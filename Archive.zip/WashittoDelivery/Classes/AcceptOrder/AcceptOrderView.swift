//
//  AcceptOrderView.swift
//  WashittoDelivery
//
//  Created by Rahul on 17/08/18.
//  Copyright © 2018 Himanshu pal. All rights reserved.
//

import UIKit
import GoogleMaps
import HarishFrameworkSwift4


class AcceptOrderView: UIViewController  ,GMSMapViewDelegate , CLLocationManagerDelegate{
    @IBOutlet var lblTimer: UILabel!
    var timer: Timer?

    @IBOutlet var progressing: CustomSlider!
    @IBOutlet var lblType: UILabel!
    @IBOutlet var imgType: UIImageView!
    @IBOutlet var lblDistance: UILabel!
   

    var is_time = 0, remaining_time = 0
    
    var classType = ""

    //    var UserPin: GMSMarker?
    var orderLo: GMSMarker!
    var UserPin: GMSMarker!
    var orderImage = UIImage(named: "deliverypin")
    var LaundryType  = ""
    var latitude:Double = 0.0 //
    var longitude:Double = 0.0 // 76.0508
    var orderLocation: CLLocationCoordinate2D?
    var locManager:CLLocationManager? = CLLocationManager()
    @IBOutlet var mapView: GMSMapView!
    @IBOutlet var viewAcceptPOPUP: UIView!
    @IBOutlet var progressAccept: UIProgressView!
    
    @IBOutlet var imgAnimation: UIImageView!
    @IBOutlet var backbutton: UIBarButtonItem!

    var orderid = ""
    var request_id = ""

//    func setOrder(){
//        progressAccept.progress = 0.1
//    }
    
    var line_color = UIColor(red: 60/255, green: 176/255, blue: 223/255, alpha: 1.0)//(red: 60/255, green: 176/255, blue: 223/255) // 60. 176 223
    override func viewDidLoad() {
        
      //  progressAccept.progress = 1.0
        backbutton.image = UIImage.imageWithImage(image: UIImage(named: "back.png")!, scaledToSize: CGSize(width: 10.0, height: 16.0))

        if kappDelegate.comefromNoti == "yes" {
            orderid = kappDelegate.order_id
            request_id = kappDelegate.request_id
            classType = "yes"
        }

        navigationController?.navigationBar.shouldRemoveShadow(true)
        if latitude == 0.0 {
//            latitude = 22.6965059
//            longitude = 75.865884
        }
        
        self.WS_OrderDetails()

        self.setImageNavigation()
        
        self.mapView.delegate = self;
       
        
        self.mapView.settings.myLocationButton = false;
        self.mapView.settings.zoomGestures = true;
        self.mapView.settings.scrollGestures = true;
        self.mapView.isUserInteractionEnabled = true;
        self.mapView.isMyLocationEnabled = false;
        self.mapView.settings.compassButton = true;
           self.view.addSubview(viewAcceptPOPUP)

        viewAcceptPOPUP.frame = CGRect(x: 0, y:self.view.bounds.size.height - self.viewAcceptPOPUP.frame.size.height - 64, width: self.view.frame.size.width, height: self.viewAcceptPOPUP.frame.size.height)
        curLocation()
        
      //  let blueColor = UIColor(red: 77/255, green: 170/255, blue: 207/255, alpha: 1.0)
        
        progressing.trackHeight = 29
        progressing.layer.cornerRadius = 14.5
    
        progressing.clipsToBounds = true
        progressing.frame.size.height = 29
        self.progressing.isHidden = true
        
        progressing.minimumTrackTintColor = UIColor(red: 255/255, green: 192/255, blue: 0/255, alpha: 1.0)

        progressing.backgroundColor = UIColor(red: 255/255, green: 192/255, blue: 0/255, alpha: 1.0)
        progressing.tintColor = UIColor(red: 255/255, green: 192/255, blue: 0/255, alpha: 1.0)
        self.progressing.maximumTrackTintColor = UIColor(red: 255/255, green: 192/255, blue: 0/255, alpha: 1.0)


        UserPin = GMSMarker()
        UserPin.tracksViewChanges = true
        UserPin.appearAnimation = .none
        
        UserPin.title = "My Location"
      
        UserPin.icon = orderImage
        UserPin.map = mapView
        
        
    }
    
    var increse:Float  = 0.0
    
    func WS_OrderDetails(){
        let params = NSMutableDictionary()
        params["order_id"] = orderid
        params["request_id"] = request_id
        
        Http.instance().json(WebServices.ordersdetails, params, "GET", ai: true, popup: true, prnt: true, userInfo.Token(), sync: false) { (json, dict, str) in
            
            if json != nil {
                let json1 = json as? NSDictionary
                if number(json1! , "success").boolValue {
                    
                    
                    if let result = json1?["result"] as? NSDictionary {
                        
                        
                        self.LaundryType = string(result, "title")
                        if  let ll1 = Double(string(result, "latitude")) {
                            self.latitude = ll1
                        }
                        if  let ll = Double(string(result, "longitude")) {
                            self.longitude = ll
                        }
                        if self.checkingLocation {
                            if (self.locManager?.location?.coordinate.latitude) != nil {
                                self.getMyPolyline(myLat: (self.locManager?.location?.coordinate.latitude)!, myLng: (self.locManager?.location?.coordinate.longitude)!)

                            }
                            
                        }
                        
                        let position = CLLocationCoordinate2D(latitude: self.latitude, longitude: self.longitude)
                        self.orderLo = GMSMarker(position: position)
                        self.orderLo?.title = "Order location"
                       self.orderLo?.position = position
                        if  self.LaundryType  == "Laundry Owner" {
                            self.orderLo?.icon = UIImage(named: "laundrypin")
                        }else {
                            self.orderLo?.icon = UIImage(named: "Cumtomerpin")
                        }
                        
                        self.orderLo?.map = self.mapView
                        self.lblType.text = string(result, "service_name")
                        //

                        if let path = result.object(forKey: "service_icon") as? String {
                            let imgurl =  APPConstants.upload_url + path
                        //    let URL =  NSURL(string: imgurl)
                            //            print("-url--\(URL)-")
                            self.imgType.downloadedServer(url: imgurl)
                            
                        }
                        
                        
                        if let remainingtime = result.object(forKey: "remaining_time") as? Int {
                             self.remaining_time = remainingtime

                        }
                        if self.remaining_time == 0 {
                            self.remaining_time = 10

                        }
                        self.progressing.maximumValue = Float(self.remaining_time)
                       self.progressing.isHidden = false
                        
                        self.progressing.minimumValue  = 0.0
                        self.progressing.setValue(Float(self.remaining_time), animated: false)
                     
                        
                        if self.timer == nil {
                            DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(1), execute: {
                                self.progressing.tintColor = UIColor.white
                                self.progressing.backgroundColor = UIColor.white
                                self.progressing.maximumTrackTintColor = UIColor.white

                            })

                            self.timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(self.myMethod), userInfo: nil, repeats: true)
                            self.timer?.fire()
                        }
                    }
                }else {
                    Http.alert("", string(json1! , "message"))
                }
            }
        }
    }
    
    
    @objc func myMethod(){
        
     //   DispatchQueue.main.async {
            let ss = Float(self.remaining_time) - Float(self.is_time)
            print("processing_value ----->\(ss)")
            if ss >= 0.0 {
                
//                UIView.animate(withDuration: 1, animations: {
//                })
                 self.progressing.setValue(ss, animated:true)
            }else {
                self.timer?.invalidate()
                self.timer = nil
                if self.classType == "" {
                    self.navigationController?.popViewController(animated: true)
                }else {
                    self.sideMenuViewController.setContentViewController(self.storyboard?.instantiateViewController(withIdentifier: "order_nav"), animated: true)
                }
            }
            
            self.is_time = self.is_time + 1

       // }
        
        //  print("<-is_time-\(is_time)---<--\(progressAccept.progress)----->")
      /*
        
        if is_time == remaining_time { // timer to  // remaining_time
//            actionLeftNavigation(0)
            timer?.invalidate()
            timer = nil
            DispatchQueue.main.async {
                if self.classType == "" {
                    self.navigationController?.popViewController(animated: true)
                }else {
                    self.sideMenuViewController.setContentViewController(self.storyboard?.instantiateViewController(withIdentifier: "order_nav"), animated: true)

                }

            }
            

        }else {
            
          //  let ss111s = Float(remaining_time) / Float(is_time)

            
    //        let sss = (Float(is_time) / Float(remaining_time)) * 0.10000000000
            
//            let percentage = Float(remaining_time) / Float(is_time) * 100
            
            let eeee  = Float(increse) * Float(is_time)
            
            print("<--\(Float(increse))--->\(eeee)<------->")

           
            progressAccept.progress -= increse
           // let percentage =  progressAccept.progress - increse //  1.0 - increse // eeee // 100.0 - eeee
            

            // / is_time *  0.1 // Float(remaining_time) / Float(is_time) *  0.1

            // progressAccept.setProgress(Float(percentage), animated: true)

            
   
           print("timer ---->\(is_time)<--per--->\(progressAccept.progress)<------->")

        }
        
        if test {
        //    progressAccept.setProgress(0.2, animated: true)

        }else {
          //  progressAccept.setProgress(0.6, animated: true)

        }
         
         newTMP = newTMP -  increse //eeee
         
         progressAccept.setProgress(newTMP, animated: true)
         
         
         //   progressAccept.progress -= increse
         
         //   test = !test
         is_time = is_time + 1
         print("\(is_time)<--\(Float(increse))--->\(newTMP)<------->")

        */
        
    }
    @IBAction func actionNoThanks(_ sender: Any) {
        
        actionMenu(sender)
    
    }
    @IBAction func actionMenu(_ sender: Any) {
        if classType == "yes" {
            //self.dismiss(animated: true, completion: nil)
           self.sideMenuViewController.setContentViewController(self.storyboard?.instantiateViewController(withIdentifier: "order_nav"), animated: true)
        }else{
            //            self.dismiss(animated: true, completion: nil)
            self.navigationController?.popViewController(animated: true)
        }
        kappDelegate.comefromNoti = ""
        kappDelegate.order_id = ""
        kappDelegate.request_id = ""
        
//        self.sideMenuViewController.setContentViewController(self.storyboard?.instantiateViewController(withIdentifier: "order_nav"), animated: true)
    }
    
    @IBAction func actionAccept(_ sender: Any) {
        CreateOrder()
    }
    
    func CreateOrder(){
        let params = NSMutableDictionary()
        
        params["order_id"] = orderid
        params["request_id"] = request_id
        Http.instance().json(WebServices.ordersaccept, params, "POST", ai: true, popup: true, prnt: true, userInfo.Token(), sync: false) { (json, dict, str) in
            
            if json != nil {
                let json1 = json as? NSDictionary
                if number(json1! , "success") == 1 {
                    if self.timer != nil {
                        self.timer?.invalidate()
                    }
//                    self.timer?.invalidate()
                    self.timer = nil
                    if self.classType == "" {
                        self.navigationController?.popViewController(animated: true)
                    }else {
  self.sideMenuViewController.setContentViewController(self.storyboard?.instantiateViewController(withIdentifier: "order_nav"), animated: true)
                        //self.sideMenuViewController.setContentViewController(self.storyboard?.instantiateViewController(withIdentifier: "order_nav"), animated: true)
                    }
                    
//                    Http.alert("", string(json1! , "message"))
                }else {
                    
                    Http.alert("", string(json1! , "message"))
                }
            }
        }
    }
    func curLocation() {
        
        if locManager != nil {
            locManager?.delegate = self
            locManager?.desiredAccuracy = kCLLocationAccuracyBest
            
            locManager?.requestWhenInUseAuthorization()
            
            locManager?.distanceFilter = 1
            locManager?.startUpdatingLocation()
            locManager!.desiredAccuracy = kCLLocationAccuracyBest;
            locManager!.activityType = .automotiveNavigation;
            
            locManager?.startUpdatingHeading()
            
            // Check authorizationStatus
            let authorizationStatus = CLLocationManager.authorizationStatus()
            // List out all responses
            
            switch authorizationStatus {
            case .authorizedAlways:
                print("authorized")
            case .authorizedWhenInUse:
                print("authorized when in use")
            case .denied:
                print("denied")
            case .notDetermined:
                print("not determined")
            case .restricted:
                print("restricted")
            }
            
            // Get the location
            locManager?.startUpdatingLocation()
            
            if(CLLocationManager.authorizationStatus() == CLAuthorizationStatus.authorizedWhenInUse ||
                CLLocationManager.authorizationStatus() == CLAuthorizationStatus.authorizedAlways) {
                // Extract the location from CLLocationManager
                let userLocation = locManager?.location
                
                // Check to see if it is nil
                if userLocation != nil {
                    if (locManager?.location?.coordinate.latitude) != nil {
                        let camera = GMSCameraPosition.camera(withLatitude: (locManager?.location?.coordinate.latitude)!, longitude: (locManager?.location?.coordinate.longitude)!, zoom: 10.0)
                        mapView?.animate(to: camera)
                      
                    }
                    //print("location is \(userLocation)")
                } else {
                    //print("location is nil")
                }
            } else {
                //print("not authorized")
            }
            
        }
    }
    var iscall = true
    
    var lastLocation:CLLocation? = nil
    var ismyLocation = true
    
    
    
    func locationManager(_ manager: CLLocationManager, didUpdateHeading newHeading: CLHeading) {
        let  heading:Double = newHeading.trueHeading;
        UserPin.groundAnchor = CGPoint(x: 0.5, y: 0.5)
        UserPin.rotation = heading
        //        print("heading---->",heading)
        UserPin.map = mapView;
        //
        
    }
    
    var checkingLocation = true
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation])
    {
        
        
        
        CATransaction.begin()
        CATransaction.setAnimationDuration(0.3)
        
        CATransaction.setValue(2.0, forKey: kCATransactionAnimationDuration)
        CATransaction.setCompletionBlock {
            self.UserPin.groundAnchor = CGPoint(x: 0.5, y: 0.5)
        }
        UserPin.position = (locManager?.location!.coordinate)!
        CATransaction.commit()
        
        
        
        
        let position1 = CLLocationCoordinate2D(latitude: (manager.location?.coordinate.latitude)!, longitude: (manager.location?.coordinate.longitude)!)
        
        //        let head = manager.location?.course ?? 0
        //        print("rotation ->",head)
        //        UserPin.rotation = head
        UserPin.position = position1
        
        if checkingLocation {
            self.getMyPolyline(myLat: (locManager?.location?.coordinate.latitude)!, myLng: (locManager?.location?.coordinate.longitude)!)
            
        }
        
//        let position111 = CLLocation(latitude: (manager.location?.coordinate.latitude)!, longitude: (manager.location?.coordinate.longitude)!)
        
   
        
     
        
    }
    var oldLocationCenter: CLLocation?
    
  
    
    
    func showAllMarker(){
        var bounds = GMSCoordinateBounds()
        
        if latitude != 0.0 || longitude != 0.0 {
            
            bounds = bounds.includingCoordinate(CLLocationCoordinate2D(latitude:latitude, longitude:longitude))
        }
        if self.UserPin.position.longitude != 0.0 {
            self.iscall = false
            bounds = bounds.includingCoordinate(CLLocationCoordinate2D(latitude:(self.UserPin.position.latitude), longitude:(self.UserPin.position.longitude)))
            
            let update = GMSCameraUpdate.fit(bounds, withPadding: 50)
            mapView.animate(with: update)
        }
        
    }
    
    func getMyPolyline(myLat: Double, myLng: Double)  {
        
        
        let config = URLSessionConfiguration.default
        let session = URLSession(configuration: config)
        
        if latitude == 0.0 || longitude == 0.0 {
            return
        }
        
        let directionURL = String(format: "https://maps.googleapis.com/maps/api/directions/json?origin=\(myLat),\(myLng)&destination=\(latitude),\(longitude)&key=AIzaSyDemfeMxzN_fPkeeBS8vYOQb3w01UOVtv0")
        //
        print(directionURL)
        let url = URL(string: directionURL)!
        let task = session.dataTask(with: url, completionHandler: {
            (data, response, error) in
            if error != nil {
                print(error!.localizedDescription)
            } else {
                do {
                    if let json = try JSONSerialization.jsonObject(with: data!, options: .allowFragments) as? NSDictionary {
                        //                        _ = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
                        print("json --->",json)
                        self.checkingLocation = false
                        if let routes = json.object(forKey:"routes")  as? NSArray {
                            if routes.count > 0 {
                                DispatchQueue.main.async {
                                    if self.iscall {
                                        self.iscall = false
                                        self.showAllMarker()
                                    }
                                    self.mapView.clear()
                                    self.orderLo?.map = self.mapView
                                    self.UserPin?.map = self.mapView
                                    for dic11 in routes {
                                        if let route = dic11 as? NSDictionary {
                                            if let arr = route["legs"] as? NSArray {
                                                for route1 in arr {
                                                    if let route1 = route1 as? NSDictionary {
                                                        if let distance = route1.object(forKey:"distance") as? NSDictionary {
                                                            
                                                                self.lblDistance.text = string(distance, "text")
                                                        }
                                                        if let duration = route1.object(forKey:"duration") as? NSDictionary {
                                                            
                                                            self.lblTimer.text = string(duration, "text")
                                                        }
                                                        
                                                        if let steps = route1["steps"] as? NSArray {
                                                            self.convertPolyline(steps)
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    
                                }
                            }
                        }
                        
                        
                        
                    }
                } catch {
                    //                    print("error in JSONSerialization")
                }
            }
        })
        task.resume()
    }
    
    
    
    
    func convertPolyline(_ arr: NSArray){
        
        
        for k in 0..<arr.count {
            if let route2 = arr[k] as? NSDictionary {
                if let overviewPolyline = route2["polyline"] as? NSDictionary {
                    if let points = overviewPolyline["points"] as? String {
                        
                        let path = GMSMutablePath(fromEncodedPath: points)
                        let polyline = GMSPolyline(path: path)
                        polyline.strokeWidth = 5
                        polyline.strokeColor = UIColor.red
                        polyline.map = mapView
                        
                    }
                }
            }
            
        }
        
    }
    
    
    
}

extension UIImageView {
    func downloadedServer(url: String) {
        guard let url = URL(string: url) else { return }

        URLSession.shared.dataTask(with: url) { data, response, error in
            guard
                let httpURLResponse = response as? HTTPURLResponse, httpURLResponse.statusCode == 200,
                let mimeType = response?.mimeType, mimeType.hasPrefix("image"),
                let data = data, error == nil,
                let image = UIImage(data: data)
                else { return }
            DispatchQueue.main.async() {
                self.image = image
                self.image = image.withRenderingMode(.alwaysTemplate)
                self.tintColor = UIColor.white

            }
            }.resume()
    }
 
}
open class CustomSlider : UISlider {
    @IBInspectable open var trackHeight:CGFloat = 2 {
        didSet {setNeedsDisplay()}
    }
    
    override open func trackRect(forBounds bounds: CGRect) -> CGRect {
        let defaultBounds = super.trackRect(forBounds: bounds)
        return CGRect(
            x: 0,
            y: defaultBounds.origin.y + defaultBounds.size.height/2 - trackHeight/2,
            width: defaultBounds.size.width,
            height: trackHeight
        )
        /*  return CGRect(
         x: defaultBounds.origin.x,
         y: defaultBounds.origin.y + defaultBounds.size.height/2 - trackWidth/2,
         width: defaultBounds.size.width,
         height: trackWidth
         )*/
    }
}
