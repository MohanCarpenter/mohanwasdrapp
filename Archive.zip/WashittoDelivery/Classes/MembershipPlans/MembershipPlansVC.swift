//
//  MembershipPlansVC.swift
//  Washitto
//
//  Created by Kavya mac 5 on 07/08/18.
//  Copyright © 2018 Himanshu. All rights reserved.
//

import UIKit
import HarishFrameworkSwift4

class MembershipPlansVC: UIViewController , UITableViewDelegate , UITableViewDataSource , UICollectionViewDelegate , UICollectionViewDataSource , UICollectionViewDelegateFlowLayout{
    
    @IBOutlet var lblTitle: UILabel!
    @IBOutlet var collectionView: UICollectionView!
    
    @IBOutlet var viewDetails: View!
    @IBOutlet var lblPrice: UILabel!
    @IBOutlet var tblView: UITableView!
    @IBOutlet var btnSubscribeNow: UIButton!
    @IBOutlet var viewCircle2: UIView!
    @IBOutlet var viewCircle1: UIView!
    
    var arrPlans = NSMutableArray()
    var intIndexSelected = 0
    var plan_id = ""
    var plan_name = ""
    
    //MARK:- Life Cycle Methods
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.isNavigationBarHidden = false
        navigationItem.hidesBackButton = false
        navigationController?.navigationBar.shouldRemoveShadow(true)
        self.setImageNavigation()
        self.rightMenuNavigationButton()
        Displaylayout()
        WS_Plan_List()
        
        tblView.isScrollEnabled = false
    }
    
    // MARK: - FUNCTIONS
    
    func DisplayAndDelegates()  {
        collectionView.isHidden = false
        tblView.isHidden = false
        btnSubscribeNow.isUserInteractionEnabled = true
        
        if let flowLayout = collectionView.collectionViewLayout as? UICollectionViewFlowLayout {
            
            var width = CGFloat()
            
            if arrPlans.count < 5{
                width = (view.frame.width-10)/CGFloat(arrPlans.count)
            }else{
                width = (view.frame.width-10)/4
            }
            
            flowLayout.itemSize = CGSize(width: width, height: 35)
            flowLayout.minimumInteritemSpacing = 0
            flowLayout.minimumLineSpacing = 0
        }
        
        collectionView.alwaysBounceHorizontal = false
        
        let dict = arrPlans.object(at: 0) as! NSDictionary
        
        // lblPrice.text = "$" + string(dict, "price") + "\n/"  + string(dict, "duration")
        if  let price = Double(string(dict, "price")){
            
            let dollar = price.dollarString
            
            lblPrice.attributedText = getMyAtrributedString(strFirst: "\(dollar)\n", fontSizeFirst: 30.0, strSecond: "/\(string(dict, "duration"))", fontSizeSecond: 20.0)
        }else{
            lblPrice.text =  ""
        }
        
        plan_id = string(dict, "id")
        plan_name = string(dict, "title")
        intIndexSelected = 0
    }
    
    func Displaylayout()  {
        // arrPlans = ["Monthly","Quarterly","Half-yearly","Annually"]
        collectionView.delegate = self
        collectionView.dataSource = self
        tblView.delegate = self
        tblView.dataSource = self
        
        viewCircle1.border(UIColor.white, viewCircle1.frame.size.height/2, 2)
        viewCircle2.border(UIColor.clear, viewCircle2.frame.size.height/2, 1)
        
        collectionView.allowsSelection = true
        
        collectionView.isHidden = true
        tblView.isHidden = true
        
        lblPrice.text = ""
        btnSubscribeNow.isUserInteractionEnabled = false
        //print("plan_name--->>",plan_name)
        
        if plan_name.count == 0{
            btnSubscribeNow.setTitle("Subscribe Now", for: .normal)
        }else{
            btnSubscribeNow.setTitle("Update Now", for: .normal)
        }
    }
    
    func rightMenuNavigationButton()  {
        let button1 = UIBarButtonItem(image: UIImage(named: "menu"), style: .plain, target: self, action: #selector(actionRightMenuButton)) //
        self.navigationItem.rightBarButtonItem = button1
    }
    
    @objc func actionRightMenuButton() {
        self.sideMenuViewController.presentRightMenuViewController()
    }
    
    @IBAction func btnSubscribeNow(_ sender: Any) {
        self.ws_SubscribePlan()
    }
    
    // MARK: - TableView Delegates and Data source
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return 2
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tblView.dequeueReusableCell(withIdentifier: "PlanTableViewCell") as! PlanTableViewCell
        
        //  cell.lblTitle.text = "Lorem ipsum dolor sit amet, consectetur adipiscing elit."
        
        if indexPath.row == 0{
            cell.lblTitle.text = "No delivery charges."
        }else if indexPath.row == 1{
            cell.lblTitle.text = "No extra charges."
        }else{
            cell.lblTitle.text = ""
        }
        return cell
    }
    
    // MARK: - Colletion Delegates and Data source
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        return arrPlans.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "PlanOptionCollectionCell", for: indexPath) as! PlanOptionCollectionCell
        
        let dict = arrPlans.object(at: indexPath.row) as! NSDictionary
        
        cell.lblTitle.text = string(dict, "title")
        
        if intIndexSelected == indexPath.row {
            cell.lblLine.backgroundColor = appColor
        }else{
            cell.lblLine.backgroundColor = appLightGray
        }
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        let dict = arrPlans.object(at: indexPath.row) as! NSDictionary
        
        //   lblPrice.text = "$" + string(dict, "price") + "\n/"  + string(dict, "duration")
        
        if  let price = Double(string(dict, "price")){
            
            let dollar = price.dollarString
            
            lblPrice.attributedText = getMyAtrributedString(strFirst: "\(dollar)\n", fontSizeFirst: 30.0, strSecond: "/\(string(dict, "duration"))", fontSizeSecond: 20.0)
        }else{
            lblPrice.text =  ""
        }
        
        plan_id = string(dict, "id")
        plan_name = string(dict, "title")
        
        intIndexSelected = indexPath.row
        collectionView.reloadData()
    }
    
    ///////////////////*****************************
    
    func WS_Plan_List(){
        
        Http.instance().json(WebServices.plan_list, nil, "GET", ai: true, popup: true, prnt: true, userInfo.Token(), sync: false) { (json, dict, str) in
            
            if json != nil {
                let json1 = json as? NSDictionary
                if number(json1! , "success").boolValue {
                    if let result = json1?["result"] as? NSArray {
                        self.arrPlans = result.mutableCopy() as! NSMutableArray
                        
                        print("arrPlans-->>>\(self.arrPlans)")
                        self.DisplayAndDelegates()
                        self.collectionView.reloadData()
                        self.tblView.reloadData()
                    }
                    print(json1!)
                }else {
                    Http.alert("", string(json1! , "message"))
                }
            }
        }
    }
    
    func ws_SubscribePlan() {
        
        let params = NSMutableDictionary()
        params["plan_id"]  = plan_id
        
        Http.instance().json(WebServices.plan_purchase, params, "POST", ai: true, popup: true, prnt: true, userInfo.Token(), sync: false) { (json, params, strJson) in
            
            if json != nil {
                
                let json = json as? NSDictionary
                if number(json! , "success").boolValue {
                    self.navigationController?.popViewController(animated: true)
                    //Http.alert("", string(json! , "message"))
                }else{
                    Http.alert("", string(json! , "message"))
                }
            }else {
                Http.alert("", string(json as! NSDictionary , "message"))
            }
        }
    }
    
    //MARK:- Fuctions NSMutableAttributedString
    
    func getMyAtrributedString(strFirst:String, fontSizeFirst:CGFloat , strSecond:String, fontSizeSecond:CGFloat) -> NSMutableAttributedString {
        
        let attributedStr1 = [
            NSAttributedStringKey.font : UIFont.boldSystemFont(ofSize: fontSizeFirst),
            NSAttributedStringKey.foregroundColor : UIColor.white]
        
        let attributedStr2 = [
            NSAttributedStringKey.font : UIFont.systemFont(ofSize: fontSizeSecond),
            NSAttributedStringKey.foregroundColor : UIColor.white]
        
        let myFinalString1 = NSMutableAttributedString(string: strFirst, attributes: attributedStr1 )
        
        let myFinalString2 = NSMutableAttributedString(string: strSecond, attributes: attributedStr2 )
        
        myFinalString1.append(myFinalString2)
        
        return myFinalString1
    }
}

class PlanOptionCollectionCell : UICollectionViewCell {
    
    @IBOutlet var lblTitle: UILabel!
    @IBOutlet var lblLine: UILabel!
    
}

class PlanTableViewCell : UITableViewCell {
    
    @IBOutlet var lblTitle: UILabel!
    @IBOutlet var imgPlan: UIImageView!
    
}







