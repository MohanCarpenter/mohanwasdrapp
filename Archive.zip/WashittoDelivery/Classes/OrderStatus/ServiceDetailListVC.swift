
//
//  ServiceDetailVC.swift
//  Washitto
//
//  Created by Himanshu on 03/07/18.
//  Copyright © 2018 Himanshu. All rights reserved.
//

import UIKit
import HarishFrameworkSwift4

//import AVFoundation

class ServiceDetailListVC: UIViewController , UITableViewDelegate, UITableViewDataSource, ServiceDetailDelegate ,  UIImagePickerControllerDelegate, UINavigationControllerDelegate, UIPopoverControllerDelegate , UITextFieldDelegate,  UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout {
//    @IBOutlet var imgUser: UIImageView!
//    @IBOutlet var tfCode: TextField!
    var imgProfilePicture:UIImage? = nil
//    @IBOutlet var viewPicked: UIView!

    @IBOutlet var tblHeight: NSLayoutConstraint!
    @IBOutlet var viewScrl: UIView!
//    @IBOutlet var view_main: UIView!
    @IBOutlet var scrlView: UIScrollView!
    @IBOutlet var imgService: UIImageView!
    @IBOutlet var lblServiceType: UILabel!
    @IBOutlet var lblPickup: UILabel!
    @IBOutlet var lblDropOff: UILabel!
    @IBOutlet var lblAddress: UILabel!
    @IBOutlet var tblView: UITableView!
    @IBOutlet var lblWASH_TEMPERATURE: UILabel!
    @IBOutlet var lblTimer: UILabel!
    var request_id = ""

    var orderid = ""
//    var comefrom = ""
       @IBOutlet var const_btn_request: NSLayoutConstraint!
//    @IBOutlet var wash_const: NSLayoutConstraint!
    @IBOutlet var const_mainView_height: NSLayoutConstraint!
    @IBOutlet var lblSubtotal: UILabel!
    @IBOutlet var lblLineSELECTION: UILabel!

    @IBOutlet var lblDeliveryCharge: UILabel!
    @IBOutlet var lblOrderStatus: UILabel!
//    @IBOutlet var pickup_origin_Const: NSLayoutConstraint!
    @IBOutlet var collectionInagesView: UICollectionView!

    @IBOutlet var backbutton: UIBarButtonItem!
    ///
    @IBOutlet var const_order_images: NSLayoutConstraint!
    var arrOrder_images = NSArray()
//    @IBOutlet var origin_const: NSLayoutConstraint!
    @IBOutlet var viewOrderImage: UIView!

    @IBOutlet var imgProduct: UIImageView!
    @IBOutlet var lblProductName: UILabel!
    @IBOutlet var lblPrice: UILabel!
    @IBOutlet var lblDiscount: UILabel!
    @IBOutlet var lblQuantity: UILabel!
    @IBOutlet var btnTemperature: Button!
    @IBOutlet var btnDryerTemperature: Button!
    @IBOutlet var btnDertergent: Button!
    @IBOutlet var btnFabricSoftener: Button!
    @IBOutlet var btnOxiclean: Button!
    @IBOutlet var btnSeperateColors: Button!
    @IBOutlet var btnStarch: Button!
    @IBOutlet var lblSpecialInstructions: UILabel!
    @IBOutlet var lblTotalPrice: UILabel!
    var timer: Timer?

    //
    var dictMain = NSDictionary()
    override func viewDidLoad() {
        super.viewDidLoad()
//        collectionInagesView.layer.cornerRadius = 10
        collectionInagesView.clipsToBounds = false
        backbutton.image = UIImage.imageWithImage(image: UIImage(named: "back.png")!, scaledToSize: CGSize(width: 10.0, height: 16.0))
        collectionInagesView.delegate = self
        collectionInagesView.dataSource = self
        let cellWidth : CGFloat = collectionInagesView.frame.size.width / 2.0 - 5.0
        let cellheight : CGFloat = collectionInagesView.frame.size.height//myCollectionView.frame.size.width / 4.0 //- 2.0
        let cellSize = CGSize(width: cellheight , height:cellheight)
        
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .horizontal //.horizontal
        layout.itemSize = cellSize
        layout.sectionInset = UIEdgeInsets(top: 1, left: 1, bottom: 1, right: 1)
        layout.minimumLineSpacing = 1.0
        layout.minimumInteritemSpacing = 1.0
        collectionInagesView.setCollectionViewLayout(layout, animated: true)
        

//        viewPicked.frame = self.view.frame
       

        if kappDelegate.comefromNoti == "yes" {
            orderid = kappDelegate.order_id
            request_id = kappDelegate.request_id
           //implement timer
         
         
        }else{
//            kappDelegate.comefromNoti = ""
//            kappDelegate.order_id = ""
            }
       self.ws_ordersdetails()
        
        
    

//        origin_const.constant = CGFloat(self.view.frame.size.width) // CGFloat
        // Do any additional setup after loading the view.
    }

    @IBAction func actionMenu(_ sender: Any) {
        self.sideMenuViewController.presentRightMenuViewController()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.isNavigationBarHidden = false
        navigationItem.hidesBackButton = false
        navigationController?.navigationBar.shouldRemoveShadow(true)
        self.setImageNavigation()
        
    }
    var is_time = 5
    @objc func myMethod(){
        print("timer ---->\(is_time)")
        

        if is_time == 0 { // timer to
            actionLeftNavigation(0)
            timer?.invalidate()
            timer = nil
        }
        if is_time != 0 {
            let date = Date(timeIntervalSince1970: Double(is_time))
            print("date - \(date)")
            
            let formatter = DateFormatter()
            formatter.dateFormat = "mm:ss"
//             formatter.locale = NSLocale(localeIdentifier: "en_US") as Locale!
            formatter.timeZone = TimeZone(abbreviation: "UTC") //  NSTimeZone(abbreviation: "UTC")! as TimeZone

            let dd = formatter.string(from: date as Date)
            print(dd)
            
            lblTimer.text = dd
        }
  
        is_time = is_time - 1

    }
    
    
    @IBAction func actionAddress(_ sender: Any) {
    
    }
    @IBAction func actionLeftNavigation(_ sender: Any) {
        
        if kappDelegate.comefromNoti == "yes" {
//            self.navigationController?.popViewController(animated: true)
  
            self.sideMenuViewController.setContentViewController(self.storyboard?.instantiateViewController(withIdentifier: "order_nav"), animated: true)
        }else{
//            self.dismiss(animated: true, completion: nil)
            self.navigationController?.popViewController(animated: true)
        }
     kappDelegate.comefromNoti = ""
        kappDelegate.order_id = ""
        kappDelegate.request_id = ""

    }
    
    var pickupDateTime = String()
    var dropDateTime = String()
    var dictaddress = NSDictionary()
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        self.title  = ""
    }
    
    
  
    
    var request_status = ""
    var arrlist = NSMutableArray()
    func ws_ordersdetails(){
        let params = NSMutableDictionary()
        params["order_id"] = orderid
        params["request_id"] = request_id

        Http.instance().json(WebServices.ordersdetails, params, "GET", ai: true, popup: true, prnt: true, userInfo.Token(), sync: false) { (json, dict, str) in
            
            if json != nil {
                let json1 = json as? NSDictionary
                if number(json1! , "success").boolValue {
//                    kappDelegate.comefromNoti = ""
//                    kappDelegate.order_id = ""
                    self.arrlist = NSMutableArray()
                  if let result = json1?["result"] as? NSDictionary {
                    
                    if let path = result.object(forKey: "service_icon") as? String {
                        let imgurl = APPConstants.upload_url + path
                        let URL =  NSURL(string: imgurl)
                        self.imgService.sd_setImage(with: URL as URL!, placeholderImage: UIImage(named: "noimage.png"),  options: SDWebImageOptions.retryFailed)
                        self.lblServiceType.text =  string(result, "service_name")
                    }
                    self.dictMain = result
                    
                    
                    self.request_status = string(result, "request_status")
//                    self.lblOrderStatus.text = "" + self.request_status + "   "
                    // string(result, "order_status")
                    
                    let  strStatus = string(result, "request_status")
                    self.lblOrderStatus.text = ""  + strStatus + "   "
                    self.lblOrderStatus.backgroundColor = appColour().getColor(string(result, "request_status"))
                    self.lblOrderStatus.textColor = UIColor.white
                   // remaining_time
                    
                    if let remaining_time = result.object(forKey: "remaining_time") as? Int {
                        self.is_time = remaining_time
                    }
                    self.request_type = string(result, "request_type")

                    if self.request_status == "Pending" {
                        if self.is_time == 0 {
                            self.is_time = 10
                        }
                        if self.timer == nil {
                            self.timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(self.myMethod), userInfo: nil, repeats: true)
                            self.timer?.fire()
                        }
                    }else if self.request_status == "Accepted" {
                        self.btnRequest.setTitle("Pick up", for: .normal)
                        self.btnRequest.isHidden = false
                    }
                    else if self.request_status == "Pickedup" && self.request_type == "Dropoff"{
                        self.btnRequest.setTitle("Delivered", for: .normal)
                        self.btnRequest.isHidden = false
                    }
//                    else if self.request_status == "Pickedup" {
//                        self.btnRequest.setTitle("Pickedup", for: .normal)
//                    }
                    else {
                        self.btnRequest.isHidden = true
                    }
                    self.lblPickup.text =  string(result, "pickup_time").converDate("yyyy-MM-dd HH:mm:ss", "dd E, MMM \nhh:mm a")
                    self.lblDropOff.text =  string(result, "dropoff_time").converDate("yyyy-MM-dd HH:mm:ss", "dd E, MMM \nhh:mm a")
                  
                    
                    self.lblSubtotal.text = "$" + string(result, "subtotal")
                    self.lblDeliveryCharge.text = "$" + string(result, "delivery_charge")
                    
                    
                    self.lblTotalPrice.text = " $" + string(result, "grand_total")

                    
                    self.lblAddress.text =   string(result, "address")
                 
                    if let customer =  result.object(forKey: "customer")as? NSDictionary{
                        self.arrlist.add(customer)
                        
                    }
                    if let dictVendor =  result.object(forKey: "vendors")as? NSDictionary{
                        self.arrlist.add(dictVendor)
                        
                    }
                    if let dictpickupdeliveryboy =  result.object(forKey: "pickup_deliveryboy")as? NSDictionary{
                        self.arrlist.add(dictpickupdeliveryboy)
                        
                    }
                    if let dictdropoffdeliveryboy =  result.object(forKey: "dropoff_deliveryboy")as? NSDictionary{
                        self.arrlist.add(dictdropoffdeliveryboy)
                    }
//                    print(self.arrlist)
                    self.tblView.reloadData()
                    
                    if self.arrlist.count > 0 {
                        self.tblView.isHidden = false
                        self.tblHeight.constant = CGFloat(self.arrlist.count * 100)
                        
                    }else{
                        self.tblView.isHidden = true
                        self.btnRequest.frame.origin.y = self.viewPayment.frame.size.height + self.viewPayment.frame.origin.y + 10
                    }
                    
                    
                    self.showdetail()
                    }
                }else {
                    Http.alert("", string(json1! , "message"))
                }
            }
        }
    }
    
   

    func showdetail(){
        
        if let arr =  dictMain.object(forKey: "order_images") as? NSArray {
            self.arrOrder_images = arr
            collectionInagesView.reloadData()
        }
        
        lblDeliveryCharge.text = " $" + string(dictMain, "delivery_charge") + " "
        
        var myDict = dictMain
        if   let myDic1t =  dictMain.object(forKey: "options") as? NSDictionary{
            myDict = myDic1t
        }
        //    print("myDict--------\(myDict)")
        
        
        if self.arrOrder_images.count == 0 {
            
            const_order_images.constant = 0
            
            
            
            
            // collectionInagesView.isHidden = true
        }
        if string(myDict, "bag_type").lowercased() == "small_bag" {
            lblProductName.text  = "Small Bag"
            //        imgProduct.image = UIImage(named: "bag_sm.png")
        }else {
            lblProductName.text  = "Large Bag"
        }
        imgProduct.image = UIImage(named: "bag_lg.png")
        
        if string(myDict, "bag_type") == "small_bag"{
            lblDiscount.text = "*Up to 30 pounds"
        }else{
            lblDiscount.text = "*Up to 50 pounds"
        }
        
        lblQuantity.text = "Quantity - " + string(myDict, "bag_qty")
        lblPrice.text =  "$" + string(myDict, "bag_price")
        
        
        
        btnTemperature.setTitle("    " + string(myDict, "wash_temp") + "    ", for: .normal)
        btnDryerTemperature.setTitle("    " + string(myDict, "dryer_temp") + "    " , for: .normal)
        btnDertergent.setTitle("    " + string(myDict, "detergent") + "    ", for: .normal)
        
        btnFabricSoftener.setTitle("    " + string(myDict, "fabric_softener") + "    ", for: .normal)
        
        btnOxiclean.setTitle("    " + string(myDict, "oxiclean") + "    " , for: .normal)
        
        btnSeperateColors.setTitle("    " + string(myDict, "separate_colors") + "    " , for: .normal)
        
        btnStarch.setTitle("    " + string(myDict, "starch") + "    ", for: .normal)
        
        
        lblSpecialInstructions.text =  string(myDict, "instructions")
        //    print("constant--->",const_mainView_height.constant)
        //    const_mainView_height.constant = btnRequest.frame.origin.y + btnRequest.frame.size.height
        //    viewScrl.layoutIfNeeded()
        
        //    print("constant--->",const_mainView_height.constant)
        
        
        DispatchQueue.main.async {
            //        print("constant--->",self.const_mainView_height.constant)
            
            self.const_mainView_height.constant = self.btnRequest.frame.origin.y + self.btnRequest.frame.size.height
            self.viewScrl.layoutIfNeeded()
            self.viewScrl.updateConstraints()
            //        print("constant--->",self.const_mainView_height.constant)
            //        self.btnRequest.translatesAutoresizingMaskIntoConstraints = false
            
        }
        
        
        //            const_mainView_height = lblLineSELECTION.topAnchor.constraint(equalTo: const_mainView_height)
        //        constraintEqualToAnchor(self.wash_const, constant:0)
        //            btnRequest.isActiveisActive = true
        
        
        
        
        
    }
    
    //MARK:- UICollectionView
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        return self.arrOrder_images.count
    }
    
    // make a cell for each cell index path
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        // get a reference to our storyboard cell
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "GroupDetailImagesCell", for: indexPath as IndexPath) as! GroupDetailImagesCell
        let userdetail = self.arrOrder_images.object(at: indexPath.row) as! NSDictionary
        if let path = userdetail.object(forKey: "image") as? String {
            let imgurl = APPConstants.upload_url + path
            let URL =  NSURL(string: imgurl)
            cell.imgPost.sd_setImage(with: URL as URL!, placeholderImage: UIImage(named: "noimage.png"),  options: SDWebImageOptions.retryFailed)
//            cell.imgPost.setImage
            
//            cell.imgPost.
                //.setImage(self.view, imgurl, nil, true, cell.avindicator)
            
//            cell.imgPost.setImage(self.view, imgurl, nil, true, nil)
//cell.imgPost.setImage

        }else{
//            cell.imgPost.image = UIImage(named : "noimage.png")
        }
        cell.imgPost.layer.cornerRadius = 10
        cell.imgPost.clipsToBounds = true
        return cell
    }


    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let imag = self.storyboard?.instantiateViewController(withIdentifier: "MyImageZoom") as? MyImageZoom
        let userdetail = self.arrOrder_images.object(at: indexPath.row) as! NSDictionary
        if let path = userdetail.object(forKey: "image") as? String {
            let imgurl = APPConstants.upload_url + path
            imag?.imageName = imgurl
        }
        self.present(imag!, animated: false, completion: nil)
//
//        imageViewZoom._delegate = self
//        imageViewZoom.image = UIImage(named: "noimage.png")
//        imageViewZoom.contentMode = .left
//
    }
    @IBOutlet var btnRequest: UIButton!
    @IBOutlet var viewPayment: UIView!
   
    func CreateOrder(){
        let params = NSMutableDictionary()
       
        params["order_id"] = orderid
        params["request_id"] = request_id

//     params["type"] = ""  // orders/delboy-accept
        
        Http.instance().json(WebServices.ordersaccept, params, "POST", ai: true, popup: true, prnt: true, userInfo.Token(), sync: false) { (json, dict, str) in
            
            if json != nil {
                let json1 = json as? NSDictionary
                if number(json1! , "success").boolValue {
                    Http.alert("", string(json1! , "message"))
                    self.actionLeftNavigation(0)
                  
                }else {
//
                    Http.alert("", string(json1! , "message"))
                }
            }
        }
    }
    
  var request_type = ""

    @IBAction func actionRequest(_ sender: Any) {
  
        if self.request_status == "Pending" {
            self.CreateOrder()
        }else if self.request_status == "Accepted" {
            // mhn
            if request_type == "Dropoff" {
                ws_OrderPicked() // when driver go to vendor
            }else {
                let vc = self.storyboard?.instantiateViewController(withIdentifier: "OrderPickupView") as? OrderPickupView
                vc!.orderid = orderid
                vc!.request_id = request_id
                vc!.request_type = request_type
                self.navigationController?.pushViewController(vc!, animated: true)

            }
        }else if self.request_status == "Pickedup" {
            ws_DeliverdToCustomer()
        }
       
     
    }
    
    func ws_OrderPicked(){
        let params = NSMutableDictionary()
        params["request_id"] = request_id
        params["order_id"] = orderid
        params["request_type"] = request_type

        Http.instance().json(WebServices.orders_picked, params, "POST", ai: true, popup: true, prnt: true, userInfo.Token(),  sync: false) { (json, dict, str) in
            
            if json != nil {
                let json1 = json as? NSDictionary
                if number(json1! , "success").boolValue {
                    Http.alert("", string(json1! , "message"))
                    self.actionLeftNavigation(0)
                }else {
                    Http.alert("", string(json1! , "message"))
                }
            }
        }
    }
//    sdsdsds
 
    func ws_DeliverdToCustomer(){
        let params = NSMutableDictionary()
        params["request_id"] = request_id
        params["order_id"] = orderid
        params["request_type"] = request_type
        
        Http.instance().json(WebServices.deliver_to_customer, params, "POST", ai: true, popup: true, prnt: true, userInfo.Token(),  sync: false) { (json, dict, str) in
            
            if json != nil {
                let json1 = json as? NSDictionary
                if number(json1! , "success").boolValue {
                    Http.alert("", string(json1! , "message"))
                   self.actionLeftNavigation(0)
                }else {
                    Http.alert("", string(json1! , "message"))
                }
            }
        }
    }
 
    
   
    
   
    
    //MARK:- TABLEVIEW_DELEGATE
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrlist.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ServiceDetailListCell", for: indexPath) as! ServiceDetailListCell
        let dict = arrlist.object(at: indexPath.row) as! NSDictionary
        cell.index = indexPath
        cell.delegate = self
      cell.lblType.text = string(dict, "title")
        cell.lblName.text = string(dict, "name")
        if dict.object(forKey: "ratings") != nil {
           cell.viewRating.rating = (dict.object(forKey: "ratings") as? Float)!
        }else{
             cell.viewRating.rating = 0.00
            }
       
        if let path = dict.object(forKey: "profile_image") as? String {
            let imgurl = APPConstants.upload_url + path
            let URL =  NSURL(string: imgurl)
            cell.imgView.sd_setImage(with: URL as URL!, placeholderImage: UIImage(named: "noimage.png"),  options: SDWebImageOptions.retryFailed)
        }
        
        
        
        return cell
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
//        let dict = arrlist.object(at: indexPath.row) as! NSDictionary
    
    }
   
    func call(_ index:IndexPath?){
        guard let row = index?.row else {
            return
        }
        let dict = arrlist.object(at: row) as! NSDictionary

    }
    func sms(_ index:IndexPath?){
        guard let row = index?.row else {
            return
        }
        let dict = arrlist.object(at: row) as! NSDictionary
        
    }
    
    

    func Track(_ index:IndexPath?){
        guard let row = index?.row else {
            return
        }
      
        //        latitude = "22.6965059";
        //        longitude = "75.86588499999999";
        
        let dict = arrlist.object(at: row) as! NSDictionary

        let vc = self.storyboard?.instantiateViewController(withIdentifier: "TrackLocationView") as! TrackLocationView
        
        vc.LaundryType = string(dict, "title")
        if  let ll = Double(string(self.dictMain, "latitude")) {
                 vc.latitude = ll
        }
        if  let ll = Double(string(self.dictMain, "longitude")) {
            vc.longitude = ll
        }
        
        self.navigationController?.pushViewController(vc, animated: true)
        

    }
    
 
}
protocol ServiceDetailDelegate {
    
     func call(_ index:IndexPath?)
     func sms(_ index:IndexPath?)
     func Track(_ index:IndexPath?)

}
class ServiceDetailListCell: UITableViewCell {
    var delegate:ServiceDetailDelegate?
    @IBOutlet var imgView: ImageView!
    @IBOutlet var lblType: UILabel!
    @IBOutlet var viewBg: UIView!
    @IBOutlet var lblName: UILabel!
    @IBOutlet var viewRating: FloatRatingView!
    var index:IndexPath?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        let btnCall  = UIButton(type: .custom) as UIButton
        btnCall.setTitle(" Call    ", for: .normal)
        btnCall.tintColor = UIColor.white
        btnCall.backgroundColor = appColor
        btnCall.frame.size.height = 15
        btnCall.setImage(UIImage.imageWithImage(image: UIImage(named: "call_icons.png")!, scaledToSize: CGSize(width: 10.0, height: 10.0)), for: .normal)
        btnCall.titleLabel?.font = UIFont(name:"Times New Roman", size: 12)
        btnCall.imageEdgeInsets = UIEdgeInsets(top: 0, left: 4, bottom: 0, right: 0)
        btnCall.titleEdgeInsets = UIEdgeInsets(top: 0, left: 4, bottom: 0, right: 0)
        btnCall.sizeToFit()
        btnCall.addTarget(self, action: #selector(call(_:)), for: .touchUpInside)
        viewBg.addSubview(btnCall)
        btnCall.frame  = CGRect(x: viewRating.frame.origin.x, y: viewRating.frame.origin.y + viewRating.frame.size.height + 5 , width: btnCall.frame.size.width
            , height: btnCall.frame.size.height)
        btnCall.layer.cornerRadius = btnCall.frame.size.height/2
        btnCall.clipsToBounds = true
       
       //--------------------
        let btnSms  = UIButton(type: .custom) as UIButton
        btnSms.setTitle(" SMS    ", for: .normal)
        btnSms.tintColor = UIColor.white
        btnSms.backgroundColor = appColor
       // btnSms.frame.size.height = 15
        btnSms.setImage(UIImage.imageWithImage(image: UIImage(named: "sms.png")!, scaledToSize: CGSize(width: 10.0, height: 10.0)), for: .normal)
        btnSms.titleLabel?.font = UIFont(name:"Times New Roman", size: 12)
        btnSms.imageEdgeInsets = UIEdgeInsets(top: 0, left: 4, bottom: 0, right: 0)
        btnSms.titleEdgeInsets = UIEdgeInsets(top: 0, left: 4, bottom: 0, right: 0)
        btnSms.sizeToFit()
        btnSms.addTarget(self, action: #selector(sms(_:)), for: .touchUpInside)
        viewBg.addSubview(btnSms)
        btnSms.frame  = CGRect(x: btnCall.frame.origin.x + btnCall.frame.size.width + 10 , y: viewRating.frame.origin.y + viewRating.frame.size.height + 5 , width: btnSms.frame.size.width
            , height: btnSms.frame.size.height)
        btnSms.layer.cornerRadius = btnSms.frame.size.height/2
        btnSms.clipsToBounds = true
        
        
        //--------------------
        let btnTrack  = UIButton(type: .custom) as UIButton
        btnTrack.setTitle(" Track on map   ", for: .normal)
        btnTrack.tintColor = UIColor.white
        btnTrack.backgroundColor = appColor
        // btnSms.frame.size.height = 15
        btnTrack.setImage(UIImage.imageWithImage(image: UIImage(named: "track_icon.png")!, scaledToSize: CGSize(width: 8.0, height: 10.0)), for: .normal)
        btnTrack.titleLabel?.font = UIFont(name:"Times New Roman", size: 12)
        
        btnTrack.imageEdgeInsets = UIEdgeInsets(top: 0, left: 4, bottom: 0, right: 0)
        btnTrack.titleEdgeInsets = UIEdgeInsets(top: 0, left: 4, bottom: 0, right: 0)
        btnTrack.sizeToFit()
        btnTrack.addTarget(self, action: #selector(Track(_:)), for: .touchUpInside)
        viewBg.addSubview(btnTrack)
        btnTrack.frame  = CGRect(x: btnSms.frame.origin.x + btnSms.frame.size.width + 10 , y: viewRating.frame.origin.y + viewRating.frame.size.height + 5 , width: btnTrack.frame.size.width
            , height: btnTrack.frame.size.height)
        btnTrack.layer.cornerRadius = btnTrack.frame.size.height/2
        btnTrack.clipsToBounds = true
        
        
    }
    
    
    @objc private func call(_ sender: UIButton?) {
        delegate?.call(index)
    }
    @objc private func sms(_ sender: UIButton?) {
        delegate?.sms(index)
    }
    @objc private func Track(_ sender: UIButton?) {
        delegate?.Track(index)
    }
    
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
}

extension String {
    
    func getDecimalValue(_ rupee: String) -> String {
        let fullNameArr = rupee.components(separatedBy: ".")
        if fullNameArr.count  > 1{
            let name = fullNameArr[0]
            var surname = fullNameArr[1]
            if surname.characters.count == 1 {
                surname.append("0")
                let xx = name + "." + surname
                return xx
            }else {
                return rupee
            }
        }
        return rupee + ".00"
    }
    
}


