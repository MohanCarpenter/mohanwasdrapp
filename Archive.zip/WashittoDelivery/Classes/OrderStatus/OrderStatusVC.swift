//
//  OrderStatusVC.swift
//  Washitto
//
//  Created by Himanshu on 15/06/18.
//  Copyright © 2018 Himanshu. All rights reserved.
//



import UIKit
import HarishFrameworkSwift4
class OrderStatusVC: UIViewController , UITableViewDelegate, UITableViewDataSource, UIGestureRecognizerDelegate , URLSessionDownloadDelegate{
    var arrStatusList = [status_type]()

    var arrtblList = NSMutableArray()
    @IBOutlet var tblView: UITableView!
//    var arrEliment = [String]()
    override func viewDidLoad() {
        super.viewDidLoad()
        self.sideMenuViewController.panGestureEnabled = false

      //  arrStatusList = ["All","Pending","Accepted","Pickup"]
        
//        var arrStatusList1 = [status_type]()
        var status = status_type()
        status.status = "All"
        status.title = "All"
        arrStatusList.append(status)
        status = status_type()
        status.title = "Pending"
        status.status = "Pending"
        arrStatusList.append(status)
        status = status_type()

        status.title = "Accepted"
        status.status = "Accepted"
        arrStatusList.append(status)
        status = status_type()

        status.title = "Pickup"
        status.status = "Pickup"
        arrStatusList.append(status)
     
        status = status_type()
        status.title = "Completed"
        status.status = "Completed"
        arrStatusList.append(status)

        
        self.tblViewStatus.reloadData()
        // } for customer
        /*
         Pending(Pending)
         Accepted(Accepted)
         Driver coming(Driver_coming)
         Processing(Processing)
         Processing(Processing)
         Order Ready(Order_ready)
         Order Ready(Order_ready)
         Dispatch(Dispatch)
         Completed(Completed)*/
        
      /*
         status = status_type()

         status.status = "All"
        status.title = "All"
        arrStatusList1.append(status)
         status = status_type()

        status.title = "Pending"
        status.status = "Pending"
        arrStatusList1.append(status)

         status = status_type()
        status.title = "Accepted"
        status.status = "Accepted"
        arrStatusList1.append(status)

         status = status_type()

        status.title = "Driver coming"
        status.status = "Pickup_driver_assigned"
        arrStatusList1.append(status)
         status = status_type()

        status.title = "Processing"
        status.status = "Picked_by_driver"
        arrStatusList1.append(status)
        

        
         status = status_type()
        status.title = "Processing"
        status.status = "Received_driver_to_vendor"
        arrStatusList1.append(status)
        
         status = status_type()
        status.title = "Order Ready"
        status.status = "Ready_for_dispatch"
        arrStatusList1.append(status)
         status = status_type()

        status.title = "Order Ready"
        status.status = "Drop_driver_assigned"
        arrStatusList1.append(status)
         status = status_type()

        status.title = "Dispatch"
        status.status = "Received_vendor_to_driver"
        arrStatusList1.append(status)
         status = status_type()

        status.title = "Completed"
        status.status = "Received_by_customer"
        arrStatusList1.append(status)
        
*/
      
        /*
         
        (2)
        (3)
        (4)
        (5)
        (6)
        (7)
        (8)
        
        */
        
        
        
        
//       arrStatusList = arrStatusList1//.removeDuplicates1111()
       // let filteredElements = arrStatusList1.fil//removeDuplicates { $0.status == $1.status  }

        // && $0.PropertyTwo == $1.PropertyTwo
//        arrEliment = ["All"]
        
//        print(arrStatusList.removeDuplicates()) // Prints: [2, 4]

        tblViewStatus.delegate = self
        tblViewStatus.dataSource = self
        
        //viewBGPopUP.frame.size.height = CGFloat(arrStatusList.count * 40 + 50)
        tblStatusConstaintHeight.constant = CGFloat(arrStatusList.count * 45 + 50)
        tblViewStatus.isScrollEnabled = false
        
        
  //
    }

    override func viewWillAppear(_ animated: Bool) {
        page = 1
        self.ws_OrderListing()

        self.navigationController?.isNavigationBarHidden = false
        navigationItem.hidesBackButton = false
        navigationController?.navigationBar.shouldRemoveShadow(true)
        setImageNavigation()
    }
    
    @IBAction func actionMenu(_ sender: Any) {
        self.sideMenuViewController.presentRightMenuViewController()
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override func viewWillDisappear(_ animated: Bool) {
        self.title = ""
    }
    
    //MARK:- TABLEVIEW_DELEGATE
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView == tblView{
            return arrtblList.count
        }else{
            return arrStatusList.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if tableView == tblView{
        let cell = tableView.dequeueReusableCell(withIdentifier: "OrderStatusCell", for: indexPath) as! OrderStatusCell
        
        let dict = arrtblList.object(at: indexPath.row) as! NSMutableDictionary
        cell.lblOrderId.text = string(dict, "id")
        //"2018-07-05 09:00:00";
        cell.lblPickup.text = string(dict, "pickup_time").converDate("yyyy-MM-dd HH:mm:ss", "dd E, MMM \nhh:mm a")
        
        cell.lblDropoff.text = string(dict, "dropoff_time").converDate("yyyy-MM-dd HH:mm:ss", "dd E, MMM \nhh:mm a")
        
       let request_status =  string(dict, "request_status")
    
        
        
//        cell.lblStatus.textColor = UIColor.white
//        cell.lblStatus.text = "  " + string(dict, "status_label") + "  "
//
        let  strStatus = string(dict, "request_status")
        cell.lblStatus.text = " "  + strStatus + "   "
        cell.lblStatus.backgroundColor = appColour().getColor(request_status)
        cell.lblStatus.textColor = UIColor.white

        // Pickedup
        if let path = dict.object(forKey: "service_icon") as? String {
            let imgurl =  APPConstants.upload_url + path
            let URL =  NSURL(string: imgurl)
//            print("-url--\(URL)-")
            cell.imgService.sd_setImage(with: URL as URL!, placeholderImage: UIImage(named: "imgpsh_fullsize.png"),  options: SDWebImageOptions.retryFailed)
        }
        
        
        if indexPath.row == (arrtblList.count - 1) {
            if !isDownloading {
                isDownloading = true
                if arrtblList.count % 10 == 0 {
                    page += 1
                    self.ws_OrderListing()
                }
            }
        }
        
        return cell
        }else{
            
            let cell = tableView.dequeueReusableCell(withIdentifier: "OrderListStatusCell", for: indexPath) as! OrderListStatusCell
            let ss = arrStatusList[indexPath.row]
            cell.lblStatus.text = ss.title//.object(at: indexPath.row)
            
            if intIndexSelected == indexPath.row{
                cell.imgStatus.image = UIImage(named: "checked_circular")
                cell.lblStatus.textColor = appColor
            }else{
                cell.imgStatus.image = UIImage(named: "unchecked_circular")
                cell.lblStatus.textColor = UIColor.black
            }
            
            return cell
        }
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if tblView == tableView{
        let dict = arrtblList.object(at: indexPath.row) as! NSMutableDictionary
            
            
            
            if string(dict, "request_status") == "Accepted" {
                let vc = self.storyboard?.instantiateViewController(withIdentifier: "AcceptOrderView")as!  AcceptOrderView

                vc.orderid = string(dict, "id")
                vc.request_id = string(dict, "request_id")
                self.navigationController?.pushViewController(vc, animated: true)
//
                return
            }
            
            guard let service_id = dict.object(forKey: "service_id") as? Int else {
                return
            }
            
            
            
            if service_id == 2 || service_id == 3 {
                
                let vc = self.storyboard?.instantiateViewController(withIdentifier: "DryCleanDetail") as! DryCleanDetail
                vc.orderid = string(dict, "id")
                vc.request_id = string(dict, "request_id")
                self.navigationController?.pushViewController(vc, animated: true)
            }else {
                
                let vc = self.storyboard?.instantiateViewController(withIdentifier: "ServiceDetailListVC") as! ServiceDetailListVC
                vc.orderid = string(dict, "id")
                vc.request_id = string(dict, "request_id")
                
                self.navigationController?.pushViewController(vc, animated: true)

            }
            
            
        }else{
            
            let  strSt = arrStatusList[indexPath.row]
            strStatus = strSt.status
            
            // s(arrStatusList.object(at: indexPath.row) as? String)!
            
            if strSt.status == "All"{
                strStatus = ""
            }
            
            intIndexSelected = indexPath.row
            tblViewStatus.reloadData()
            removeSubViewWithAnimation(viewMain: viewMainStatus, viewPopUP: viewBGPopUP)
            page = 1
            ws_OrderListing()
            self.arrtblList = NSMutableArray()
        }
    }
    
    
    var page = 1
    var isDownloading = false
    /*"
     order_status
     :(Pending/Pickup/Completed/Canceled/Not_accepted/Accepted) for search filter"*/
    func ws_OrderListing() {
        let params = NSMutableDictionary()
        params["page"] = page
        params["per_page"] = "30"
        params["order_status"] = strStatus
        
        Http.instance().json(WebServices.orderslist , params, "POST", ai: true, popup: true, prnt: true, userInfo.Token(), sync: false) { (json, dict, str) in
            
            if json != nil {
                let json1 = json as? NSDictionary
                if number(json1! , "success").boolValue {
                    if let arrr = json1?.object(forKey: "result") as? NSArray {
                        if self.page == 1 {
                            self.arrtblList = arrr.mutableCopy() as! NSMutableArray
                        }else {
                            self.arrtblList.addObjects(from: arrr as! [Any])
                        }
                     /*   for ii in 0 ..< self.arrtblList.count {
                            let dict = self.arrtblList.object(at: ii) as! NSMutableDictionary
                            let  strStatus = string(dict, "request_status")
                          
                           // var arrStatusList1 = [status_type]()
                            let status = status_type()
                            status.status = strStatus
                            status.title = strStatus
                           // arrStatusList1.append(status)
                            
                            self.arrStatusList.append(status)
                            self.arrStatusList =  self.arrStatusList.removeDuplicates1111()
                            
                        }
                        let height = CGFloat(self.arrStatusList.count * 45 + 50)
                        if height > self.view.frame.size.height-100 {
                            self.tblStatusConstaintHeight.constant = self.view.frame.size.height-100

                        }else {
                            self.tblStatusConstaintHeight.constant = height

                        }
                        */
                       // self.tblViewStatus.reloadData()
                        
                        self.isDownloading = false
                        self.tblView.reloadData()
                    }
                }else {
                    self.isDownloading = true
                    self.tblView.reloadData()
                }
                if self.arrtblList.count == 0{
                    self.tblView.displayBackgroundImageWithText(text: string(json1! , "message") , fontStyle: "helvetica", fontSize: 15, imgName: "cloud")
                    self.tblView.reloadData()
                }else{
                    self.tblView.displayBackgroundImageWithText(text: "" , fontStyle: "helvetica", fontSize: 15, imgName: "")
                }
            }
        }
    }
 
    
    
    
    @IBOutlet var tblViewStatus: UITableView!
    @IBOutlet var viewMainStatus: UIView!
    @IBOutlet var viewBGPopUP: UIView!
    
    @IBOutlet var btnFilter: UIButton!
    @IBOutlet var btnClose: UIButton!
    @IBOutlet var tblStatusConstaintHeight: NSLayoutConstraint!
    var intIndexSelected = 0
    var strStatus = ""
    /////=============
    
    @IBAction func btnFilterAction(_ sender: Any) {
        addPopupShow(viewMain: viewMainStatus, viewPopUP: viewBGPopUP)
    }
    
    @IBAction func btnCloseAction(_ sender: Any) {
        
        removeSubViewWithAnimation(viewMain: viewMainStatus, viewPopUP: viewBGPopUP)
    }
    
    //MARK:- FUNCTION FOR POPVIEW
    func addPopupShow(viewMain: UIView, viewPopUP: UIView)  {
        viewMain.frame = self.view.frame
        viewMain.backgroundColor = UIColor.black.withAlphaComponent(0.5)
        self.view.window?.addSubview(viewMain)
        // self.scroll.addSubview(viewMain)
        
        let tap = UITapGestureRecognizer(target: self, action: #selector(self.handleTap(sender:)))
        tap.delegate = (self as UIGestureRecognizerDelegate)
        viewMain.addGestureRecognizer(tap)
        
        viewPopUP.leftAnchor.constraint(equalTo: viewPopUP.leftAnchor, constant: 15).isActive = true
        viewPopUP.rightAnchor.constraint(equalTo: viewPopUP.rightAnchor, constant: -15).isActive = true
        
        viewMain.centerYAnchor.constraint(equalTo: view.centerYAnchor).isActive = true
        viewMain.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        
        self.test(viewTest: viewPopUP)
    }
    
    func test(viewTest: UIView) {
        let orignalT: CGAffineTransform = viewTest.transform
        viewTest.transform = CGAffineTransform.identity.scaledBy(x: 0.0, y: 0.0)
        UIView.animate(withDuration: 0.4, animations: {
            
            viewTest.transform = orignalT
        }, completion:nil)
    }
    
    func removeSubViewWithAnimation(viewMain: UIView, viewPopUP: UIView) {
        let orignalT: CGAffineTransform = viewPopUP.transform
        UIView.animate(withDuration: 0.3, animations: {
            viewPopUP.transform = CGAffineTransform.identity.scaledBy(x: 0.1, y: 0.1)
        }, completion: {(sucess) in
            viewMain.removeFromSuperview()
            viewPopUP.transform = orignalT
        })
    }
    
    @objc func handleTap(sender: UITapGestureRecognizer? = nil) {
        //viewPopup.removeFromSuperview()
        removeSubViewWithAnimation(viewMain: viewMainStatus, viewPopUP: viewBGPopUP)
    }
    
    func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldReceive touch: UITouch) -> Bool {
        if viewMainStatus.bounds.contains(touch.location(in: viewBGPopUP)) {
            return false
        }
        
        return true
    }

    
    
    
    
    var fileNameR = ""
    func downloadFile(url: String ) { //to download the media file in document directory.
     //    downloadFile(url: "http://youritteam.org/wowffer/public/category/20180814163600.svg")
        if let audioUrl = URL(string: url) {
            fileNameR = audioUrl.lastPathComponent
            print("download_url-\(url)-----fileName-->\(fileNameR)")
        //    let documentsDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
            // choose a name for your image
       //     let fileName = fileNameR
            // create the destination file url to save your image
          //  let fileURL = documentsDirectory.appendingPathComponent(fileName)
            // get your UIImage jpeg data representation and check if the destination file url already exists
            
            
            // then lets create your document folder url
            let documentsDirectoryURL =  FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
            
            // lets create your destination file url
            let destinationUrl = documentsDirectoryURL.appendingPathComponent(fileNameR)
            
            
            print(destinationUrl)
            // to check if it exists before downloading it
            if FileManager.default.fileExists(atPath: destinationUrl.path) {
                
                print("The file already exists at path")
                self.playDownload(fileName: self.fileNameR)
              
            } else {
                
                URLSession.shared.dataTask(with: audioUrl) { data, response, error in
                    guard
                        let httpURLResponse = response as? HTTPURLResponse, httpURLResponse.statusCode == 200,
                        let mimeType = response?.mimeType, mimeType.hasPrefix("image"),
                        let data = data, error == nil
                        //, let image = UIImage(data: data)
                        else { return }
                    do {
                        // writes the image data to disk
                        try data.write(to: destinationUrl)
                        print("file saved")
                    } catch {
                        print("error saving file:", error)
                    }
                    
                    /*
                     if !FileManager.default.fileExists(atPath: fileURL.path) {
                     }else {
                     print("already file saved")
                     }
                     */
                    }.resume()
                
                
                
                // you can use NSURLSession.sharedSession to download the data asynchronously
                
             /*
                 let config = URLSessionConfiguration.default
                let session = URLSession(configuration: config, delegate: self, delegateQueue: nil)
                
                // Don't specify a completion handler here or the delegate won't be called
                let task = session.downloadTask(with: audioUrl)
                task.resume()*/
            }
        }
    }
    
    
    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didWriteData bytesWritten: Int64, totalBytesWritten: Int64, totalBytesExpectedToWrite: Int64) {
        
        let progress = Float(totalBytesWritten) / Float(totalBytesExpectedToWrite)
        
        print("download task did write data")
        print("progress -\(progress)-")
        OperationQueue.main.addOperation {
            // self.progressDownloadIndicator.progress = progress
        }
    }
    
    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didFinishDownloadingTo location: URL) {
        
        print("Dowloading is finished.")
        
        //Http.alert("", "Dowloading is finished.")
        
        do {
            
            let documentsDirectoryURL =  FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
            //
            let destinationUrl = documentsDirectoryURL.appendingPathComponent(fileNameR)
            print(destinationUrl)
            
            // after downloading your file you need to move it to your destination url
            try FileManager.default.moveItem(at: location, to: destinationUrl)
            print("File moved to documents folder")
            
            //to play file instantly after downloading.
            
            OperationQueue.main.addOperation {
                self.playDownload(fileName: self.fileNameR)
            }
            
        } catch let error as NSError {
            print(error.localizedDescription)
        }
    }
    func playDownload(fileName: String) {
        
        // then lets create your document folder url
        let documentsDirectoryURL =  FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        
        // lets create your destination file url
        
        let destinationUrl = documentsDirectoryURL.appendingPathComponent(fileName)
        //let url = Bundle.main.url(forResource: destinationUrl, withExtension: "mp3")!
        print(destinationUrl)
        
       // if let daata  = Data(contentsOf: destinationUrl) {}

      /*
         do {
           let daata = try Data(contentsOf: destinationUrl)
            
        } catch  {
        
        }
        */
        //        moviePlayer = MPMoviePlayerController(contentURL: destinationUrl)
    }
}
//extension SomeType: UIWebView, URLSessionDownloadDelegate {
 //    implementation of protocol requirements goes here
//}



class OrderStatusCell: UITableViewCell {
    
    @IBOutlet var imgService: UIImageView!
    @IBOutlet var lblOrderId: UILabel!
    @IBOutlet var lblPickup: UILabel!
    @IBOutlet var lblDropoff: UILabel!
    @IBOutlet var lblStatus: Label!
    
}
class OrderListStatusCell: UITableViewCell {
    
    @IBOutlet var imgStatus: UIImageView!
    @IBOutlet var lblStatus: UILabel!
    
    
}


extension Array where Element:Equatable {
    func removeDuplicates() -> [Element] {
        var result = [Element]()
        
        for value in self {
            if result.contains(value) == false {
                result.append(value)
            }
        }
        return result
    }
    func removeDuplicates1111() -> [status_type] {
        var result = [status_type]()
        
        for value in self {
            if result.contains(value as! status_type) == false {
                result.append(value as! status_type)
            }
        }
        return result
    }
    
    
    func callmethod(){
        
     /*   let fileManager = NSFileManager.defaultManager()
        let paths = (NSSearchPathForDirectoriesInDomains(.DocumentDirectory, .UserDomainMask, true)[0] as NSString).stringByAppendingPathComponent("apple.jpg")
        let image = UIImage(named: "apple.jpg")
        print(paths)
        let imageData = UIImageJPEGRepresentation(image!, 0.5)
        fileManager.createFileAtPath(paths as String, contents: imageData, attributes: nil)
*/
        
        
    }
    
    
    
    
    
    
    
    
}


class status_type: NSObject {
    var title = ""
    var status = ""
}
