//
//  NotificationListVC.swift
//  WashittoVendor
//
//  Created by Himanshu on 06/07/18.
//  Copyright © 2018 Himanshu pal. All rights reserved.
//

import UIKit
import HarishFrameworkSwift4
class NotificationListVC: UIViewController , UITableViewDelegate, UITableViewDataSource,AlertDelegate{

    var arrtblList = NSMutableArray()
    @IBOutlet var tblView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        page = 1
        // Do any additional setup after loading the view.
    }
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.isNavigationBarHidden = false
        navigationItem.hidesBackButton = false
        navigationController?.navigationBar.shouldRemoveShadow(true)
        self.setImageNavigation()
        self.sideMenuViewController.panGestureEnabled = false
        self.ws_Notificationlist()
    }
    

    @IBAction func actionMenu(_ sender: Any) {
        self.sideMenuViewController.presentRightMenuViewController()
    }
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override func viewWillDisappear(_ animated: Bool) {
        self.title = ""
    }
    
    
    //MARK:- TABLEVIEW_DELEGATE
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrtblList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "NotificationListCell", for: indexPath) as! NotificationListCell
        
        let dict = arrtblList.object(at: indexPath.row) as! NSMutableDictionary
        
      cell.lblTitle.text = string(dict, "title")
        cell.lblDiscription.text = string(dict, "message")
         cell.lblTime.text = " " + timeAgoSinceDateInShort(date: stringToDateWithFormat(strDate: string(dict, "created_at"),dateFormat: "yyyy-MM-dd HH:mm:ss") , numericDates: true) + "  "
        
        if indexPath.row == (arrtblList.count - 1) {
            if !isDownloading {
                isDownloading = true
                if arrtblList.count % 10 == 0 {
                    page += 1
                    self.ws_Notificationlist()
                }
            }
        }
        
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let dict = arrtblList.object(at: indexPath.row) as! NSMutableDictionary
        print(dict)
        
        
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ServiceDetailListVC") as! ServiceDetailListVC
        vc.orderid = string(dict, "order_id")
//
        
        
        vc.request_id = string(dict, "request_id")
        
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    
    
    var page = 1
    var isDownloading = false
 
    func ws_Notificationlist() {
        let params = NSMutableDictionary()
        params["page"] = page
        params["per_page"] = "30"
        
        Http.instance().json(WebServices.notificationlist , params, "POST", ai: true, popup: true, prnt: true, userInfo.Token(), sync: false) { (json, dict, str) in
            
            if json != nil {
                let json1 = json as? NSDictionary
                if number(json1! , "success").boolValue {
                    if let arrr = json1?.object(forKey: "result") as? NSArray {
                        if self.page == 1 {
                            self.arrtblList = arrr.mutableCopy() as! NSMutableArray
                        }else {
                            self.arrtblList.addObjects(from: arrr as! [Any])
                        }
                        self.isDownloading = false
                        self.tblView.reloadData()
                    }
                }else {
                    self.isDownloading = true
                    self.tblView.reloadData()
                }
                if self.arrtblList.count == 0{
                    self.tblView.displayBackgroundImageWithText(text: string(json1! , "message") , fontStyle: "helvetica", fontSize: 15, imgName: "cloud")
                    self.tblView.reloadData()
                }else{
                    self.tblView.displayBackgroundImageWithText(text: "" , fontStyle: "helvetica", fontSize: 15, imgName: "")
                }
            }
        }
    }
    
    
    func ws_DeleteAllNotification() {
        
        
        Http.instance().json(WebServices.notificationclear, nil, "POST", ai: true, popup: true, prnt: true, userInfo.Token(), sync: false) { (json, dict, str) in
            
            if json != nil {
                let json1 = json as? NSDictionary
                if number(json1! , "success").boolValue {
                    self.arrtblList = NSMutableArray()
                    self.tblView.displayBackgroundImageWithText(text: string(json1! , "message") , fontStyle: "helvetica", fontSize: 15, imgName: "cloud")
                    self.tblView.reloadData()
                }else {
                    Http.alert("", string(json1! , "message"))
                }
            }
        }
    }
    
    @IBAction func actionDeleteNotifi(_ sender: Any) {
        if arrtblList.count > 0 {
           Http.alert("", "Sure to delete?", [self,"Yes","No"])
        }else{
          Http.alert("", "Notification not found.")
        }
        
        
        
    }
    func alertZero () {
        ws_DeleteAllNotification()
    }
    
    func alertOne () {
    
    }

}

class NotificationListCell: UITableViewCell {
    
    @IBOutlet var lblTitle: UILabel!
    @IBOutlet var lblDiscription: UILabel!
    @IBOutlet var lblTime: UILabel!
    
}


