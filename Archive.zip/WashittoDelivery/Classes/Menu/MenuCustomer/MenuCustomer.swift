//
//  MenuCustomer.swift
//  Pallardy Place
//
//  Created by Kamal on 04/12/17.
//  Copyright © 2017 Anil. All rights reserved.
//

import UIKit
import HarishFrameworkSwift4

import AudioToolbox
import UserNotifications
//
class MenuCustomer: UIViewController, UITableViewDelegate, UITableViewDataSource {

    
    
    //MARK: OUTLETS
    @IBOutlet var tblView11: UITableView!
    @IBOutlet var lblName: UILabel!
    
    //MARK: VARIABLES
    let arrMenu = NSMutableArray()
    
    @IBOutlet var imgUser: ImageView!
    //MARK: LIFECYCLE
    override func viewDidLoad() {
        super.viewDidLoad()
        NotificationCenter.default.removeObserver(self, name: Notification.Name("ReceiveRemoteNotificationNew"), object: nil)
        
        NotificationCenter.default.addObserver(self, selector: #selector(self.methodRemoteNotification(notification:)
            ), name: Notification.Name("ReceiveRemoteNotificationNew"), object: nil)
        
        

//        SocketIOManagerMHN.sharedInstance.socketHandler()
        
          setNeedsStatusBarAppearanceUpdate()
        createMenu()
      
    }
  
    
    override func viewWillAppear(_ animated: Bool) {
        
    
        userDetail()
        
//        tblView.reloadData()
    }
    @objc func methodRemoteNotification(notification: NSNotification) {
        var userInfoCurrent = NSDictionary()
        if kappDelegate.strBGNotification == "neeleshwari" {
            kappDelegate.strBGNotification = ""
            userInfoCurrent = kappDelegate.Sourabhnotification
            print("------------------->Appkilled")
        }else{
            print("------------------->AppNotkilled")
            userInfoCurrent = notification.userInfo! as NSDictionary
        }
        if let userdetail:NSDictionary = userInfo.getLoginInfo()  {
            print(userdetail)
            if string(userdetail, "is_vibration_enable") == "1" {
                viberation()
                
            }
            if string(userdetail, "is_sound_enable") == "1"  {
                playSoundAndVibrateForNotification()
                
            }
            
            
        }
        
        print("userInfoCurrent--\(userInfoCurrent)-")
        
        
        let dictAps = userInfoCurrent.object(forKey: "aps") as! NSDictionary
        let dictAlert = dictAps.object(forKey: "alert") as! NSDictionary
        var service_id = 0
        if let serviceid = userInfoCurrent.object(forKey: "service_id") as? String {
            if let idd = Int(serviceid) {
                service_id = idd

            }
        }
        if string(userInfoCurrent, "type") == "NEW_DELIVERY_REQUEST"{
            kappDelegate.comefromNoti = "yes"
            kappDelegate.order_id =  string(userInfoCurrent, "order_id")
            kappDelegate.request_id =  string(userInfoCurrent, "request_id")
           
            let alert = UIAlertController(title: string(dictAlert, "title"), message: string(dictAlert, "body"), preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "CANCEL", style: .default, handler: {(void) in
                
            }))
            
            alert.addAction(UIAlertAction(title: "VIEW", style: .default, handler: {(void) in
            
              //  let vc = self.storyboard?.instantiateViewController(withIdentifier: "AcceptOrderView") as!  AcceptOrderView
                
                self.sideMenuViewController.setContentViewController(self.storyboard?.instantiateViewController(withIdentifier: "AcceptOrderNAV"), animated: true)

              //  self.present(vc, animated: true, completion: nil)// navigationController?.pushViewController(vc, animated: true)
                

                
//                if service_id == 2 || service_id == 3 {
//                    self.sideMenuViewController.setContentViewController(self.storyboard?.instantiateViewController(withIdentifier: "Dry_Clean"), animated: true)
//
//                }else {
//                    self.sideMenuViewController.setContentViewController(self.storyboard?.instantiateViewController(withIdentifier: "detail_nav"), animated: true)
//
//                }
            }))
            if UIDevice.current.userInterfaceIdiom == .pad {
                if let popoverController = alert.popoverPresentationController {
                    popoverController.sourceView = self.view
                    popoverController.sourceRect = self.view.bounds
                }
            }
            self.present(alert, animated: true, completion: nil)
        }else if string(userInfoCurrent, "type") == "ORDER_RECEIVED_BY_VENDOR"{
            kappDelegate.comefromNoti = "yes"
            kappDelegate.order_id =  string(userInfoCurrent, "order_id")
            kappDelegate.request_id =  string(userInfoCurrent, "request_id")
            
            let alert = UIAlertController(title: string(dictAlert, "title"), message: string(dictAlert, "body"), preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "CANCEL", style: .default, handler: {(void) in
                
            }))
            
            alert.addAction(UIAlertAction(title: "VIEW", style: .default, handler: {(void) in
                
                if service_id == 2 || service_id == 3 {
                    self.sideMenuViewController.setContentViewController(self.storyboard?.instantiateViewController(withIdentifier: "Dry_Clean"), animated: true)
                    
                }else {
                    self.sideMenuViewController.setContentViewController(self.storyboard?.instantiateViewController(withIdentifier: "detail_nav"), animated: true)
                      }
            }))
            if UIDevice.current.userInterfaceIdiom == .pad {
                if let popoverController = alert.popoverPresentationController {
                    popoverController.sourceView = self.view
                    popoverController.sourceRect = self.view.bounds
                }
            }
            self.present(alert, animated: true, completion: nil)
        }
        
        
    }
    
    
    
    
    func playSoundAndVibrateForNotification() {
        var soundID:SystemSoundID = 0
        let soundFile: String = Bundle.main.path(forResource: "phonering", ofType: "mp3")!
        AudioServicesCreateSystemSoundID(NSURL.fileURL(withPath: soundFile) as CFURL, &soundID)

        AudioServicesPlaySystemSound(soundID)

    }
    
    func viberation(){
        AudioServicesPlayAlertSound(kSystemSoundID_Vibrate)
    }
    override func viewDidAppear(_ animated: Bool) {
    }
    
    override func viewWillDisappear(_ animated: Bool) {
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    func userDetail(){
        if let userdetail:NSDictionary = userInfo.getLoginInfo()  {
            print("userdetail ======>",userdetail)
            if let firstname = userdetail.object(forKey: "first_name") as? String {
                let lastname = userdetail.object(forKey: "last_name") as! String
                self.lblName.text = firstname + " " + lastname
            }
            
            if let path = userdetail.object(forKey: "profile_image") as? String {
                let imgurl = APPConstants.upload_url + path
                let URL =  NSURL(string: imgurl)
                self.imgUser.sd_setImage(with: URL as URL!, placeholderImage: UIImage(named: "noimage.png"),  options: SDWebImageOptions.retryFailed)
            }else{
                self.imgUser.image = UIImage(named : "noimage.png")
            }
            
        }
    }
    //MARK: FUNCTIONS  //"home_menu"
    func createMenu() {
        
//        arrMenu.add(NSMutableDictionary(dictionary:["title": "Home", "status": "1", "imgTitle": "services_icon"]))
        arrMenu.add(NSMutableDictionary(dictionary:["title": "Orders", "status": "0", "imgTitle": "orders_icon"]))
        arrMenu.add(NSMutableDictionary(dictionary:["title": "Profile", "status": "0", "imgTitle": "user_icon"]))
        arrMenu.add(NSMutableDictionary(dictionary:["title": "Settings", "status": "0", "imgTitle": "settings_icon"]))
       // arrMenu.add(getMutable(["title": "Settings", "status": "0", "imgTitle": ""]))
        arrMenu.add(NSMutableDictionary(dictionary:["title": "Notifications", "status": "0", "imgTitle": "notification"]))
        arrMenu.add(NSMutableDictionary(dictionary:["title": "Logout", "status": "0", "imgTitle": "logout"]))
        
        
//        tblView11.reloadData()
    }
    
    func getMutable(_ dt:Dictionary<String, Any>) -> NSMutableDictionary {
        return NSMutableDictionary(dictionary: dt)
    }
    
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    //MARK: TABLEVIEW DELEGATE AND DATASOURCE.
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrMenu.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "MenuCustomerCell") as! MenuCustomerCell
        
       let dict = arrMenu.object(at: indexPath.row) as! NSMutableDictionary
        cell.lblTitle.text = string(dict, "title")
           cell.imgIcon.image = UIImage(named: string(dict, "imgTitle"))
        
        cell.backgroundColor = UIColor.clear
        
        if string(dict, "status") == "1" {
            //   cell.imgIcon.image = cell.imgIcon.image!.withRenderingMode(.alwaysTemplate)
            //   cell.imgIcon.tintColor = UIColor.white
            cell.backgroundColor = appLightGray
            //  cell.lblTitle.textColor = appColor
            cell.lblYellow.isHidden = false
        } else {
            cell.backgroundColor = UIColor.white
            // cell.viewBg.backgroundColor = UIColor.white
            // cell.imgIcon.image = cell.imgIcon.image!.withRenderingMode(.alwaysTemplate)
            // cell.imgIcon.tintColor = UIColor.black
            //  cell.lblTitle.textColor = UIColor.black
            cell.lblYellow.isHidden = true
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        for i in 0..<arrMenu.count {
            let dictMenu =  arrMenu.object(at: i) as! NSMutableDictionary
            dictMenu.setValue("0", forKey: "status")
            arrMenu.replaceObject(at: i, with: dictMenu)
        }
        
        let dict = arrMenu.object(at: indexPath.row) as! NSMutableDictionary
        dict.setValue("1", forKey: "status")
        arrMenu.replaceObject(at: indexPath.row, with: dict)
        tblView11.reloadData()
        
        //Push View Controller
        if string(dict, "title") == "Home" { //1
            Http.alert("", "Work in process")

//            self.sideMenuViewController.setContentViewController(self.storyboard?.instantiateViewController(withIdentifier: "home_nav"), animated: true)
//            self.sideMenuViewController.hideViewController()
            
        } else if string(dict, "title") == "Orders" {  //2
//            Http.alert("", "Work in process")

          
//            self.sideMenuViewController.setContentViewController(self.storyboard?.instantiateViewController(withIdentifier: "Track"), animated: true)
            
            self.sideMenuViewController.setContentViewController(self.storyboard?.instantiateViewController(withIdentifier: "order_nav"), animated: true)
            self.sideMenuViewController.hideViewController()
            
        } else if string(dict, "title") == "Profile" { //3
            self.sideMenuViewController.setContentViewController(self.storyboard?.instantiateViewController(withIdentifier: "profile_nav"), animated: true)
            self.sideMenuViewController.hideViewController()
            
        } else if string(dict, "title") == "Settings" { // 4
//            Http.alert("", "Work in process")

        self.sideMenuViewController.setContentViewController(self.storyboard?.instantiateViewController(withIdentifier: "setting_nav"), animated: true)
            self.sideMenuViewController.hideViewController()
            
        }  else if string(dict, "title") == "Notifications" { // 6
//            Http.alert("", "Work in process")

           self.sideMenuViewController.setContentViewController(self.storyboard?.instantiateViewController(withIdentifier: "notif_nav"), animated: true)
            self.sideMenuViewController.hideViewController()
            
        }  else if string(dict, "title") == "Logout" { // 7
            self.sideMenuViewController.hideViewController()
            let alert = UIAlertController(title: "Confirmation", message: "Are you sure, you want to logout?", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: {(void) in
                self.logout()
            }))
            alert.addAction(UIAlertAction(title: "CANCEL", style: .default, handler: {(void) in
            }))
            if UIDevice.current.userInterfaceIdiom == .pad {
                if let popoverController = alert.popoverPresentationController {
                    popoverController.sourceView = self.view
                    popoverController.sourceRect = self.view.bounds
                }
            }
            self.present(alert, animated: true, completion: nil)
        }
    }
    
    func logout() {
        ws_Logout()
         let defaults = UserDefaults.standard
//        defaults.removeObject(forKey: "email")
//        defaults.removeObject(forKey: "pass")
        defaults.removeObject(forKey: "is_login")
        defaults.synchronize()
        
   

     
//        self.navigationController?.popToRootViewController(animated: true)
//        self.navigationController?.viewControllers = []
//        let vc = self.storyboard?.instantiateViewController(withIdentifier: "WelcomeVC")  as? WelcomeVC
        
//        kappDelegate.window?.rootViewController = vc
        
//        self.sideMenuViewController.hideViewController()
        
  
        userInfo.removeAllUserDefaultOBJ()
    }
    
    @IBAction func actionProfile(_ sender: Any) {
        self.sideMenuViewController.setContentViewController(self.storyboard?.instantiateViewController(withIdentifier: "profile_nav"), animated: true)
        self.sideMenuViewController.hideViewController()
        
    }
    var Notiftype = ""
    var NotifId = ""
    
 
 
    func ws_Logout(){
        
        Http.instance().json(WebServices.logout, nil, "GET", ai: true, popup: true, prnt: true, userInfo.Token(), sync: false) { (json, dict, str) in
            
            if json != nil {
                let json1 = json as? NSDictionary
                if number(json1! , "success").boolValue {
                    userInfo.removeAllUserDefaultOBJ()
                    
                    
                    /* self.navigationController?.viewControllers = []
                     let vc = self.storyboard?.instantiateViewController(withIdentifier: "SigninVC")
                     kappDelegate.window?.rootViewController = vc
                     
                     self.sideMenuViewController.hideViewController()*/
                    
                    //                    if let result = json1?["result"] as? NSDictionary {
                    //
                    //                    }
                }else {
                    Http.alert("", string(json1! , "message"))
                }
            }
            self.sideMenuViewController.setContentViewController(self.storyboard?.instantiateViewController(withIdentifier: "main11"), animated: true)
            self.sideMenuViewController.hideViewController()

        }
    }
    
  
    
    
    
    
}//Class End.

