//
//  MenuCustomerCell.swift
//  Pallardy Place
//
//  Created by Kamal on 04/12/17.
//  Copyright © 2017 Anil. All rights reserved.
//

import UIKit

class MenuCustomerCell: UITableViewCell {

    @IBOutlet var lblTitle: UILabel!
    @IBOutlet var imgIcon: UIImageView!
     @IBOutlet var lblYellow: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        // Configure the view for the selected state
    }
}
