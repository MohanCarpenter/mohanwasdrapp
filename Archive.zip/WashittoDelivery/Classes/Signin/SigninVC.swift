//
//  SigninVC.swift
//  Washitto
//
//  Created by Himanshu on 13/06/18.
//  Copyright © 2018 Himanshu. All rights reserved.
//

import UIKit
import FacebookLogin
import FacebookCore
import FBSDKLoginKit
import FacebookShare
import GoogleSignIn
import Google
import HarishFrameworkSwift4

class SigninVC: UIViewController , GIDSignInUIDelegate, GIDSignInDelegate, UITextFieldDelegate {
    
    @IBOutlet var tfPassword: TextField!
    @IBOutlet var lblPrivacyPolicy: UILabel!
    @IBOutlet var btnFacebook: Button!
    @IBOutlet var btnGoogle: Button!
    @IBOutlet var tfPhoneNo: TextField!
    @IBOutlet var scrlView: UIScrollView!
    @IBOutlet var imgRemember: UIImageView!
    var is_remamber = true
    override func viewDidLoad() {
        super.viewDidLoad()
         self.registerForKeyboardNotifications()
        btnFacebook.setImage(UIImage.imageWithImage(image: UIImage(named: "facebook.png")!, scaledToSize: CGSize(width: 10, height: 25)), for: .normal)
        btnGoogle.setImage(UIImage.imageWithImage(image: UIImage(named: "google.png")!, scaledToSize: CGSize(width: 25, height: 25)), for: .normal)
      /*
        let myString:NSString = "By joining you agree to our Terms and our Privacy Policy"
        let myMutableString = NSMutableAttributedString(string:myString as String)
        // let  myMutableString = NSMutableAttributedString(string: myString as String, attributes: [NSAttributedStringKey.font:UIFont(name: "VarelaRound-Regular 12.0", size: 12.0)!])
       
        myMutableString.addAttribute(NSAttributedStringKey.foregroundColor, value: UIColor.orange, range: NSRange(location:28,length:5))
        
        myMutableString.addAttribute(NSAttributedStringKey.foregroundColor, value: UIColor.orange, range: NSRange(location:42,length:7))
        
        myMutableString.addAttribute(NSAttributedStringKey.foregroundColor, value: UIColor.orange, range: NSRange(location:50,length:6))
        */
        
        lblPrivacyPolicy.text = "Remember me"// .attributedText = myMutableString
        imgRemember.image = UIImage(named: "remember_meNo.png")
        is_remamber = false
        let userIDPass = getEmailPass()
        
        if ((userIDPass.0 != nil)  && (userIDPass.1 != nil)  && userIDPass.2!) {
            if userIDPass.2! {
                is_remamber = true
                self.tfPhoneNo.text! = userIDPass.0!
                self.tfPassword.text! = userIDPass.1!
                imgRemember.image = UIImage(named: "remember_meYes.png")

            }
        }
       
//       self.tfPhoneNo.text! =  "mohan.kavyasoftech@gmail.com"
//
//            self.tfPassword.text = "Kavya.indore"

        
        
        
        
        
    }
    override func viewWillAppear(_ animated: Bool) {
        self.title = ""
//        tfPhoneNo.text = "mohan.kavyasoftech@gmail.com"
//        tfPassword.text = "qwerty"
//        self.navigationController?.isNavigationBarHidden = false
        navigationItem.hidesBackButton = true
        navigationController?.navigationBar.shouldRemoveShadow(true)
        
        
    }
    override func viewWillDisappear(_ animated: Bool) {
        self.title = ""
         deregisterFromKeyboardNotifications()
         stopActivityI()
    }
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    @IBAction func actionGoogle(_ sender: Any) {
        kappDelegate.social = "GOOGLE"
        googleLogin ()
    }
    
    @IBAction func actionFacebook(_ sender: Any) {
        kappDelegate.social = "FACEBOOK"
        fbLogin ()
    }
    
    @IBAction func actionRememberMe(_ sender: Any) {
        if is_remamber {
            
            imgRemember.image = UIImage(named: "remember_me.png")

            
        }else {
            imgRemember.image = UIImage(named: "remember_meYes.png")

        }
        is_remamber = !is_remamber
    }
    
    /***************************** Facebook  ******************************/
    
    func fbLogin () {
        
        let fbLoginManager : FBSDKLoginManager = FBSDKLoginManager()
        
        fbLoginManager.logOut()
        
        fbLoginManager.logIn(withReadPermissions: ["email"], from: self) { (result, error) in
            if (error == nil) {
                
                if ((FBSDKAccessToken.current()) != nil) {
                    
                    Http.startActivityIndicator()
                    
                    FBSDKGraphRequest(graphPath: "me", parameters: ["fields": "id, name, first_name, last_name, picture.type(large), email"]).start(completionHandler: { (connection, result, error) -> Void in
                        if (error == nil) {
                            if let dt = result as? NSDictionary {
                                print(dt)
                                let params = NSMutableDictionary()
                                params["first_name"] = dt["first_name"]
                                params["last_name"] = dt["last_name"]
                                // params["email"] = ""
                                params["phone_number"] = ""
                                params["password"] = ""
                                params["role"] =  "customer"
                                params["device_name"] = UIDevice.current.modelName
                                params["imei"] =    APPConstants.getDeviceId()
                                params["apns_id"] =   kappDelegate.apns
                                params["device_type"] = APPConstants.deviceType
                                params["modal_no"] = UIDevice.current.model
                                params["os_version"] =  UIDevice.current.systemVersion
                                params["social_id"] = dt["id"]
                                params["social_type"] = "facebook"
                                let defaults = UserDefaults.standard
                                if  let notificationid = defaults.object(forKey: "firebasetoken") {
                                    params["notification_id"] =   ("\(notificationid)")
                                }else{
                                    params["notification_id"] = "123"
                                }
                                
                                /*  md["first_name"] = dt["first_name"]
                                 md["last_name"] = dt["last_name"]
                                 md["social_id"] = dt["id"]
                                 md["email"] = dt["email"]
                                 md["username"] = dt["email"]
                                 md["login_type"] = "facebook"
                                 // md["device_id"] = PredefinedConstants.userDeviceId
                                 // md["device_type"] = PredefinedConstants.deviceType
                                 md["notification_id"] = "123"
                                 md["lang"] = "en"
                                 md["app_version"] = "1.0"
                                 
                                 
                                 
                                 var url:String? = nil
                                 
                                 if let picture = dt["picture"] as? NSDictionary {
                                 if let data = picture["data"] as? NSDictionary {
                                 if let uurl = data["url"] as? String {
                                 url = uurl
                                 }
                                 }
                                 }
                                 
                                 if url == nil {
                                 self.socialLogin(md)
                                 } else {
                                 md["social_dp"] = url!
                                 self.socialLogin(md)
                                 }*/
                                print(params)//Print FB User Details
                                self.socialLogin(params)
                            } else {
                                Http.startActivityIndicator()
                            }
                        } else {
                            Http.startActivityIndicator()
                        }
                    })
                } else {
                    self.stopActivityI()
                }
            }
        }
    }
    
    
    
    //MARK: WS_LOGIN
    
    func socialLogin (_ params:NSMutableDictionary) {
        Http.instance().json(WebServices.login, params, "POST", ai: true, popup: true, prnt: true, sync: false) { (json, dict, str) in
            
            if json != nil {
                let json1 = json as? NSDictionary
                if number(json1! , "success").boolValue {
                    if let result = json1?["result"] as? NSDictionary {
                      //  Http.alert("", string(json1! , "message"))
                        
                        if let user = json1?.object(forKey: "result") as? NSDictionary {
                            userInfo.saveLoginInfo(user)
                        }
                        
                        if let token = result.object(forKey: "token") as? String {
                            userInfo.savetoken(token)
                        }
                       
                        
                        if string(result, "is_phone_verified") == "0" && string(result, "phone_number") == "" && string(result, "temp_phone_number") == ""{
                            let vc = self.storyboard?.instantiateViewController(withIdentifier: "ChangeNumberVC") as! ChangeNumberVC
                            self.navigationController?.pushViewController(vc, animated: true)
                            
                            
                        }else if string(result, "is_phone_verified") == "0" && string(result, "phone_number") != "" && string(result, "temp_phone_number") != "" {
                            
                            let vc = self.storyboard?.instantiateViewController(withIdentifier: "VerifyNumberVC") as! VerifyNumberVC
                            vc.mobileNumber = string(result, "temp_phone_number")
                            self.navigationController?.pushViewController(vc, animated: true)
                        }
                        else if string(result, "is_mail_verified") == "0" && string(result, "email") == "" {
                            let vc = self.storyboard?.instantiateViewController(withIdentifier: "AddEmailVC") as! AddEmailVC
                            self.navigationController?.pushViewController(vc, animated: true)
                            
                        }else if string(result, "is_mail_verified") == "0" && string(result, "email") != "" {
                            let vc = self.storyboard?.instantiateViewController(withIdentifier: "VerifyEmailVC") as! VerifyEmailVC
                            vc.myemail = string(result, "email")
                            self.navigationController?.pushViewController(vc, animated: true)
                            
                        }
                        else{
                            self.navigationController?.viewControllers = []
                            let vc = self.storyboard?.instantiateViewController(withIdentifier: "RootViewCustomer") as! RootViewCustomer
                            kappDelegate.window?.rootViewController = vc
                        }
                        
                        
                        
                    }
                }else {

                    if string(json1!, "is_new_user") == "1" {
                        let vc = self.storyboard?.instantiateViewController(withIdentifier: "SignupVC") as! SignupVC
                        self.navigationController?.pushViewController(vc, animated: true)
                    }
                    Http.alert("", string(json1! , "message"))
                    
                }
                
            }
        }
    }
    
    
    func googleLogin () {
        GIDSignIn.sharedInstance().delegate = self
        GIDSignIn.sharedInstance().uiDelegate = self
        GIDSignIn.sharedInstance()?.signIn()
    }
    
    public func sign(_ signIn: GIDSignIn!, didSignInFor user: GIDGoogleUser!, withError error: Error!) {
        if (error == nil) {
            Http.startActivityIndicator()
          /*
            let userId = user.userID
            //let fullName = user.profile.name
            let givenName = user.profile.givenName
            let familyName = user.profile.familyName
            let email = user.profile.email*/
            
            let params = NSMutableDictionary()
            params["first_name"] = user.profile.givenName
            params["last_name"] = user.profile.familyName
            // params["email"] = ""
            params["phone_number"] = ""
            params["password"] = ""
            params["role"] =  "delivery"
            params["device_name"] = UIDevice.current.modelName
            params["imei"] =    APPConstants.getDeviceId()
            params["apns_id"] =   kappDelegate.apns
            params["device_type"] = APPConstants.deviceType
            params["modal_no"] = UIDevice.current.model
            params["os_version"] =  UIDevice.current.systemVersion
            params["social_id"] = user.userID
            params["social_type"] = "google"
            let defaults = UserDefaults.standard
            if  let notificationid = defaults.object(forKey: "firebasetoken") {
                params["notification_id"] =   ("\(notificationid)")
            }else{
                params["notification_id"] = "123"
            }
            
            self.socialLogin(params)
            
       //     var url:String? = nil
            
            /* if user.profile.hasImage {
             let uurl = user.profile.imageURL(withDimension: 120)
             url = uurl?.absoluteString
             }
             
             if url == nil {
             self.socialLogin(params)
             } else {
             md["social_dp"] = url!
             self.socialLogin(md)
             }*/
        } else {
            print("1 sign error-\(error.localizedDescription)")
            stopActivityI()
        }
    }
    
    func sign(inWillDispatch signIn: GIDSignIn!, error: Error!) {
        if error != nil {
            Http.stopActivityIndicator()
        }
    }
    
    // Present a view that prompts the user to sign in with Google
    func sign(_ signIn: GIDSignIn!, present viewController: UIViewController!) {
        self.present(viewController, animated: true, completion: nil)
    }
    
    // Dismiss the "Sign in with Google" view
    func sign(_ signIn: GIDSignIn!, dismiss viewController: UIViewController!) {
        self.dismiss(animated: true, completion: nil)
        
        Http.stopActivityIndicator()
    }
    
    
    //MARK: FUNCTIONS.
    
    func stopActivityI () {
        Http.stopActivityIndicator()
        Http.stopActivityIndicator()
    }
    
    
    @IBAction func actionSignUp(_ sender: Any) {
        
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "SignupVC") as! SignupVC
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    override func viewDidDisappear(_ animated: Bool) {
        stopActivityI()
    }
    @IBAction func actionSignin(_ sender: Any) {
//        self.scrlView.setContentOffset(CGPoint(x: 0, y: 0), animated: true)
        self.view.endEditing(true)
        if let str = self.checkValidation() {
            Http.alert("", str)
            
        } else {
            ws_Signin()
            
        }
        
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        if (textField.frame.origin.y >= 200) {
            scrlView.setContentOffset(CGPoint(x: 0, y: CGFloat(Int(textField.frame.origin.y - 200))) , animated: true)
        }
    }
    func textFieldDidEndEditing(_ textField: UITextField) {
        
        scrlView.setContentOffset(CGPoint(x: 0, y: 0), animated: true)
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
         if textField == tfPhoneNo {
            tfPassword.becomeFirstResponder()
        }else if textField == tfPassword{
            textField.resignFirstResponder()
            self.scrlView.setContentOffset(CGPoint(x: 0, y: 0), animated: true)
        }
        
        
        return true
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        let length = (textField.text?.count)! + string.count - range.length
        let strResult = isNumberOrEmail(testString: tfPhoneNo.text!)
        
        if strResult == "email" {
            if textField == tfPhoneNo {
                return (length > 40) ? false : true
            }
        } else if strResult == "number" {
            if textField == tfPhoneNo {
                return (length > 10) ? false : true
            }
        }
        else if textField == tfPassword {
            
            
            return (length > 31) ? false : true
        }
        return true
    }
    
    
    func isNumberOrEmail(testString: String) -> String {
        let number = Double(testString)
        if number == nil {
            return "email"
        } else {
            return "number"
        }
    }
    func checkValidation() -> String? {
        if tfPhoneNo.text?.count == 0  {
            return "Please enter phone number or email."
            
        } else if (tfPhoneNo.text?.count)! > 0 {
            let strResult = isNumberOrEmail(testString: tfPhoneNo.text!)
            if strResult == "email" {
                if !Validation.email(tfPhoneNo.text!) {
                    return "Please enter valid email."
                }
            } else {
                let strLength = tfPhoneNo.text?.count
                if strLength != 10 {
                    return "Mobile number is not valid."
                }
            }
        } else if tfPassword.text?.count == 0  {
            return "Please enter password."
            
        } else if (tfPassword.text?.count)! < 6 {
            return "Password should be minimum 6 characters."
        }
        
        return nil
    }
    
    
    func ws_Signin() {
        let params = NSMutableDictionary()
        params["username"] = tfPhoneNo.text!
        params["password"] = tfPassword.text!
        params["role"] =  "delivery"
        params["device_name"] = UIDevice.current.modelName
        params["imei"] =    APPConstants.getDeviceId()
        params["apns_id"] =   kappDelegate.apns
        params["device_type"] = APPConstants.deviceType
        params["modal_no"] = UIDevice.current.model
        params["os_version"] =  UIDevice.current.systemVersion
        params["social_type"] = "email"
        
        let defaults = UserDefaults.standard
        if  let notificationid = defaults.object(forKey: "firebasetoken") {
            params["notification_id"] =   ("\(notificationid)")
        }else{
            params["notification_id"] = "123"
        }
        
        // UIDevice.current.deviceInfo(params)
        
        print("params-------", params)
        Http.instance().json(WebServices.login, params, "POST", ai: true, popup: true, prnt: true, sync: false) { (json, dict, str) in
            
            if let json1 = json as? NSDictionary {
                
                if number(json1 , "success").boolValue {
                    if let result = json1["result"] as? NSDictionary {
                     //   Http.alert("", string(json1! , "message"))
                        let uDef = UserDefaults.standard
                        
                        if let user = json1.object(forKey: "result") as? NSDictionary {
                            if let delivery_address = user.object(forKey: "delivery_address") as? NSDictionary {
                                if let country_id = delivery_address.object(forKey: "country_id") as? Int {
                                    uDef.set(country_id, forKey: "country_id")
                                }

                            }
                            // let uDef = UserDefaults.standard

                            uDef.set(self.tfPhoneNo.text!, forKey: "email")
                            uDef.set(self.tfPassword.text!, forKey: "pass")

                            if self.is_remamber {
                                uDef.set(true, forKey: "is_remamber")
                            }else {
                                uDef.set(false, forKey: "is_remamber")
                            }

                            uDef.set(true, forKey: "is_login")
                            userInfo.saveLoginInfo(user)
                        }
                        

                        
                        if let token = result.object(forKey: "token") as? String {
                            userInfo.savetoken(token)
                        }
                        if let user_key = result.object(forKey: "user_key") as? String {
                            uDef.set(user_key, forKey: "user_key")
                            SOCKETIOCLIENTMANAGER.sharedInstance.loginConnection()
                        }
                        uDef.synchronize()

                        guard let completed_steps = result.object(forKey: "completed_steps") as? Int else {
                            return
                        }
                        
                        kappDelegate.completed_steps = completed_steps
                        
                        if completed_steps == 1 {
                            let vc = self.storyboard?.instantiateViewController(withIdentifier: "AgreementView") as! AgreementView
                            self.navigationController?.pushViewController(vc, animated: true)
                        }else if completed_steps == 2 {
                            let vc = self.storyboard?.instantiateViewController(withIdentifier: "UserInformationView") as! UserInformationView
                            self.navigationController?.pushViewController(vc, animated: true)

                        }else if completed_steps == 3 {
                            let vc = self.storyboard?.instantiateViewController(withIdentifier: "VerifyNumberVC") as! VerifyNumberVC
                            vc.mobileNumber = string(result, "phone_number")
                            self.navigationController?.pushViewController(vc, animated: true)

                        }else if completed_steps == 4 {
                            let vc = self.storyboard?.instantiateViewController(withIdentifier: "AddAddressSignupVC") as! AddAddressSignupVC
                            self.navigationController?.pushViewController(vc, animated: true)

                        }else if completed_steps == 5 {
                            let vc = self.storyboard?.instantiateViewController(withIdentifier: "AddMarketView") as! AddMarketView
                            self.navigationController?.pushViewController(vc, animated: true)
                            
                        }else if completed_steps == 6 {
                            
                            let vc = self.storyboard?.instantiateViewController(withIdentifier: "AddVehicleView") as! AddVehicleView
                            self.navigationController?.pushViewController(vc, animated: true)

                        }else if completed_steps == 7 {
                            if Int(string(result, "license_screen")) == 1 {
                                let vc = self.storyboard?.instantiateViewController(withIdentifier: "AddLicenseinforView") as! AddLicenseinforView
                                self.navigationController?.pushViewController(vc, animated: true)

                            }else {
                                
                                let vc = self.storyboard?.instantiateViewController(withIdentifier: "AgreementFCRAView") as! AgreementFCRAView
                                self.navigationController?.pushViewController(vc, animated: true)

//                                let vc = self.storyboard?.instantiateViewController(withIdentifier: "AddSelfeView") as! AddSelfeView
//                                self.navigationController?.pushViewController(vc, animated: true)

                            }
                            
                            
                        }else if completed_steps == 8 {
                            
                            let vc = self.storyboard?.instantiateViewController(withIdentifier: "AgreementStateView") as! AgreementStateView
                            self.navigationController?.pushViewController(vc, animated: true)

                        }else if completed_steps == 9 {
                            
                            let vc = self.storyboard?.instantiateViewController(withIdentifier: "SocialSecuirtyVC") as! SocialSecuirtyVC
                            self.navigationController?.pushViewController(vc, animated: true)
//                            let vc = self.storyboard?.instantiateViewController(withIdentifier: "AgreementConsentView") as! AgreementConsentView
//                            self.navigationController?.pushViewController(vc, animated: true)
                        }else if completed_steps == 10 {
                            let vc = self.storyboard?.instantiateViewController(withIdentifier: "AddSelfeView") as! AddSelfeView
                            self.navigationController?.pushViewController(vc, animated: true)
                        }else  {
                            self.navigationController?.viewControllers = []
                            let vc = self.storyboard?.instantiateViewController(withIdentifier: "RootViewCustomer") as! RootViewCustomer
                            kappDelegate.window?.rootViewController = vc
                        }
                        
                        
                        
                      
                        
                        
//                        let vc = self.storyboard?.instantiateViewController(withIdentifier: "AgreementView") as! AgreementView
//                        self.navigationController?.pushViewController(vc, animated: true)

//                        return
                        
                        
                       /* if string(result, "is_phone_verified") == "0" && string(result, "phone_number") == "" && string(result, "temp_phone_number") == ""{
                            let vc = self.storyboard?.instantiateViewController(withIdentifier: "ChangeNumberVC") as! ChangeNumberVC
                            self.navigationController?.pushViewController(vc, animated: true)
                            
                            
                        }else if string(result, "is_phone_verified") == "0" && string(result, "phone_number") != "" && string(result, "temp_phone_number") != "" {
                            
                            let vc = self.storyboard?.instantiateViewController(withIdentifier: "VerifyNumberVC") as! VerifyNumberVC
                            vc.mobileNumber = string(result, "temp_phone_number")
                            self.navigationController?.pushViewController(vc, animated: true)
                        }
                        else if string(result, "is_mail_verified") == "0" && string(result, "email") == "" {
                            let vc = self.storyboard?.instantiateViewController(withIdentifier: "AddEmailVC") as! AddEmailVC
                            self.navigationController?.pushViewController(vc, animated: true)
                            
                        }else if string(result, "is_mail_verified") == "0" && string(result, "email") != "" {
                            let vc = self.storyboard?.instantiateViewController(withIdentifier: "VerifyEmailVC") as! VerifyEmailVC
                            vc.myemail = string(result, "email")
                            self.navigationController?.pushViewController(vc, animated: true)
                            
                        }
                        else{
                            self.navigationController?.viewControllers = []
                            let vc = self.storyboard?.instantiateViewController(withIdentifier: "RootViewCustomer") as! RootViewCustomer
                            kappDelegate.window?.rootViewController = vc
                        }
                        */
                        
                    }
                }else {
                    if string(json1, "is_new_user") == "1" {
                        let vc = self.storyboard?.instantiateViewController(withIdentifier: "SignupVC") as! SignupVC
                        self.navigationController?.pushViewController(vc, animated: true)
                    }
                    Http.alert("", string(json1 , "message"))
                    
                }
                
            }
        }
        
        
    }
    
    //*************************************************
    //MARK:- KEYBOARD NOTIFICATION METHODS
    func registerForKeyboardNotifications() {
        let notificationCenter = NotificationCenter.default
        notificationCenter.addObserver(self, selector: #selector(adjustForKeyboard), name: Notification.Name.UIKeyboardWillHide, object: nil)
        notificationCenter.addObserver(self, selector: #selector(adjustForKeyboard), name: Notification.Name.UIKeyboardWillChangeFrame, object: nil)
    }
    
    func deregisterFromKeyboardNotifications() {
        NotificationCenter.default.removeObserver(self, name: .UIKeyboardWillShow, object: nil)
        NotificationCenter.default.removeObserver(self, name: .UIKeyboardWillHide, object: nil)
    }
    
    @objc func adjustForKeyboard(notification: Notification) {
        let userInfo = notification.userInfo!
        
        let keyboardScreenEndFrame = (userInfo[UIKeyboardFrameEndUserInfoKey] as! NSValue).cgRectValue
        let keyboardViewEndFrame = view.convert(keyboardScreenEndFrame, from: view.window)
        
        if notification.name == Notification.Name.UIKeyboardWillHide {
            scrlView.contentInset = UIEdgeInsets.zero
        } else {
            scrlView.contentInset = UIEdgeInsets(top: 0, left: 0, bottom: keyboardViewEndFrame.height + 10, right: 0)
        }
        
        scrlView.scrollIndicatorInsets = scrlView.contentInset
    }
    
    @IBAction func actionForgotPasword(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ForgotPassword") as! ForgotPassword
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    
    
    
}
