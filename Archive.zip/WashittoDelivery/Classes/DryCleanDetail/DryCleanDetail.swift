//
//  DryCleanDetail.swift
//  Washitto
//
//  Created by Rahul on 07/08/18.
//  Copyright © 2018 Himanshu. All rights reserved.
//

import UIKit
import HarishFrameworkSwift4
import MessageUI

class DryCleanDetail: UIViewController , UITableViewDelegate, UITableViewDataSource, ServiceDetailDelegate , MFMessageComposeViewControllerDelegate ,UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout{
  
    
  
    @IBOutlet var lblTimer: UILabel!
    var request_id = ""
    @IBOutlet var backbutton: UIBarButtonItem!
    @IBOutlet var btnRequest: UIButton!
    @IBOutlet var imgCategory: UIImageView!
    @IBOutlet var lblCategoryName: UILabel!
    @IBOutlet var lblPickUpOn: UILabel!
    @IBOutlet var lblDeliveryOn: UILabel!
    @IBOutlet var lblAddress: UILabel!
    @IBOutlet var lblDeliveryCharge: UILabel!
    @IBOutlet var lblTotalPrice: UILabel!
    @IBOutlet var lblSubTotal: UILabel!
    @IBOutlet var lblOrderStatus: Label!
    @IBOutlet var tblView: UITableView!
    @IBOutlet var tblItemView: UITableView!
    @IBOutlet var tblViewConstraintHeight: NSLayoutConstraint!
    @IBOutlet var collectionViewConstaintHt: NSLayoutConstraint!
    @IBOutlet var tblItemViewConstraintHeight: NSLayoutConstraint!
    
    var arrItem = NSArray()
    @IBOutlet var lblItem: UILabel!
    var orderid = ""
    var comefrom = ""
    var pickupDateTime = String()
    var dropDateTime = String()
    var service_id = String()
    @IBOutlet var btnDeliver: UIButton!

    //
    

    
    override func viewDidLoad() {
        super.viewDidLoad()
        backbutton.image = UIImage.imageWithImage(image: UIImage(named: "back.png")!, scaledToSize: CGSize(width: 10.0, height: 16.0))

        if kappDelegate.comefromNoti == "yes" {
            orderid = kappDelegate.order_id
            request_id = kappDelegate.request_id
        
        }
    }
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.isNavigationBarHidden = false
        navigationItem.hidesBackButton = false
        
        navigationController?.navigationBar.shouldRemoveShadow(true)
        
        self.setImageNavigation()
        self.WS_OrderDetails()

        
        tblView.delegate = self
        tblView.dataSource = self
        //tvSpecialInstructions.text = "Not Available."
        
        collectionInagesView.clipsToBounds = false
        collectionInagesView.delegate = self
        collectionInagesView.dataSource = self
        
        let cellWidth : CGFloat = collectionInagesView.frame.size.width / 2.0 - 5.0
        let cellheight : CGFloat = collectionInagesView.frame.size.height //myCollectionView.frame.size.width / 4.0 //- 2.0
        let cellSize = CGSize(width: cellheight , height:cellheight)
        
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .horizontal //.horizontal
        layout.itemSize = cellSize
        layout.sectionInset = UIEdgeInsets(top: 1, left: 1, bottom: 1, right: 1)
        layout.minimumLineSpacing = 1.0
        layout.minimumInteritemSpacing = 1.0
        collectionInagesView.setCollectionViewLayout(layout, animated: true)
        
    }
    var placeholderLabel : UILabel!

   
    
    func serviceDetails()  {
     
        self.request_status = string(self.dictResult, "request_status")
        self.request_type = string(self.dictResult, "request_type")
        
        if let dict = self.dictResult.object(forKey: "customer") as? NSDictionary {
            self.arrList.add(dict)
        }
        if let dictVendor =  dictResult.object(forKey: "vendors")as? NSDictionary{
            self.arrList.add(dictVendor)
            
        }
        if let dict = self.dictResult.object(forKey: "pickup_deliveryboy") as? NSDictionary {
            
            self.arrList.add(dict)
        }
        if let dict = self.dictResult.object(forKey: "dropoff_deliveryboy") as? NSDictionary {
            
            self.arrList.add(dict)
        }
        if self.arrList.count > 0 {
            
            self.tblViewConstraintHeight.constant = CGFloat(self.arrList.count * 100)
        }
        if let items = dictResult.object(forKey: "items") as? NSArray {
            arrItem  = items
        }
        tblView.reloadData()
        let  strStatus = string(dictResult, "request_status")

        self.lblOrderStatus.text = ""  + strStatus + "   "
        self.lblOrderStatus.backgroundColor = appColour().getColor(string(dictResult, "request_status"))
        self.lblOrderStatus.textColor = UIColor.white
        // remaining_time
        
      
        
        tblItemViewConstraintHeight.constant = CGFloat(arrItem.count)*110 
        tblItemView.reloadData()
        
        if let path = dictResult.object(forKey: "service_icon") as? String {
            let imgurl = APPConstants.upload_url + path
            let URL =  NSURL(string: imgurl)
            imgCategory.sd_setImage(with: URL as URL!, placeholderImage: UIImage(named: "noimage.png"),  options: SDWebImageOptions.retryFailed)
        }
        
        lblCategoryName.text =  string(dictResult, "service_name")
        
        
        pickupDateTime = string(dictResult, "pickup_time") //+ " " + string(pickup, "time")
        
        lblPickUpOn.text  = pickupDateTime.converDate("yyyy-MM-dd HH:mm:ss", "E,MMM dd\nhh:mm a")
        
        dropDateTime = string(dictResult, "dropoff_time")  //+ " " + string(dropoff, "time")
        
        lblDeliveryOn.text  = dropDateTime.converDate("yyyy-MM-dd HH:mm:ss", "E,MMM dd\nhh:mm a")
        
        lblAddress.text =  string(dictResult, "address")
        
        
        //===========******==========================
        
        if  let subtotal = Double(string(dictResult, "subtotal")){
            
            lblSubTotal.text = subtotal.dollarString
            
        }
        if  let delivery_charge = Double(string(dictResult, "delivery_charge")){
            
            lblDeliveryCharge.text = delivery_charge.dollarString
        }
        
        if  let grand_total = Double(string(dictResult, "grand_total")){
            
            lblTotalPrice.text = grand_total.dollarString
        }
        
//        print("dictResult--------\(dictResult)")
        if let arr =  dictResult.object(forKey: "order_images") as? NSArray {
            self.arrOrder_images = arr
            collectionInagesView.reloadData()
        }
        if self.arrOrder_images.count == 0 {
            collectionViewConstaintHt.constant = 0
        }
        self.OrderStatus(string(dictResult, "request_status") )

    }
    
   
    
    var dictResult = NSMutableDictionary()
    var timer: Timer?

    @IBAction func actionLeftNavigation(_ sender: Any) {
        
        if kappDelegate.comefromNoti == "yes" {
            //            self.navigationController?.popViewController(animated: true)
            
            self.sideMenuViewController.setContentViewController(self.storyboard?.instantiateViewController(withIdentifier: "order_nav"), animated: true)
        }else{
            //            self.dismiss(animated: true, completion: nil)
            self.navigationController?.popViewController(animated: true)
        }
        kappDelegate.comefromNoti = ""
        kappDelegate.order_id = ""
        kappDelegate.request_id = ""
        
    }
    var is_time = 0
    @objc func myMethod(){
        print("timer ---->\(is_time)")
        
        
        if is_time == 0 { // timer to
            actionLeftNavigation(0)
            timer?.invalidate()
            timer = nil
        }
        if is_time != 0 {
            let date = Date(timeIntervalSince1970: Double(is_time))
            print("date - \(date)")
            
            let formatter = DateFormatter()
            formatter.dateFormat = "mm:ss"
            //             formatter.locale = NSLocale(localeIdentifier: "en_US") as Locale!
            formatter.timeZone = TimeZone(abbreviation: "UTC") //  NSTimeZone(abbreviation: "UTC")! as TimeZone
            
            let dd = formatter.string(from: date as Date)
            print(dd)
            
            lblTimer.text = dd
        }
        
        is_time = is_time - 1
        
    }
    func OrderStatus(_ request_status:String)  {
        
        if let remaining_time = dictResult.object(forKey: "remaining_time") as? Int {
            self.is_time = remaining_time
        }
        if request_status == "Pending" {
            if self.is_time == 0 {
//                self.is_time = 5
            }
            if self.timer == nil {
                self.timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(self.myMethod), userInfo: nil, repeats: true)
                self.timer?.fire()
            }
            self.btnRequest.setTitle("Accept", for: .normal)
            self.btnRequest.isHidden = false

        }else if request_status == "Accepted" {
            self.btnRequest.setTitle("Pick up", for: .normal)
            self.btnRequest.isHidden = false
        }
        else if request_status == "Pickedup" && request_type == "Dropoff"{
            self.btnRequest.setTitle("Delivered", for: .normal)
            self.btnRequest.isHidden = false
        }
            //                    else if self.request_status == "Pickedup" {
            //                        self.btnRequest.setTitle("Pickedup", for: .normal)
            //                    }
        else {
            self.btnRequest.isHidden = true
        }
            
        
     
    }
    ///////////Neeleshwari==========
    
    //MARK:- TABLEVIEW_DELEGATE
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView == tblView {
            return arrList.count
            
        }else if tableView == tblItemView {
            return arrItem.count
        }else {
            return 0
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if tableView == tblView {
            let cell = tableView.dequeueReusableCell(withIdentifier: "ServiceDetailListCell", for: indexPath) as! ServiceDetailListCell
            cell.delegate = self
            cell.index = indexPath
            
            let dict = arrList.object(at: indexPath.row) as! NSDictionary
            
            cell.lblType.text = string(dict, "title")
            cell.lblName.text = string(dict, "name")
            if dict.object(forKey: "ratings") != nil {
                cell.viewRating.rating = (dict.object(forKey: "ratings") as? Float)!
            }else{
                cell.viewRating.rating = 1.00
            }
            
            if let path = dict.object(forKey: "profile_image") as? String {
                let imgurl = APPConstants.upload_url + path
                let URL =  NSURL(string: imgurl)
                cell.imgView.sd_setImage(with: URL as URL!, placeholderImage: UIImage(named: "noimage.png"),  options: SDWebImageOptions.retryFailed)
            }
            
            return cell
        }else {
            let cell = tableView.dequeueReusableCell(withIdentifier: "DryCleanCell", for: indexPath) as! DryCleanCell
            
            let dict = arrItem.object(at: indexPath.row) as! NSDictionary
            
          
            cell.lblProductName.text = string(dict, "name")
            if  let subtotal = Double(string(dict, "total_price")){
                cell.lblPrice.text = subtotal.dollarString

            }
            if  let subtotal = Double(string(dict, "price")){
                cell.lblDiscount.text = "Item Price - "  + subtotal.dollarString
                
            }
         
//            cell.lblPrice.text = "$" + string(dict, "total_price")
            cell.lblQuantity.text = "Quantity - " + string(dict, "qty")
//            cell.lblDiscount.text = "Item Price - $"  + string(dict,"price" )
            
            if let path = dict.object(forKey: "image") as? String {
                let imgurl = APPConstants.cloth_url + path
                let URL =  NSURL(string: imgurl)
                cell.imgProduct.sd_setImage(with: URL as URL!, placeholderImage: UIImage(named: "noimage.png"),  options: SDWebImageOptions.retryFailed)
            }
        
            return cell
        }
     
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        //let dict = arrList.object(at: indexPath.row) as! NSDictionary
    }
    
    func messageComposeViewController(_ controller: MFMessageComposeViewController, didFinishWith result: MessageComposeResult) {
        switch (result.rawValue) {
        case MessageComposeResult.cancelled.rawValue:
            print("Message was cancelled")
            self.dismiss(animated: true, completion: nil)
        case MessageComposeResult.failed.rawValue:
            print("Message failed")
            self.dismiss(animated: true, completion: nil)
        case MessageComposeResult.sent.rawValue:
            print("Message was sent")
            self.dismiss(animated: true, completion: nil)
        default:
            break;
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        self.navigationController?.isNavigationBarHidden = false
        self.title  = ""
    }
    
    func sms(_ index: IndexPath?) {
        let dict = arrList.object(at: (index?.row)!) as! NSDictionary
        print(dict)
        if (MFMessageComposeViewController.canSendText()) {
            let controller = MFMessageComposeViewController()
            controller.body = ""
            controller.recipients = [string(dict, "phone_number")]
            controller.messageComposeDelegate = self
            self.present(controller, animated: true, completion: nil)
        }
    }
    
    func call(_ index: IndexPath?) {
        let dict = arrList.object(at: (index?.row)!) as! NSDictionary
        let mobile = string(dict, "phone_number")
        callNumber(mobile)
    }
    func Track(_ index: IndexPath?) {
        
        let dict = arrList.object(at: (index?.row)!) as! NSDictionary
        print(dict)
       let vc = self.storyboard?.instantiateViewController(withIdentifier: "TrackLocationView")as! TrackLocationView
//

     
        vc.LaundryType = string(dict, "title")
        if  let ll = Double(string(dictResult, "latitude")) {
            vc.latitude = ll
        }
        if  let ll = Double(string(dictResult, "longitude")) {
            vc.longitude = ll
        }
        
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    
 
    //MARK:- WS_OrderDetails
    
    
    
    var arrList = NSMutableArray()
    
    // MARK: - Functions
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
   
    

    @IBAction func actionMap(_ sender: Any) {
//        let vc = self.storyboard?.instantiateViewController(withIdentifier: "Addressmap")as! Addressmap
//        vc.latitude = string(dictResult, "latitude")
//        vc.longitude = string(dictResult, "longitude")
//        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    
    @IBOutlet var collectionInagesView: UICollectionView!
    var arrOrder_images = NSArray()
    // @IBOutlet var const_order_images: NSLayoutConstraint!
    @IBOutlet var viewScrl: UIView!
    
    // @IBOutlet var const_mainView_height: NSLayoutConstraint!
    
    
    //MARK:- Button Actions
    @IBAction func btnAccept(_ sender: Any) {
        print("btnAccept")
        self.CreateOrder()
    }
    
    var request_status = ""

    
    var request_type = ""

    @IBAction func btnDeliver(_ sender: Any) {
        
        if self.request_status == "Pending" {
            self.CreateOrder()
        }else if self.request_status == "Accepted" {
            // mhn
            if request_type == "Dropoff" {
                ws_OrderPicked() // when driver go to vendor
            }else {
                let vc = self.storyboard?.instantiateViewController(withIdentifier: "OrderPickupView") as? OrderPickupView
                vc!.orderid = orderid
                vc!.request_id = request_id
                vc!.request_type = request_type
                self.navigationController?.pushViewController(vc!, animated: true)
                
            }
        }else if self.request_status == "Pickedup" {
            ws_DeliverdToCustomer()
        }
        
        
    }
    
    func ws_OrderPicked(){
        let params = NSMutableDictionary()
        params["request_id"] = request_id
        params["order_id"] = orderid
        params["request_type"] = request_type
        
        Http.instance().json(WebServices.orders_picked, params, "POST", ai: true, popup: true, prnt: true, userInfo.Token(),  sync: false) { (json, dict, str) in
            
            if json != nil {
                let json1 = json as? NSDictionary
                if number(json1! , "success").boolValue {
                    Http.alert("", string(json1! , "message"))
                    self.WS_OrderDetails()
                }else {
                    Http.alert("", string(json1! , "message"))
                }
            }
        }
    }
    //    sdsdsds
    
    func ws_DeliverdToCustomer(){
        let params = NSMutableDictionary()
        params["request_id"] = request_id
        params["order_id"] = orderid
        params["request_type"] = request_type
        
        Http.instance().json(WebServices.deliver_to_customer, params, "POST", ai: true, popup: true, prnt: true, userInfo.Token(),  sync: false) { (json, dict, str) in
            
            if json != nil {
                let json1 = json as? NSDictionary
                if number(json1! , "success").boolValue {
                    Http.alert("", string(json1! , "message"))
                   self.WS_OrderDetails()
                }else {
                    Http.alert("", string(json1! , "message"))
                }
            }
        }
    }
    
    
    
    func WS_OrderDetails(){
        let params = NSMutableDictionary()
        params["order_id"] = orderid
        params["request_id"] = request_id

        Http.instance().json(WebServices.ordersdetails, params, "GET", ai: true, popup: true, prnt: true, userInfo.Token(), sync: false) { (json, dict, str) in
            
            if json != nil {
                let json1 = json as? NSDictionary
                if number(json1! , "success").boolValue {
                    
//                    kappDelegate.comefromNoti = ""
//                    kappDelegate.order_id = ""
                    // self.arrlist = NSMutableArray()

                    if let result = json1?["result"] as? NSDictionary {
                        self.arrList = NSMutableArray()
                        print("result-->>\(result)")
                        self.dictResult = result.mutableCopy() as! NSMutableDictionary
                      
                      
                        self.serviceDetails()
                       
                    }
                }else {
                    Http.alert("", string(json1! , "message"))
                }
            }
        }
    }
    
   
    
    func CreateOrder(){
        let params = NSMutableDictionary()
        
        params["order_id"] = orderid
        params["request_id"] = request_id
        Http.instance().json(WebServices.ordersaccept, params, "POST", ai: true, popup: true, prnt: true, userInfo.Token(), sync: false) { (json, dict, str) in
            
            if json != nil {
                let json1 = json as? NSDictionary
                if number(json1! , "success") == 1 {
                    if self.timer != nil {
                        self.timer?.invalidate()
                    }
                    self.timer = nil

                 self.WS_OrderDetails()

                    Http.alert("", string(json1! , "message"))
                }else {
                    
                    Http.alert("", string(json1! , "message"))
                }
            }
        }
    }
    
    
    //MARK:- UICollectionView
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        return self.arrOrder_images.count
    }
    
    // make a cell for each cell index path
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        // get a reference to our storyboard cell
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "GroupDetailImagesCell", for: indexPath as IndexPath) as! GroupDetailImagesCell
        let userdetail = self.arrOrder_images.object(at: indexPath.row) as! NSDictionary
        if let path = userdetail.object(forKey: "image") as? String {
            let imgurl = APPConstants.upload_url + path
            let URL =  NSURL(string: imgurl)
            cell.imgPost.sd_setImage(with: URL as URL!, placeholderImage: UIImage(named: "noimage.png"),  options: SDWebImageOptions.retryFailed)
        }else{
            cell.imgPost.image = UIImage(named : "noimage.png")
        }
        cell.imgPost.layer.cornerRadius = 10
        cell.imgPost.clipsToBounds = true
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let imag = self.storyboard?.instantiateViewController(withIdentifier: "MyImageZoom") as? MyImageZoom
        let userdetail = self.arrOrder_images.object(at: indexPath.row) as! NSDictionary
        if let path = userdetail.object(forKey: "image") as? String {
            let imgurl = APPConstants.upload_url + path
            imag?.imageName = imgurl
        }
        imag?.arrImages = self.arrOrder_images
        self.present(imag!, animated: false, completion: nil)
        //
    }
    
}
extension Double {
    var dollarString:String {
        return String(format: "$%.2f", self)
    }
}
