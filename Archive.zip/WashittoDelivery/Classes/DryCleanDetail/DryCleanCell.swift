//
//  DryCleanCell.swift
//  Washitto
//
//  Created by Rahul on 08/08/18.
//  Copyright © 2018 Himanshu. All rights reserved.
//

import UIKit

class DryCleanCell: UITableViewCell {

    @IBOutlet var imgProduct: UIImageView!
    @IBOutlet var lblProductName: UILabel!
    @IBOutlet var lblPrice: UILabel!
    @IBOutlet var lblDiscount: UILabel!
    @IBOutlet var lblQuantity: UILabel!

   
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
