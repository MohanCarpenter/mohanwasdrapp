//
//  TrackLocationView.swift
//  WashittoDelivery
//
//  Created by Rahul on 18/07/18.
//  Copyright © 2018 Himanshu pal. All rights reserved.
//

import UIKit
import GoogleMaps

class TrackLocationView: UIViewController ,GMSMapViewDelegate , CLLocationManagerDelegate{


//    var UserPin: GMSMarker?
    var orderLo: GMSMarker!
    var UserPin: GMSMarker!

    var orderImage = UIImage(named: "deliverypin")
    var LaundryType  = ""
    var latitude:Double = 0.0 //
    var longitude:Double = 0.0 // 76.0508
    var orderLocation: CLLocationCoordinate2D?
    var locManager:CLLocationManager? = CLLocationManager()
    @IBOutlet var mapView: GMSMapView!
    
    override func viewDidLoad() {
        navigationController?.navigationBar.shouldRemoveShadow(true)
        
        self.setImageNavigation()

       // if // laundrypin
        
//        if latitude == 0.0 {
//            latitude = 22.6965059
//            longitude = 75.865884
//        }
       

        self.mapView.delegate = self;
//         self.mapView.settings.compassButton = true;
        
         self.mapView.settings.myLocationButton = false;
         self.mapView.settings.zoomGestures = true;
         self.mapView.settings.scrollGestures = true;
         self.mapView.isUserInteractionEnabled = true;
         self.mapView.isMyLocationEnabled = false;
         self.mapView.settings.compassButton = true;

        let position = CLLocationCoordinate2D(latitude: latitude, longitude: longitude)
        orderLo = GMSMarker(position: position)
        orderLo?.title = "Order location"
        orderLo?.position = position
        if  LaundryType  == "Laundry Owner" {
            orderLo?.icon = UIImage(named: "laundrypin")
        }else {
            orderLo?.icon = UIImage(named: "Cumtomerpin")
        }
        
        orderLo?.map = mapView
        curLocation()
       

        UserPin = GMSMarker()
        UserPin.tracksViewChanges = true
        UserPin.appearAnimation = .none

        UserPin.title = "My Location"
//        UserPin.position = CLLocationCoordinate2D(latitude: 0.0, longitude: 0.0)
        UserPin.icon = orderImage
        UserPin.map = mapView
//        self.UserPin.icon = self.orderImage

    }
    
  
    @IBAction func actionMenu(_ sender: Any) {
        self.sideMenuViewController.presentRightMenuViewController()
    }


    func curLocation() {
        
        if locManager != nil {
            locManager?.delegate = self
            locManager?.desiredAccuracy = kCLLocationAccuracyBest
            
            locManager?.requestWhenInUseAuthorization()
            
            locManager?.distanceFilter = 0
            locManager?.startUpdatingLocation()
            locManager!.desiredAccuracy = kCLLocationAccuracyBest;
            locManager!.activityType = .automotiveNavigation;
            
            locManager?.startUpdatingHeading()
            
            // Check authorizationStatus
            let authorizationStatus = CLLocationManager.authorizationStatus()
            // List out all responses
            
            switch authorizationStatus {
            case .authorizedAlways:
                print("authorized")
            case .authorizedWhenInUse:
                print("authorized when in use")
            case .denied:
                print("denied")
            case .notDetermined:
                print("not determined")
            case .restricted:
                print("restricted")
            }
            
            // Get the location
            locManager?.startUpdatingLocation()
            
            if(CLLocationManager.authorizationStatus() == CLAuthorizationStatus.authorizedWhenInUse ||
                CLLocationManager.authorizationStatus() == CLAuthorizationStatus.authorizedAlways) {
                // Extract the location from CLLocationManager
                let userLocation = locManager?.location
                
                // Check to see if it is nil
                if userLocation != nil {
                    if (locManager?.location?.coordinate.latitude) != nil {
                        let camera = GMSCameraPosition.camera(withLatitude: (locManager?.location?.coordinate.latitude)!, longitude: (locManager?.location?.coordinate.longitude)!, zoom: 10.0)
                        mapView?.animate(to: camera)
                    }
                    //print("location is \(userLocation)")
                } else {
                    //print("location is nil")
                }
            } else {
                //print("not authorized")
            }
            
        }
    }
    var iscall = true
    
    var lastLocation:CLLocation? = nil
    var ismyLocation = true

  
   
    func locationManager(_ manager: CLLocationManager, didUpdateHeading newHeading: CLHeading) {
        let  heading:Double = newHeading.trueHeading;
        UserPin.groundAnchor = CGPoint(x: 0.5, y: 0.5)
        UserPin.rotation = heading
//        print("heading---->",heading)
        UserPin.map = mapView;
//

    }
 
    var checkingLocation = false
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation])
    {
    
        
    
        CATransaction.begin()
        CATransaction.setAnimationDuration(0.3)
        
        CATransaction.setValue(2.0, forKey: kCATransactionAnimationDuration)
        CATransaction.setCompletionBlock {
            self.UserPin.groundAnchor = CGPoint(x: 0.5, y: 0.5)
        }
        UserPin.position = (locManager?.location!.coordinate)!
        CATransaction.commit()
        
        
        
        
        let position1 = CLLocationCoordinate2D(latitude: (manager.location?.coordinate.latitude)!, longitude: (manager.location?.coordinate.longitude)!)
        
//        let head = manager.location?.course ?? 0
//        print("rotation ->",head)
//        UserPin.rotation = head
        UserPin.position = position1
        //             SOCKETIOCLIENTMANAGER.sharedInstance.updateMyLocation((manager.location?.coordinate.latitude)!,  (manager.location?.coordinate.longitude)!, head)
        
        
        let position111 = CLLocation(latitude: (manager.location?.coordinate.latitude)!, longitude: (manager.location?.coordinate.longitude)!)

        if (lastLocation != nil) {
            
            
            if position111.distance(from: lastLocation!) > 25 {
                self.getMyPolyline(myLat: (manager.location?.coordinate.latitude)!, myLng: (manager.location?.coordinate.longitude)!)
            }
            
        }else {
            self.getMyPolyline(myLat: (manager.location?.coordinate.latitude)!, myLng: (manager.location?.coordinate.longitude)!)
            
        }
        
        lastLocation = position111
        
   
        
    }
    var oldLocationCenter: CLLocation?

   /*
    func DegreeBearing(A:CLLocation,B:CLLocation)-> Double{
        
        
        var dlon = self.ToRad(degrees: B.coordinate.longitude - A.coordinate.longitude)
        
        let dPhi = log(tan(self.ToRad(degrees: B.coordinate.latitude) / 2 + M_PI / 4) / tan(self.ToRad(degrees: A.coordinate.latitude) / 2 + M_PI / 4))
        
        if  abs(dlon) > M_PI{
            dlon = (dlon > 0) ? (dlon - 2*M_PI) : (2*M_PI + dlon)
        }
        return self.ToBearing(radians: atan2(dlon, dPhi))
    }
    
    func ToRad(degrees:Double) -> Double{
        return degrees*(M_PI/180)
    }
    
    func ToBearing(radians:Double)-> Double{
        return (ToDegrees(radians: radians) + 360) / 360
    }
    
    func ToDegrees(radians:Double)->Double{
        return radians * 180 / M_PI
    }
*/
   
    
    func showAllMarker(){
        var bounds = GMSCoordinateBounds()
        
        if latitude != 0.0 || longitude != 0.0 {
            
            bounds = bounds.includingCoordinate(CLLocationCoordinate2D(latitude:latitude, longitude:longitude))
        }
        if self.UserPin.position.longitude != 0.0 {
              self.iscall = false
            bounds = bounds.includingCoordinate(CLLocationCoordinate2D(latitude:(self.UserPin.position.latitude), longitude:(self.UserPin.position.longitude)))
            
            let update = GMSCameraUpdate.fit(bounds, withPadding: 50)
            mapView.animate(with: update)
        }
        
    }

    func getMyPolyline(myLat: Double, myLng: Double)  {
        
        
        let config = URLSessionConfiguration.default
        let session = URLSession(configuration: config)

        if latitude == 0.0 || longitude == 0.0 {
            return
        }
        
        let directionURL = String(format: "https://maps.googleapis.com/maps/api/directions/json?origin=\(myLat),\(myLng)&destination=\(latitude),\(longitude)&key=AIzaSyDemfeMxzN_fPkeeBS8vYOQb3w01UOVtv0")
//
        print(directionURL)
        let url = URL(string: directionURL)!
        let task = session.dataTask(with: url, completionHandler: {
            (data, response, error) in
            if error != nil {
                print(error!.localizedDescription)
            } else {
                do {
                    if let json = try JSONSerialization.jsonObject(with: data!, options: .allowFragments) as? NSDictionary {
//                        _ = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
                        print("json --->",json)
                            if let routes = json.object(forKey:"routes")  as? NSArray {
                                if routes.count > 0 {
                                    DispatchQueue.main.async {
                                        if self.iscall {
                                         self.iscall = false
                                           self.showAllMarker()
                                        }
                                        self.mapView.clear()
                                        self.orderLo?.map = self.mapView
                                        self.UserPin?.map = self.mapView
                                        for dic11 in routes {
                                            if let route = dic11 as? NSDictionary {
                                                if let arr = route["legs"] as? NSArray {
                                                    for route1 in arr {
                                                        if let route1 = route1 as? NSDictionary {
                                                            if let steps = route1["steps"] as? NSArray {
                                                                self.convertPolyline(steps)
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                        
                                    }
                                }
                            }

                        

                    }
                } catch {
//                    print("error in JSONSerialization")
                }
            }
        })
        task.resume()
    }
    
    

  
    func convertPolyline(_ arr: NSArray){
        
        
        for k in 0..<arr.count {
            if let route2 = arr[k] as? NSDictionary {
                if let overviewPolyline = route2["polyline"] as? NSDictionary {
                    if let points = overviewPolyline["points"] as? String {
                        
                        let path = GMSMutablePath(fromEncodedPath: points)
                        let polyline = GMSPolyline(path: path)
                        polyline.strokeWidth = 2.5
                        polyline.strokeColor = UIColor.red// UIColor(red: 60/255, green: 176/255, blue: 223/255)
                        polyline.map = mapView
                        
                    }
                }
            }
            
        }
        
    }
    
    
    
}

/* if let userdetail:NSDictionary = userInfo.getLoginInfo()  {
 
 if let path = userdetail.object(forKey: "profile_image") as? String {
 let imgurl = APPConstants.upload_url + path
 if let URL =  URL(string: imgurl) {
 downloadedFrom(url: URL )
 }
 }
 }
 func downloadedFrom(url: URL) {
 
 URLSession.shared.dataTask(with: url) { (data, response, error) in
 guard let httpURLResponse = response as? HTTPURLResponse, httpURLResponse.statusCode == 200,
 let mimeType = response?.mimeType, mimeType.hasPrefix("image"),
 let data = data, error == nil,
 let image = UIImage(data: data)
 else { return }
 DispatchQueue.main.async() { () -> Void in
 //                self.image = image
 //                self.orderImage = MapUserImage.merge(UIImage(named: "mapPin.png"), with: MapUserImage.imageWithBorder(from: image))
 //                self.orderImage = UIImage(named: "red-sports.png")
 
 
 }
 }.resume()
 }*/

