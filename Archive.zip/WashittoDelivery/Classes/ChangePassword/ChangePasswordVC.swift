//
//  ChangePasswordVC.swift
//  Washitto
//
//  Created by Himanshu on 22/06/18.
//  Copyright © 2018 Himanshu. All rights reserved.
//

import UIKit
import HarishFrameworkSwift4
class ChangePasswordVC: UIViewController, UITextFieldDelegate{

    @IBOutlet var tfConfirmpwd: TextField!
    @IBOutlet var tfNewPwd: TextField!
    @IBOutlet var tfCurrentPwd: TextField!
    override func viewDidLoad() {
        super.viewDidLoad()
self.setImageNavigation()
        // Do any additional setup after loading the view.
        
  
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
        if textField == tfCurrentPwd {
            tfNewPwd.becomeFirstResponder()
        }else if textField == tfNewPwd{
            tfConfirmpwd.becomeFirstResponder()
        }else if textField == tfConfirmpwd{
            textField.resignFirstResponder()
        }
        
        
        return true
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        let length = (textField.text?.count)! + string.count - range.length
        
      if textField == tfCurrentPwd || textField == tfNewPwd || textField == tfConfirmpwd {
            return (length > 31) ? false : true
        }
        return true
    }
    
    
    func checkValidation() -> String? {
        if tfCurrentPwd.text?.count == 0 {
            return "Please enter current password."
        }else if tfNewPwd.text?.count == 0 {
            return "Please enter new password."
        }else if tfConfirmpwd.text?.count == 0 {
            return "Please enter confirm password."
        }else if tfConfirmpwd.text! != tfNewPwd.text! {
            return "New password and confirm password are not match."
        }
        
        return nil
    }
    
    
    func ws_ChangePassword() {
        let params = NSMutableDictionary()
        params["new_password"] = tfNewPwd.text!
        params["password"] = tfCurrentPwd.text!
        
        Http.instance().json(WebServices.changepassword, params, "POST", ai: true, popup: true, prnt: true, userInfo.Token(), sync: false) { (json, dict, str) in
            
            if json != nil {
                let json1 = json as? NSDictionary
                if number(json1! , "success").boolValue {
                    Http.alert("", string(json1! , "message"))
                    self.navigationController?.popViewController(animated: true)
                    }else {
                    Http.alert("", string(json1! , "message"))
                }
            }
        }
    }
    
    
    
    @IBAction func actionChangePassword(_ sender: Any) {
        self.view.endEditing(true)
        if let str = self.checkValidation() {
            Http.alert("", str)
            
        } else {
            ws_ChangePassword()
            
        }
        
    }
    override func viewWillDisappear(_ animated: Bool) {
        self.title = ""
    }
    
    
  

}

extension UIViewController {
    func setImageNavigation(){
        let logoContainer = UIView(frame: CGRect(x: 0, y: 0, width: 60, height: 60))
        // logoContainer.backgroundColor = UIColor.red
        let imageView = UIImageView(frame: CGRect(x: 10, y: 0, width: 40, height: 40))
        imageView.contentMode = .scaleAspectFit
        // imageView.backgroundColor = UIColor.yellow
        let image = UIImage(named: "logo_icon")
        imageView.image = image
        logoContainer.addSubview(imageView)
        navigationItem.titleView = logoContainer
    }
}


