//
//  ChangeNumberVC.swift
//  Washitto
//
//  Created by Himanshu on 20/06/18.
//  Copyright © 2018 Himanshu. All rights reserved.
//

import UIKit
import HarishFrameworkSwift4
class AddEmailVC: UIViewController ,UITextFieldDelegate{
    @IBOutlet var tfEmail: TextField!
    @IBOutlet var lblTitleMessage: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    override func viewWillAppear(_ animated: Bool) {

       
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }

   
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        let length = (textField.text?.count)! + string.count - range.length
        
        if tfEmail == textField {
            return (length > 40) ? false : true
        }
        return true
    }
    
    func checkValidation() -> String? {
        if tfEmail.text?.count == 0 {
            return "Please enter your email."
        } else if !Valid.email(tfEmail.text!) {
            return "Please enter valid email."
        }
        
        return nil
    }
    func ws_AddEmail() {
        let params = NSMutableDictionary()
        params["email"] = tfEmail.text!
        Http.instance().json(WebServices.changeemail, params, "POST", ai: true, popup: true, prnt: true, userInfo.Token(), sync: false) { (json, dict, str) in
            
            if json != nil {
                let json1 = json as? NSDictionary
                if number(json1! , "success").boolValue {
                    
                    let vc = self.storyboard?.instantiateViewController(withIdentifier: "VerifyEmailVC") as! VerifyEmailVC
                    vc.myemail = self.tfEmail.text!
                    self.navigationController?.pushViewController(vc, animated: true)
        
                    
                }else {
                    Http.alert("", string(json1! , "message"))
                }
            }
        }
    }
    
    @IBAction func actionSubmit(_ sender: Any) {
        if let str = self.checkValidation() {
            Http.alert("", str)
            
        } else {
            ws_AddEmail()
            
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        self.title = ""
    }
    
}
