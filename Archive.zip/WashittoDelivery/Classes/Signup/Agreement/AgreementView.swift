//
//  AgreementView.swift
//  WashittoDelivery
//
//  Created by Rahul on 09/07/18.
//  Copyright © 2018 Himanshu pal. All rights reserved.
//

import UIKit
import HarishFrameworkSwift4

class AgreementView: UIViewController {

    @IBOutlet var textMessage: UITextView!
    
    @IBOutlet var lblMSG: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.isNavigationBarHidden = true
        self.navigationItem.hidesBackButton = true

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    @IBOutlet var lblAgreementTitle: UILabel!
    
    override func viewWillAppear(_ animated: Bool) {
        textMessage.layer.cornerRadius = 5
        textMessage.layer.borderColor = UIColor.white.cgColor
        textMessage.layer.borderWidth = 1
        textMessage.textContainerInset  = UIEdgeInsetsMake(8,5,5,5)
        
        //        [self.textView setTextContainerInset:UIEdgeInsetsMake(0, 12, 0, 12)];
        ws_agreement_content()
    }
    
    func ws_agreement_content() {
        //        type = terms / policy / fleet_agreement / fcra_agreement / state_agreement / consent_agreement
        
        Http.instance().json(WebServices.agreement_content_type+"fleet_agreement", nil, "GET", ai: true, popup: true, prnt: true, sync: false) { (json, dict, str) in
            
            
            if let json1 = json as? NSDictionary {
                
                if number(json1 , "success").boolValue {
                    if let result = json1.object(forKey: "result") as? NSDictionary {
                        self.textMessage.text = string(result, "content")
                        self.lblAgreementTitle.text = string(result, "title")
                    }
                    
                    
                }
            }
        }
    }
    

    @IBAction func actionVerify(_ sender: Any) {
        ws_VerifyNumber()

    }
    
    // /content/type
    
    
    func ws_VerifyNumber() {
        let params = NSMutableDictionary()
//        params["otp"] = ""  type => fleet_agreement / fcra_agreement / state_agreement / consent_agreement
        params["type"] = "fleet_agreement"
        
        Http.instance().json(WebServices.accept_fleet, params, "POST", ai: true, popup: true, prnt: true, userInfo.Token(), sync: false) { (json, dict, str) in
            
            if json != nil {
                let json1 = json as? NSDictionary
                if number(json1! , "success").boolValue {
                    
//                    if let userdetail:NSDictionary = userInfo.getLoginInfo()  {
//                        print("userdetail ======>",userdetail)
////                        userInfo.saveLoginInfo(userdetail)
//                    }
                    
                    let vc = self.storyboard?.instantiateViewController(withIdentifier: "UserInformationView") as! UserInformationView
                    self.navigationController?.pushViewController(vc, animated: true)
                    

                    
                    
                }else {
                    Http.alert("", string(json1! , "message"))
                }
            }
        }
    }

}
