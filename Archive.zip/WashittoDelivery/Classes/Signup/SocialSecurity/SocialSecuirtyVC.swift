//
//  SocialSecuirtyVC.swift
//  Washitto
//
//  Created by Himanshu on 29/06/18.
//  Copyright © 2018 Himanshu. All rights reserved.
//

import UIKit
import HarishFrameworkSwift4
class SocialSecuirtyVC: UIViewController, UITextFieldDelegate {
    @IBOutlet var tfSocialSecurityNo: TextField!
    @IBOutlet var tfDob: TextField!
     @IBOutlet var datePicker: UIDatePicker!
    let dateFormatter = DateFormatter()
    @IBOutlet var viewPicker: UIView!
    @IBOutlet var viewAgreementBG: UIView!

    
    @IBOutlet var viewAgreement: UIScrollView!

    
    @IBOutlet var textMessage: UITextView!
    @IBOutlet var lblAgreementTitle: UILabel!



    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.isNavigationBarHidden = true
        self.navigationItem.hidesBackButton = true
//        viewAgreementBG.layer.cornerRadius  = 10
//        viewAgreementBG.clipsToBounds = true
        
        viewAgreement.isHidden = true

        dateFormatter.dateFormat = "yyyy-MM-dd"
        datePicker.backgroundColor = UIColor.white
        datePicker.setValue(UIColor.black, forKeyPath: "textColor")
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override func viewWillAppear(_ animated: Bool) {
        textMessage.layer.cornerRadius = 5
        textMessage.layer.borderColor = UIColor.white.cgColor
        textMessage.layer.borderWidth = 1
        textMessage.textContainerInset  = UIEdgeInsetsMake(8,5,5,5)
        
//        [self.textView setTextContainerInset:UIEdgeInsetsMake(0, 12, 0, 12)];
        ws_agreement_content()
        tfDob.rightViewMode = UITextFieldViewMode.always
        tfDob.rightView = UIView().addPaddingDynamic(UIImage(named:"CalendarTime.png")!, CGRect(x: 13, y: 10, width: 15, height: 15))
        
        
    }
    func ws_agreement_content() {
//        type = terms / policy / fleet_agreement / fcra_agreement / state_agreement / consent_agreement
//        http://18.206.160.19/washitto/api/v1/content/consent_agreement
        
//        let  param = NSMutableDictionary(dictionary: ["type":"consent_agreement"])
        
        Http.instance().json(WebServices.agreement_content_type+"consent_agreement", nil, "GET", ai: true, popup: true, prnt: true, sync: false) { (json, dict, str) in
            
            
            if let json1 = json as? NSDictionary {
                
                if number(json1 , "success").boolValue {
                    if let result = json1.object(forKey: "result") as? NSDictionary {
                        self.textMessage.text = string(result, "content")
                        self.lblAgreementTitle.text = string(result, "title")
                    }
                    
                    
                }
            }
        }
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
       textField.resignFirstResponder()
        
        return true
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        let length = (textField.text?.count)! + string.count - range.length
        
        if tfSocialSecurityNo == textField {
            
            let validCharacterSet = NSCharacterSet(charactersIn: APPConstants.emailAcceptableCharacter + "  ").inverted
            let filter = string.components(separatedBy: validCharacterSet)
            if filter.count == 1 {
                
                return (length > 15) ? false : true
            } else {
                return false
            }
        }
        return true
    }
    

    @IBAction func actionDob(_ sender: Any) {
       self.view.endEditing(true)
        
        self.datePicker.setDate(Date(), animated: false)
        self.datePicker.maximumDate = Date()
        
        UIView.animate(withDuration: 0.5, animations: {
            self.viewPicker.frame.origin.y = self.view.frame.size.height - self.viewPicker.frame.size.height
        })
    }
    var date_tmp = ""
      @IBAction func actionPickerDone(_ sender: Any) {
        
      
        date_tmp = dateFormatter.string(from: datePicker.date)
        dateFormatter.dateFormat = "dd MMM, yyyy"// "yyyy-MM-dd"
        
        tfDob.text = dateFormatter.string(from: datePicker.date)
        self.removePickerView()
    }
    
    @IBAction func actionPickerClose(_ sender: Any) {
        self.removePickerView()
    }
    func removePickerView() {
        UIView.animate(withDuration: 0.5, animations: {
            self.viewPicker.frame.origin.y = self.view.frame.size.height//+self.viewPicker.frame.size.height
        })
    }
    
    
    func checkValidation() -> String? {
        if tfSocialSecurityNo.text?.count == 0 {
            return "Please enter social security number."
        }else if tfDob.text?.count == 0 {
            return "Please enter dob."
        }
        return nil
    }
    
    
    func ws_Addsecurityinfo() {
        let params = NSMutableDictionary()
        params["ssn_number"] = tfSocialSecurityNo.text!
        params["dob"] = date_tmp
       
        Http.instance().json(WebServices.add_ssn, params, "POST", ai: true, popup: true, prnt: true, userInfo.Token(), sync: false) { (json, dict, str) in
            
            if json != nil {
                let json1 = json as? NSDictionary
                if number(json1! , "success").boolValue {
           
                     self.ws_VerifyNumber()
//                    if let userdetail:NSDictionary = userInfo.getLoginInfo()  {
//                        print("userdetail ======>",userdetail)
//                        userdetail.setValue(self.tfDob.text!, forKey: "dob")
//                        userdetail.setValue(self.tfSocialSecurityNo.text!, forKey: "ssn_number")
//                        userInfo.saveLoginInfo(userdetail)
//                    }
//
//                     self.navigationController?.viewControllers = []
//
                    
//                    let vc = self.storyboard?.instantiateViewController(withIdentifier: "RootViewCustomer") as! RootViewCustomer
//                     kappDelegate.window?.rootViewController = vc
                    
                    
           
                  Http.alert("", string(json1! , "message"))
                }else {
                    Http.alert("", string(json1! , "message"))
                }
            }
        }
    }
    
    
    @IBAction func actionSubmit(_ sender: Any) {
        self.view.endEditing(true)
        if let str = self.checkValidation() {
            
            Http.alert("", str)
            
        } else {
             viewAgreement.isHidden = false
            
            
            
        }
    }
    

    
    @IBAction func actionClose(_ sender: Any) {
        viewAgreement.isHidden = true

    }
  
    
    @IBAction func actionVerify(_ sender: Any) {
        ws_Addsecurityinfo()

    }
    
    
    func ws_VerifyNumber() {
        let params = NSMutableDictionary()
        //         / consent_agreement
//        params["type"] = "consent_agreement"
      
        Http.instance().json(WebServices.agreement_content_type+"consent_agreement", nil, "POST", ai: true, popup: true, prnt: true, userInfo.Token(), sync: false) { (json, dict, str) in
            
            if json != nil {
                let json1 = json as? NSDictionary
                if number(json1! , "success").boolValue {
                    //
                    
                    //                    if let userdetail:NSDictionary = userInfo.getLoginInfo()  {
                    //                        print("userdetail ======>",userdetail)
                    //                        //                        userInfo.saveLoginInfo(userdetail)
                    //                    }
//

                    let vc = self.storyboard?.instantiateViewController(withIdentifier: "AddSelfeView") as! AddSelfeView
                    self.navigationController?.pushViewController(vc, animated: true)

                }else {
                    Http.alert("", string(json1! , "message"))
                }
            }
        }
    }
  

}
