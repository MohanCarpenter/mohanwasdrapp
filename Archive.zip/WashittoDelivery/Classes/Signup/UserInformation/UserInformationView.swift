//
//  UserInformationView.swift
//  WashittoDelivery
//
//  Created by Rahul on 09/07/18.
//  Copyright © 2018 Himanshu pal. All rights reserved.
//

import UIKit
import HarishFrameworkSwift4

class UserInformationView: UIViewController ,UITextFieldDelegate{
    @IBOutlet var tfFirst: TextField!
    @IBOutlet var tfLast: TextField!
    @IBOutlet var tfMobile: TextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.isNavigationBarHidden = true
        self.navigationItem.hidesBackButton = true

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
        textField.resignFirstResponder()
        return true
    }
    
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        let length = (textField.text?.count)! + string.count - range.length
        if textField == tfMobile {
            
            let validCharacterSet = NSCharacterSet(charactersIn: APPConstants.phoneNoAcceptableCharacter).inverted
            let filter = string.components(separatedBy: validCharacterSet)
            if filter.count == 1 {
                
                return (length > 10) ? false : true
            } else {
                return false
            }
        }else {
    
            let validCharacterSet = NSCharacterSet(charactersIn: APPConstants.StateCharacter).inverted
            let filter = string.components(separatedBy: validCharacterSet)
            if filter.count == 1 {
                
                return (length > 30) ? false : true
            } else {
                return false
            }

        }
        
        return true
    }
    
    func checkValidation() -> String? {
        if tfFirst.text?.count == 0 {
            return "Please enter first name."
        }else  if tfLast.text?.count == 0 {
            return "Please enter last name."
        }else  if tfMobile.text?.count == 0 {
            return "Please enter mobile number."
        }else if tfMobile.text!.count < 10 {
            return "Please enter correct mobile number."
        }
//        else if tfFirst.text!.count < 7 {
//            return "Please enter correct verification code."
//        }
        
        return nil
    }
    
    
//    @IBAction func actionChangeNumber(_ sender: Any) {
//        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ChangeNumberVC") as! ChangeNumberVC
//        self.navigationController?.pushViewController(vc, animated: true)
//    }
    
    @IBAction func actionVerify(_ sender: Any) {
        if let str = self.checkValidation() {
            Http.alert("", str)
            
        } else {
            ws_VerifyNumber()
            
        }
    }
    
    
    func ws_VerifyNumber() {
      
        
        let params = NSMutableDictionary()
        params["first_name"] = tfFirst.text // !.replacingOccurrences(of: "-", with: "")
        params["last_name"] = tfLast.text
        params["phone_number"] = tfMobile.text
        Http.instance().json(WebServices.add_user_info, params, "POST", ai: true, popup: true, prnt: true, userInfo.Token(), sync: false) { (json, dict, str) in
            
            if json != nil {
                let json1 = json as? NSDictionary
                if number(json1! , "success").boolValue {
                    
                    if let userdetail:NSDictionary = userInfo.getLoginInfo()  {
//                        print("userdetail ======>",userdetail)
//                        userdetail.setValue(self.mobileNumber, forKey: "phone_number")
//                        userInfo.saveLoginInfo(userdetail)
                    }
                    let vc = self.storyboard?.instantiateViewController(withIdentifier: "VerifyNumberVC") as! VerifyNumberVC
                    vc.mobileNumber = self.tfMobile.text!
                    self.navigationController?.pushViewController(vc, animated: true)

                    
                    
              /*      if    kappDelegate.comefrom == "editprofile"{
                        
                        //self.navigationController?.backToViewController(vc: EditProfileVC.self)
                    }else{
                        if let userdetail:NSDictionary = userInfo.getLoginInfo()  {
                            print("userdetail ======>",userdetail)
                            if  (userdetail.object(forKey: "email")  == nil) {
                                
                                let vc = self.storyboard?.instantiateViewController(withIdentifier: "AddEmailVC") as! AddEmailVC
                                self.navigationController?.pushViewController(vc, animated: true)
                                
                                
                            }else{
                                let vc = self.storyboard?.instantiateViewController(withIdentifier: "VerifyEmailVC") as! VerifyEmailVC
                                vc.myemail = userdetail.object(forKey: "email") as! String
                                self.navigationController?.pushViewController(vc, animated: true)
                            }
                        }
                    }
                    */
                    
                }else {
                    Http.alert("", string(json1! , "message"))
                }
            }
        }
    }
   
}
