//
//  AddSelfeView.swift
//  WashittoDelivery
//
//  Created by Rahul on 11/07/18.
//  Copyright © 2018 Himanshu pal. All rights reserved.
//

import UIKit
import HarishFrameworkSwift4

class AddSelfeView: UIViewController ,UIImagePickerControllerDelegate , UINavigationControllerDelegate{
    @IBOutlet  var cameraContainerView:UIView!
    
    var imagePickers:UIImagePickerController?
    @IBOutlet weak var  userImageView:UIImageView!
    var image :UIImage?
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.isNavigationBarHidden = true
        self.navigationItem.hidesBackButton = true

        cameraContainerView.layer.cornerRadius   = cameraContainerView.frame.size.height/2
        self.cameraContainerView.clipsToBounds = true
        // Do any additional setup after loading the view.
    }
  
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


  
    @IBAction func cameraButtonPressed(_ sender: Any) {
        self.view.endEditing(true)
//        ScrlView.setContentOffset(CGPoint(x: 0, y: 0), animated: true)
        if let str = checkValidation() {
            Http.alert("", str)
        } else {
            self.ws_EditProfile()
        }
    }
    
    func checkValidation() -> String? {
        
        if image == nil  {
            return "Please select your image."
        }

//        if tfFirstName.text?.count == 0  {
//            return "Please enter first name."
//        }
//        else if tflastName.text!.count == 0  {
//            return "Please select region."
//        }
        
        
        return nil
    }
    func ws_EditProfile() {
        let params = NSMutableDictionary()
        let images = NSMutableArray()
        if image != nil {
            let md = NSMutableDictionary()
            md["param"] = "profile_image"
            md["image"] = image!
            images.add(md)
        }
          
        
        Http.instance().json(WebServices.add_selfie, params, "POST", ai: true, popup: true, prnt: true, userInfo.Token(), images, sync: false) { (json, params, strJson) in
            
            
            if json != nil {
                
                let json = json as? NSDictionary
                if number(json! , "success").boolValue {
                    
//                    Http.alert("", string(json! , "message"))
                    
                    self.ws_get_user()
//                    self.navigationController?.viewControllers = []
//                    let vc = self.storyboard?.instantiateViewController(withIdentifier: "RootViewCustomer") as! RootViewCustomer
//                    kappDelegate.window?.rootViewController = vc

                }
                
            }else {
                Http.alert("", string(json as! NSDictionary , "message"))
                
            }
        }
    }
    
    
  
    // /get-user
    func ws_get_user() {
        
        Http.instance().json(WebServices.getuser, nil, "GET", ai: true, popup: true, prnt: true, userInfo.Token(), sync: false) { (json, params, strJson) in
            
            
            if let json1 = json as? NSDictionary {
                
                
                if number(json1 , "success").boolValue {
                    
                    if let result = json1["result"] as? NSDictionary {
                        userInfo.saveLoginInfo(result)
                    }
                    
                    self.navigationController?.viewControllers = []
                    let vc = self.storyboard?.instantiateViewController(withIdentifier: "RootViewCustomer") as! RootViewCustomer
                    kappDelegate.window?.rootViewController = vc
                    
                }
                
            }else {
                Http.alert("", string(json as! NSDictionary , "message"))
                
            }
        }
    }
    @IBAction func actionUploadProfile(_ sender: Any) {
        self.view.endEditing(true)
        let actionSheet = UIAlertController(title: nil, message: nil, preferredStyle: UIAlertControllerStyle.actionSheet)
        
        let camera = "Camera"
        let gallery = "Gallery"
        let cancel = "Cancel"
        
        
        actionSheet.addAction(UIAlertAction(title: camera, style: UIAlertActionStyle.default, handler: { (alert:UIAlertAction!) -> Void in
            self.camera()
        }))
        
        actionSheet.addAction(UIAlertAction(title: gallery, style: UIAlertActionStyle.default, handler: { (alert:UIAlertAction!) -> Void in
            self.photoLibrary()
        }))
        
        actionSheet.addAction(UIAlertAction(title: cancel, style: UIAlertActionStyle.cancel, handler: nil))
        if UIDevice.current.userInterfaceIdiom == .pad {
            if let popoverController = actionSheet.popoverPresentationController {
                popoverController.sourceView = sender as? UIView
                popoverController.sourceRect = (sender as AnyObject).bounds
            }
        }
        self.present(actionSheet, animated: true, completion: nil)
    }
    
    
    
    
    func camera() {
        if UIImagePickerController.isSourceTypeAvailable(UIImagePickerControllerSourceType.camera) {
            let imagePicker = UIImagePickerController()
            imagePicker.delegate = self
            imagePicker.sourceType = UIImagePickerControllerSourceType.camera;
            imagePicker.allowsEditing = true
            self.present(imagePicker, animated: true, completion: nil)
        }
    }
    
    
    func photoLibrary() {
        if UIImagePickerController.isSourceTypeAvailable(UIImagePickerControllerSourceType.photoLibrary) {
            let imagePicker = UIImagePickerController()
            imagePicker.delegate = self
            imagePicker.sourceType = UIImagePickerControllerSourceType.photoLibrary;
            imagePicker.allowsEditing = true
            self.present(imagePicker, animated: true, completion: nil)
        }
    }
    
    
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        var img:UIImage? = info[UIImagePickerControllerOriginalImage] as? UIImage
        if let iii = info[UIImagePickerControllerEditedImage] as? UIImage {
            img = iii
        }
        if (img != nil) {
//              = img
            image = img
            userImageView.image = img
            
        }
        picker.dismiss(animated: true, completion: nil);
    }
    
    
    

    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated:true, completion: nil)

    }


    
}

/*
 @IBAction func cameraButtonPressed(_ sender: Any) {
 
 if UIImagePickerController.isSourceTypeAvailable(.camera){
 imagePickers?.takePicture()
 
 } else{
 
 //Camera not available.
 }
 //                     self.navigationController?.viewControllers = []
 //
 
 //                    let vc = self.storyboard?.instantiateViewController(withIdentifier: "RootViewCustomer") as! RootViewCustomer
 //                     kappDelegate.window?.rootViewController = vc
 
 }
 addImagePickerToContainerView()

 func addImagePickerToContainerView(){
 
 imagePickers = UIImagePickerController()
 if UIImagePickerController.isCameraDeviceAvailable( UIImagePickerControllerCameraDevice.front) {
 imagePickers?.delegate = self
 imagePickers?.sourceType = UIImagePickerControllerSourceType.camera
 imagePickers?.cameraDevice = UIImagePickerControllerCameraDevice.front
 //add as a childviewcontroller
 addChildViewController(imagePickers!)
 
 // Add the child's View as a subview
 self.cameraContainerView.addSubview((imagePickers?.view)!)
 imagePickers?.view.frame = CGRect(x: 0, y: 0, width: cameraContainerView.bounds.width + 20, height: cameraContainerView.bounds.height + 20)//cameraContainerView.bounds
 imagePickers?.allowsEditing = false
 imagePickers?.showsCameraControls = false
 imagePickers?.view.layer.cornerRadius   = cameraContainerView.frame.size.height/2
 
 imagePickers?.view.autoresizingMask = [.flexibleTopMargin, .flexibleRightMargin]
 // [.flexibleWidth, .flexibleHeight, .flexibleTopMargin, .flexibleRightMargin, .flexibleLeftMargin]
 }else {
 self.photoLibrary()
 
 }
 }
 */
