//
//  AddVehicleView.swift
//  WashittoDelivery
//
//  Created by Rahul on 10/07/18.
//  Copyright © 2018 Himanshu pal. All rights reserved.
//

import UIKit
import HarishFrameworkSwift4

class AddVehicleView: UIViewController , UITextFieldDelegate,  UINavigationControllerDelegate, UIPickerViewDelegate, UIPickerViewDataSource {
    
    //    @IBOutlet var tfAddress: TextField!
    @IBOutlet var scrollView: UIScrollView!
    @IBOutlet var tfCountry: UITextField!
    @IBOutlet var viewPicker: UIView!
    @IBOutlet var pickerView: UIPickerView!
    var edit = ""
    var comeFrom = ""
    var countryID = 0
    var is_license_required = 0
    var arrComman = NSMutableArray()
    var picker:UIImagePickerController? = UIImagePickerController()
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.isNavigationBarHidden = true
        self.navigationItem.hidesBackButton = true

        self.removePickerView()
        //  addDoneButtonOnKeyboard()
        registerForKeyboardNotifications()
        /*   self.navigationController?.isNavigationBarHidden = false
         navigationItem.hidesBackButton = false
         navigationController?.navigationBar.shouldRemoveShadow(true)*/
        self.viewPicker.frame.size.width = self.view.frame.size.width
         ws_countries()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        tfCountry.rightViewMode = UITextFieldViewMode.always
        tfCountry.rightView = UIView().addPaddingView(UIImage(named:"arrow_down_w")!)
        
        
    }
    
    
    
    override func viewWillDisappear(_ animated: Bool) {
        self.title  = ""
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    
    
    
    
    func checkValidation() -> String? {
        
       if tfCountry.text! == "Country" {
            return "Please select country"
        }
        
        return nil
    }
    
//    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
    
//        let length = (textField.text?.count)! + string.count - range.length
//
//        if textField == tfZipCode {
//
//            let validCharacterSet = NSCharacterSet(charactersIn: APPConstants.phoneNoAcceptableCharacter).inverted
//            let filter = string.components(separatedBy: validCharacterSet)
//            if filter.count == 1 {
//
//                return (length > 6) ? false : true
//            } else {
//                return false
//            }
//        }
        
//        return true
//    }
    
//    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
//        textField.resignFirstResponder()
//
//        return true
//    }
    
    //***************************************************************//
    //MARK:- KEYBOARD NOTIFICATION METHODS
    func registerForKeyboardNotifications() {
        let notificationCenter = NotificationCenter.default
        notificationCenter.addObserver(self, selector: #selector(adjustForKeyboard), name: Notification.Name.UIKeyboardWillHide, object: nil)
        notificationCenter.addObserver(self, selector: #selector(adjustForKeyboard), name: Notification.Name.UIKeyboardWillChangeFrame, object: nil)
    }
    
    func deregisterFromKeyboardNotifications() {
        NotificationCenter.default.removeObserver(self, name: .UIKeyboardWillShow, object: nil)
        NotificationCenter.default.removeObserver(self, name: .UIKeyboardWillHide, object: nil)
    }
    
    @objc func adjustForKeyboard(notification: Notification) {
        let userInfo = notification.userInfo!
        
        let keyboardScreenEndFrame = (userInfo[UIKeyboardFrameEndUserInfoKey] as! NSValue).cgRectValue
        let keyboardViewEndFrame = view.convert(keyboardScreenEndFrame, from: view.window)
        
        if notification.name == Notification.Name.UIKeyboardWillHide {
            scrollView.contentInset = UIEdgeInsets.zero
            
        } else {
            scrollView.contentInset = UIEdgeInsets(top: 0, left: 0, bottom: keyboardViewEndFrame.height + 10, right: 0)
        }
        
        scrollView.scrollIndicatorInsets = scrollView.contentInset
    }
    
    /////////__________***********************_________
    
    func addDoneButtonOnKeyboard() {
        let doneToolbar: UIToolbar = UIToolbar(frame: CGRect(x: 0, y: 0, width: 320, height: 50))
        doneToolbar.barStyle = UIBarStyle.blackTranslucent
        doneToolbar.barTintColor = appColor
        doneToolbar.tintColor = UIColor.white
        
        let flexSpace = UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.flexibleSpace, target: nil, action: nil)
        
        let next: UIBarButtonItem = UIBarButtonItem(title: "Next", style: UIBarButtonItemStyle.done, target: self, action: #selector(self.nextOfDoneTool))
        let done: UIBarButtonItem = UIBarButtonItem(title: "Done", style: UIBarButtonItemStyle.done, target: self, action: #selector(self.done))
        
        var items:[UIBarButtonItem] = []
        items.append(next)
        items.append(flexSpace)
        items.append(done)
        doneToolbar.items = items
        doneToolbar.sizeToFit()
//        self.tfZipCode.inputAccessoryView = doneToolbar
    }
    
    @objc func done() {
//        tfZipCode.resignFirstResponder()
    }
    
    @objc func nextOfDoneTool() {
        //        tfAddress.becomeFirstResponder()
    }
    
    
    
    //>>>>>>>>>>>>>>>>>>>>>>>> PICERVIEW >>>>>>>>>>>>>>>>>>>>>>>>>>>//
    //MARK:- PickerView Delegate & DataSource
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return arrComman.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        let dict = arrComman.object(at: row) as! NSDictionary
        return string(dict, "name")
/*
        if comeFrom == "country" {
            let dict = arrComman.object(at: row) as! NSDictionary
            return string(dict, "name")
        } else if comeFrom == "state" {
            let dict = arrComman.object(at: row) as! NSDictionary
            return string(dict, "name")
        } else {
            let dict = arrComman.object(at: row) as! NSDictionary
            return string(dict, "name")
        }*/
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
        /* if comeFrom == "country" {
         let dict = arrComman.object(at: row) as! NSDictionary
         self.tfCountry.text = string(dict, "name")
         countryID = string(dict, "id")
         
         } else if comeFrom == "state" {
         let dict = arrComman.object(at: row) as! NSDictionary
         self.tfState.text = string(dict, "name")
         stateID = string(dict, "id")
         
         } else {
         let dict = arrComman.object(at: row) as! NSDictionary
         self.tfCity.text = string(dict, "name")
         cityID = string(dict, "id")
         }*/
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
//        if textField == tfZipCode{
//            tfZipCode.becomeFirstResponder()
//        }
        
    }
    @IBAction func actionPickerDone(_ sender: Any) {
        
        if comeFrom == "country" {
        }
        let dictPkr = arrComman.object(at: pickerView.selectedRow(inComponent: 0)) as! NSDictionary
        tfCountry.text! = string(dictPkr, "name")
        
        countryID = Int(string(dictPkr, "id"))!
        is_license_required  = Int(string(dictPkr, "is_license_required"))!

//        else if comeFrom == "state" {
//            let dictPkr = arrComman.object(at: pickerView.selectedRow(inComponent: 0)) as! NSDictionary
//            tfState.text! = string(dictPkr, "name")
//            stateID = string(dictPkr, "id")
//
//        } else if comeFrom == "city" {
//            let dictPkr = arrComman.object(at: pickerView.selectedRow(inComponent: 0)) as! NSDictionary
//            tfCity.text! = string(dictPkr, "name")
//            cityID = string(dictPkr, "id")
//        }
        
        self.removePickerView()
    }
    
    @IBAction func actionPickerClose(_ sender: Any) {
        self.removePickerView()
    }
    
    func removePickerView() {
        viewPicker.isHidden = true
        UIView.animate(withDuration: 0.9, animations: {
            self.viewPicker.frame.origin.y = self.view.frame.size.height
        })
    }
    
    func addPickerView() {
        viewPicker.isHidden = false
        self.view.endEditing(true)
        pickerView.reloadAllComponents()
        pickerView.selectRow(0, inComponent: 0, animated: true)
        UIView.animate(withDuration: 0.5, animations: {
            self.viewPicker.frame.origin.y = self.view.frame.size.height - self.viewPicker.frame.size.height
        })
    }
    
    //================================
    
    //>>>>>>>>>>>>>>>>>>>>>>>> PICERVIEW >>>>>>>>>>>>>>>>>>>>>>>>>>>//
    func ws_countries() {
        Http.instance().json(WebServices.vehicle_list, nil, "GET", ai: true, popup: true, prnt: true, sync: false) { (json, dict, str) in
            
            if json != nil {
                let json1 = json as? NSDictionary
                if number(json1! , "success").boolValue {
                    self.arrComman = NSMutableArray()
                    if let result = json1?.object(forKey: "result") as? NSArray {
                        self.arrComman = result.mutableCopy() as! NSMutableArray
                        if self.isFirstTime {
                            self.pickerView.selectRow(0, inComponent: 0, animated: true)
                            self.addPickerView()

                        }
                    }
                } else {
                    let msg = string(json1!, "message")
                    let alert = UIAlertController(title: "", message: msg, preferredStyle: UIAlertControllerStyle.alert)
                    alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
                    if UIDevice.current.userInterfaceIdiom == .pad {
                        if let popoverController = alert.popoverPresentationController {
                            popoverController.sourceView = self.view
                            popoverController.sourceRect = self.view.bounds
                        }
                    }
                    self.present(alert, animated: true, completion: nil)
                }
            }
        }
    }
    

    
    @IBAction func actionupdateProfile(_ sender: Any) {
        self.view.endEditing(true)
        if let str = self.checkValidation() {
            Http.alert("", str)
            
        } else {
            
            ws_addProfile()
        }
        
    }
    
    
    
    
    func ws_addProfile() {
        
     
        
        let params = NSMutableDictionary()
        params["vehicle_id"] = countryID
        
        Http.instance().json(WebServices.add_vehicle, params, "POST", ai: true, popup: true, prnt: true, userInfo.Token(), sync: false) { (json, dict, str) in
            
            if let json1 = json as? NSDictionary {
                
                if number(json1 , "success").boolValue {

                    if self.is_license_required == 1 {
                        let vc = self.storyboard?.instantiateViewController(withIdentifier: "AddLicenseinforView") as! AddLicenseinforView
                        self.navigationController?.pushViewController(vc, animated: true)

                    }else {
                        let vc = self.storyboard?.instantiateViewController(withIdentifier: "AgreementFCRAView") as! AgreementFCRAView
                        self.navigationController?.pushViewController(vc, animated: true)
                        
                    }

                    
                    
                } else {
                    Http.alert("", string(json1 , "message"))
                }
            }
        }
    }
    var isFirstTime = false
    @IBAction func actionCountry(_ sender: Any) {
        self.view.endEditing(true)
//        comeFrom = "country"
        self.isFirstTime = true
        
//        self.arrComman = result.mutableCopy() as! NSMutableArray
        if self.arrComman.count > 0 {
            self.pickerView.selectRow(0, inComponent: 0, animated: true)
            self.addPickerView()

        }else{
            ws_countries()
        }
       
    }
    
  
    
    
    
}

