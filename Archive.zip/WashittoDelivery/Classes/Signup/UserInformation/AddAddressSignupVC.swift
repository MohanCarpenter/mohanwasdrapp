//
//  EditProfileVC.swift
//  EcoGadiDriver
//
//  Created by Kavya Mac Mini 1 on 20/06/18.
//  Copyright © 2018 Kavya Mac Mini 1. All rights reserved.
//

import UIKit
import HarishFrameworkSwift4
import CoreLocation
import GooglePlaces
import GooglePlacePicker

class AddAddressSignupVC: UIViewController, UITextFieldDelegate,  UINavigationControllerDelegate, UIPickerViewDelegate, UIPickerViewDataSource , CLLocationManagerDelegate, GMSPlacePickerViewControllerDelegate{
    
    @IBOutlet var btnAddEditButton: Button!
    @IBOutlet var tfZipCode: TextField!
    @IBOutlet var tfApartment: TextField!

    @IBOutlet var tfAddress: TextField!
    @IBOutlet var scrollView: UIScrollView!
    @IBOutlet var tfCountry: UITextField!
    @IBOutlet var tfState: UITextField!
    @IBOutlet var tfCity: UITextField!
    @IBOutlet var viewPicker: UIView!
    @IBOutlet var pickerView: UIPickerView!
    var edit = ""
    var comeFrom = ""
    var countryID = ""
    var stateID = ""
    var cityID = ""
    var arrComman = NSMutableArray()
    var boolProfilePicture = false
    var imgProfilePicture:UIImage? = nil
    var picker:UIImagePickerController? = UIImagePickerController()
    
//    var mydict:AddressListClass?
    var  lat = Double()
    var long = Double()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.removePickerView()
      //  addDoneButtonOnKeyboard()
        registerForKeyboardNotifications()
     /*   self.navigationController?.isNavigationBarHidden = false
        navigationItem.hidesBackButton = false
        navigationController?.navigationBar.shouldRemoveShadow(true)*/
         self.viewPicker.frame.size.width = self.view.frame.size.width
        
        tfAddress.text = "Number and Name"
        tfCountry.text = "Country"
        
        self.navigationController?.isNavigationBarHidden = true
        self.navigationItem.hidesBackButton = true
        setDefoultContry()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        tfCountry.rightViewMode = UITextFieldViewMode.always
        tfCity.rightViewMode = UITextFieldViewMode.always
        tfCountry.rightView = UIView().addPaddingView(UIImage(named:"arrow_down_w")!)
        tfState.rightView = UIView().addPaddingView(UIImage(named:"arrow_down_w")!)
        tfState.rightViewMode = UITextFieldViewMode.always
        tfCity.rightView = UIView().addPaddingView(UIImage(named:"arrow_down_w")!)

    
    }
    

    
    override func viewWillDisappear(_ animated: Bool) {
        self.title  = ""
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
   
    
   
    func setDefoultContry(){
    
        // set default country and state
        tfCountry.text! = "United States"
        countryID =  "231"
        
        tfState.text! = "New York"
        stateID = "3956"

     
    }
    
    
    func checkValidation() -> String? {
        
        
        if tfAddress.text == "Number and Name" {
            return "Please select address"
        }else if tfZipCode.text?.count == 0 {
            return "Please enter zipcode."
        }
            
        else  if tfCountry.text! == "Country" {
            return "Please select country"
        } else if tfState.text! == "State" ||   tfState.text! == ""  {
            return "Please select state"
            
        } else if tfCity.text! == "City" || tfCity.text! == "" {
            return "Please select city"
        }
        else if tfApartment.text?.count == 0 {
            return "Please select apartment"
        }

        return nil
    }

    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        let length = (textField.text?.count)! + string.count - range.length
        
        if textField == tfApartment {
            
            let validCharacterSet = NSCharacterSet(charactersIn: APPConstants.ZipCodeAcceptableCharacter+" ,").inverted
            let filter = string.components(separatedBy: validCharacterSet)
            if filter.count == 1 {
                
                return (length > 30) ? false : true
            } else {
                return false
            }
        }else if textField == tfZipCode {
            
            let validCharacterSet = NSCharacterSet(charactersIn: APPConstants.phoneNoAcceptableCharacter).inverted
            let filter = string.components(separatedBy: validCharacterSet)
            if filter.count == 1 {
                
                return (length > 6) ? false : true
            } else {
                return false
            }
        }
        
        return true
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        
        return true
    }
    
    //***************************************************************//
    //MARK:- KEYBOARD NOTIFICATION METHODS
    func registerForKeyboardNotifications() {
        let notificationCenter = NotificationCenter.default
        notificationCenter.addObserver(self, selector: #selector(adjustForKeyboard), name: Notification.Name.UIKeyboardWillHide, object: nil)
        notificationCenter.addObserver(self, selector: #selector(adjustForKeyboard), name: Notification.Name.UIKeyboardWillChangeFrame, object: nil)
    }
    
    func deregisterFromKeyboardNotifications() {
        NotificationCenter.default.removeObserver(self, name: .UIKeyboardWillShow, object: nil)
        NotificationCenter.default.removeObserver(self, name: .UIKeyboardWillHide, object: nil)
    }
    
    @objc func adjustForKeyboard(notification: Notification) {
        let userInfo = notification.userInfo!
        
        let keyboardScreenEndFrame = (userInfo[UIKeyboardFrameEndUserInfoKey] as! NSValue).cgRectValue
        let keyboardViewEndFrame = view.convert(keyboardScreenEndFrame, from: view.window)
        
        if notification.name == Notification.Name.UIKeyboardWillHide {
            scrollView.contentInset = UIEdgeInsets.zero
            
        } else {
            scrollView.contentInset = UIEdgeInsets(top: 0, left: 0, bottom: keyboardViewEndFrame.height + 10, right: 0)
        }
        
        scrollView.scrollIndicatorInsets = scrollView.contentInset
    }
    
    /////////__________***********************_________
    
    func addDoneButtonOnKeyboard() {
        let doneToolbar: UIToolbar = UIToolbar(frame: CGRect(x: 0, y: 0, width: 320, height: 50))
        doneToolbar.barStyle = UIBarStyle.blackTranslucent
        doneToolbar.barTintColor = appColor
        doneToolbar.tintColor = UIColor.white
        
        let flexSpace = UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.flexibleSpace, target: nil, action: nil)
        
        let next: UIBarButtonItem = UIBarButtonItem(title: "Next", style: UIBarButtonItemStyle.done, target: self, action: #selector(self.nextOfDoneTool))
        let done: UIBarButtonItem = UIBarButtonItem(title: "Done", style: UIBarButtonItemStyle.done, target: self, action: #selector(self.done))
        
        var items:[UIBarButtonItem] = []
        items.append(next)
        items.append(flexSpace)
        items.append(done)
        doneToolbar.items = items
        doneToolbar.sizeToFit()
        self.tfZipCode.inputAccessoryView = doneToolbar
        self.tfApartment.inputAccessoryView = doneToolbar

    }
    
    @objc func done() {
        tfZipCode.resignFirstResponder()
        tfApartment.resignFirstResponder()

    }
    
    @objc func nextOfDoneTool() {
//        tfAddress.becomeFirstResponder()
        tfApartment.resignFirstResponder()
        tfZipCode.resignFirstResponder()

    }
    
    
    
    //>>>>>>>>>>>>>>>>>>>>>>>> PICERVIEW >>>>>>>>>>>>>>>>>>>>>>>>>>>//
    //MARK:- PickerView Delegate & DataSource
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return arrComman.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
     
        if comeFrom == "country" {
            let dict = arrComman.object(at: row) as! NSDictionary
            return string(dict, "name")
        } else if comeFrom == "state" {
            let dict = arrComman.object(at: row) as! NSDictionary
            return string(dict, "name")
        } else {
            let dict = arrComman.object(at: row) as! NSDictionary
            return string(dict, "name")
        }
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
       
       /* if comeFrom == "country" {
            let dict = arrComman.object(at: row) as! NSDictionary
            self.tfCountry.text = string(dict, "name")
            countryID = string(dict, "id")
            
        } else if comeFrom == "state" {
            let dict = arrComman.object(at: row) as! NSDictionary
            self.tfState.text = string(dict, "name")
            stateID = string(dict, "id")
            
        } else {
            let dict = arrComman.object(at: row) as! NSDictionary
            self.tfCity.text = string(dict, "name")
            cityID = string(dict, "id")
        }*/
    }

    func textFieldDidBeginEditing(_ textField: UITextField) {
//        if textField == tfZipCode{
//            tfZipCode.becomeFirstResponder()
//        }
       
    }
    @IBAction func actionPickerDone(_ sender: Any) {

        if arrComman.count == 0 {
            return
        }
        if comeFrom == "country" {
            let dictPkr = arrComman.object(at: pickerView.selectedRow(inComponent: 0)) as! NSDictionary
            tfCountry.text! = string(dictPkr, "name")
            countryID = string(dictPkr, "id")
            
        } else if comeFrom == "state" {
            let dictPkr = arrComman.object(at: pickerView.selectedRow(inComponent: 0)) as! NSDictionary
            tfState.text! = string(dictPkr, "name")
            stateID = string(dictPkr, "id")
            
        } else if comeFrom == "city" {
            let dictPkr = arrComman.object(at: pickerView.selectedRow(inComponent: 0)) as! NSDictionary
            tfCity.text! = string(dictPkr, "name")
            cityID = string(dictPkr, "id")
        }
        
        self.removePickerView()
    }
    
    @IBAction func actionPickerClose(_ sender: Any) {
        self.removePickerView()
    }
    
    func removePickerView() {
        viewPicker.isHidden = true
        UIView.animate(withDuration: 0.9, animations: {
            self.viewPicker.frame.origin.y = self.view.frame.size.height
        })
    }
    
    func addPickerView() {
        viewPicker.isHidden = false
        self.view.endEditing(true)
        pickerView.reloadAllComponents()
        pickerView.selectRow(0, inComponent: 0, animated: true)
        UIView.animate(withDuration: 0.5, animations: {
            self.viewPicker.frame.origin.y = self.view.frame.size.height - self.viewPicker.frame.size.height
        })
    }
    
    //================================
    
    //>>>>>>>>>>>>>>>>>>>>>>>> PICERVIEW >>>>>>>>>>>>>>>>>>>>>>>>>>>//
    func ws_countries() {
        Http.instance().json(WebServices.countries, nil, "GET", ai: true, popup: true, prnt: true, sync: false) { (json, dict, str) in
            
            if json != nil {
                let json1 = json as? NSDictionary
                if number(json1! , "success").boolValue {
                    self.arrComman = NSMutableArray()
                    if let result = json1?.object(forKey: "result") as? NSArray {
                        self.arrComman = result.mutableCopy() as! NSMutableArray
                        self.pickerView.selectRow(0, inComponent: 0, animated: true)
                        self.addPickerView()
                    }
                } else {
                    let msg = string(json1!, "message")
                     let alert = UIAlertController(title: "", message: msg, preferredStyle: UIAlertControllerStyle.alert)
                     alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
                    if UIDevice.current.userInterfaceIdiom == .pad {
                        if let popoverController = alert.popoverPresentationController {
                            popoverController.sourceView = self.view
                            popoverController.sourceRect = self.view.bounds
                        }
                    }
                     self.present(alert, animated: true, completion: nil)
                }
            }
        }
    }
    
    func ws_state() {
        let params = NSMutableDictionary()
        params["country_id"] = countryID
        
        Http.instance().json(WebServices.states, params, "GET", ai: true, popup: true, prnt: true, sync: false) { (json, dict, str) in
            
            if json != nil {
                let json1 = json as? NSDictionary
                if number(json1! , "success").boolValue {
                    self.arrComman = NSMutableArray()
                    if let result = json1?.object(forKey: "result") as? NSArray {
                        self.arrComman = result.mutableCopy() as! NSMutableArray
                        self.pickerView.selectRow(0, inComponent: 0, animated: true)
                        self.addPickerView()
                    }
                } else {
                    let msg = string(json1!, "msg")
                     let alert = UIAlertController(title: "", message: msg, preferredStyle: UIAlertControllerStyle.alert)
                     alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
                    if UIDevice.current.userInterfaceIdiom == .pad {
                        if let popoverController = alert.popoverPresentationController {
                            popoverController.sourceView = self.view
                            popoverController.sourceRect = self.view.bounds
                        }
                    }
                     self.present(alert, animated: true, completion: nil)
                }
            }
        }
    }
    
    func ws_city() {
        let params = NSMutableDictionary()
        params["state_id"] = stateID
        
        Http.instance().json(WebServices.cities, params, "GET", ai: true, popup: true, prnt: true, sync: false) { (json, dict, str) in
            
            if json != nil {
                let json1 = json as? NSDictionary
                if number(json1! , "success").boolValue {
                    self.arrComman = NSMutableArray()
                    if let result = json1?.object(forKey: "result") as? NSArray {
                        self.arrComman = result.mutableCopy() as! NSMutableArray
                        self.pickerView.reloadAllComponents()
                        self.pickerView.selectRow(0, inComponent: 0, animated: true)
                        self.addPickerView()
                    }
                } else {
                    let msg = string(json1!, "msg")
                     let alert = UIAlertController(title: "", message: msg, preferredStyle: UIAlertControllerStyle.alert)
                     alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
                    if UIDevice.current.userInterfaceIdiom == .pad {
                        if let popoverController = alert.popoverPresentationController {
                            popoverController.sourceView = self.view
                            popoverController.sourceRect = self.view.bounds
                        }
                    }
                     self.present(alert, animated: true, completion: nil)
                }
            }
        }
    }
    
    
    @IBAction func actionupdateProfile(_ sender: Any) {
        self.view.endEditing(true)
        if let str = self.checkValidation() {
            Http.alert("", str)
            
        } else {
        
             ws_addProfile()
        }
        
    }
    
    

    
    func ws_addProfile() {
        /*"address:sundaram complex
         zipcode:452001
         apartment:1st flor
         country_id:101
         state_id:21
         city_id:2229
         latitude:22.67777
         longitude:75.84477"*/
        let params = NSMutableDictionary()
        params["apartment"] = tfApartment.text!
        params["address"] = tfAddress.text!
        params["city_id"] = cityID
        params["country_id"] = countryID
        params["state_id"] = stateID
        params["latitude"] = lat
        params["longitude"] = long
       params["zipcode"] = tfZipCode.text!

       Http.instance().json(WebServices.addressadd, params, "POST", ai: true, popup: true, prnt: true, userInfo.Token(), sync: false) { (json, dict, str) in
            
            if json != nil {
                let json1 = json as? NSDictionary
                if number(json1! , "success").boolValue {
                   
                    let dd = UserDefaults.standard
                    if let id = Int(self.countryID) {
                        dd.set(id, forKey: "country_id")
                    }else {
                        dd.set(self.countryID, forKey: "country_id")
                    }
                    dd.synchronize()
                 //   setValue(self.countryID, forKey: "country_id")

                    let vc = self.storyboard?.instantiateViewController(withIdentifier: "AddMarketView") as! AddMarketView
                    self.navigationController?.pushViewController(vc, animated: true)

//                    let vc = self.storyboard?.instantiateViewController(withIdentifier: "SocialSecuirtyVC")as! SocialSecuirtyVC
//                    self.navigationController?.pushViewController(vc, animated: true)
                    
                    
                    
                } else {
                    Http.alert("", string(json1! , "message"))
                }
            }
        }
    }
    
    @IBAction func actionCountry(_ sender: Any) {
        self.view.endEditing(true)
        comeFrom = "country"
        tfState.text! = ""
        tfCity.text! = ""
        countryID = ""
        stateID = ""
        cityID = ""
        ws_countries()
    }
    
    @IBAction func actionState(_ sender: Any) {
        
        self.view.endEditing(true)
        comeFrom = "state"
        if countryID != "" {
            tfCity.text! = ""
            ws_state()
        } else {
            Http.alert("", "Please first select country.")
            //                let alert = UIAlertController(title: "", message: "Please first select country.", preferredStyle: UIAlertControllerStyle.alert)
            //                alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
            //                self.present(alert, animated: true, completion: nil)
        }
        
    }
    @IBAction func actionCity(_ sender: Any) {
        if countryID != "" && stateID != ""{
            comeFrom = "city"
            self.view.endEditing(true)
            ws_city()
        } else {
            Http.alert("", "Please first select state.")
            
        }

    }
    
    @IBAction func actionplacePicker(_ sender: Any) {
        tfAddress.text = ""
        let config = GMSPlacePickerConfig(viewport: nil)
        let placePicker = GMSPlacePickerViewController(config: config)
        
        placePicker.delegate = self
        
        let autocompleteController = GMSAutocompleteViewController()
        autocompleteController.delegate = self as? GMSAutocompleteViewControllerDelegate
        UINavigationBar.appearance().tintColor = UIColor.white
        //UISearchBar.appearance.textField.setTextColor = UIColor.red
        if #available(iOS 9.0, *) {
            UITextField.appearance(whenContainedInInstancesOf: [UISearchBar.self]).defaultTextAttributes = [NSAttributedStringKey.foregroundColor.rawValue: UIColor.white]
        } else {
            // Fallback on earlier versions
        }
        UISearchBar.appearance().barStyle = UIBarStyle.default
    //    self.present(autocompleteController, animated: true, completion:nil)
        
        
        present(placePicker, animated: true, completion: nil)
        
    }
    var locationCoordinates = CLLocationCoordinate2D()
    func placePicker(_ viewController: GMSPlacePickerViewController, didPick place: GMSPlace) {
        // Dismiss the place picker, as it cannot dismiss itself.
        viewController.dismiss(animated: true, completion: nil)
        
//print("Place name --->\(place.name) -placeID------>\(place.placeID) -place----->\(place)")

        
       locationCoordinates = place.coordinate
        lat = locationCoordinates.latitude
        long = locationCoordinates.longitude
        
        if let add = place.formattedAddress {
        if String(place.name) != "" {
          //  print("Place address ----->\(add)")
            
            self.tfAddress.text = String(place.name)
            
        }else {
            searchAddress()
            
            
        }
        }else{
          searchAddress()
        }
    }
    
    func searchAddress(){
        let strApi = "https://maps.googleapis.com/maps/api/geocode/json?address=\(lat),\(long)&key=\(APPConstants.googleApiKey)"
        
        
        print(strApi)
        Http.instance().json(strApi, nil, "GET", ai: true, popup: false, prnt: false, completionHandler: { (json, params, responce)  in
            
            if let result1 = json   {
            print("json>>\(json!)")
              
                if let result = (result1 as AnyObject).object(forKey: "results") as? NSArray {
                    var zero = ""
                    var one = ""
                    var two = ""
                    var three = ""
                    var four = ""
                    if let address = result.object(at: 0)as? NSDictionary {
                       // print(address)
                        if let addresscomponents = address.object(forKey: "address_components")as? NSArray{
                            if   let number  = addresscomponents.object(at: 0)as? NSDictionary{
                                zero = string(number, "long_name")
                            }
                            
                            if   let number  = addresscomponents.object(at: 1)as? NSDictionary{
                                one = string(number, "long_name")
                            }
                            if   let number  = addresscomponents.object(at: 2)as? NSDictionary{
                                two = string(number, "long_name")
                            }
                            if   let number  = addresscomponents.object(at: 3)as? NSDictionary{
                                three = string(number, "long_name")
                            }
                            if   let number  = addresscomponents.object(at: 4)as? NSDictionary{
                                four = string(number, "long_name")
                            }
                           
                        }
                       
                    }
                   
                    self.tfAddress.text = String(format: "%@ %@, %@ %@",one,two,three,four)
                    
                    
                }
                
            }
        })
    }
    
    func placePickerDidCancel(_ viewController: GMSPlacePickerViewController) {
        // Dismiss the place picker, as it cannot dismiss itself.
        viewController.dismiss(animated: true, completion: nil)
        
        print("No place selected")
    }
    
}
