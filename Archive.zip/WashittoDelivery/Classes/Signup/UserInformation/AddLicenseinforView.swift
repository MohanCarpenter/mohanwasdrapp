//
//  AddLicenseinforView.swift
//  WashittoDelivery
//
//  Created by Rahul on 11/07/18.
//  Copyright © 2018 Himanshu pal. All rights reserved.
//

import UIKit
import HarishFrameworkSwift4

class AddLicenseinforView: UIViewController, UITextFieldDelegate,  UINavigationControllerDelegate, UIPickerViewDelegate, UIPickerViewDataSource {
    
    //    @IBOutlet var tfAddress: TextField!
    @IBOutlet var scrollView: UIScrollView!
    @IBOutlet var tfexpiration_date: UITextField!
    @IBOutlet var viewPicker: UIView!
    @IBOutlet var pickerView: UIPickerView!
     @IBOutlet var tflicence_number: TextField!
    @IBOutlet var tfState: TextField!

    
    @IBOutlet var datePicker: UIDatePicker!
    let dateFormatter = DateFormatter()
    @IBOutlet var viewDatePicker: UIView!

    
    
    var edit = ""
    var comeFrom = ""
    var countryID = ""
    var stateID = ""
    var arrComman = NSMutableArray()
    var picker:UIImagePickerController? = UIImagePickerController()
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.isNavigationBarHidden = true
        self.navigationItem.hidesBackButton = true

        self.removePickerView()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        datePicker.backgroundColor = UIColor.white
        datePicker.setValue(UIColor.black, forKeyPath: "textColor")

        //  addDoneButtonOnKeyboard()
        registerForKeyboardNotifications()
        /*   self.navigationController?.isNavigationBarHidden = false
         navigationItem.hidesBackButton = false
         navigationController?.navigationBar.shouldRemoveShadow(true)*/
        self.viewPicker.frame.size.width = self.view.frame.size.width
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        if let id11 = UserDefaults.standard.value(forKey: "country_id") as? String {
            countryID = id11
            
        }else if let id11 = UserDefaults.standard.value(forKey: "country_id") as? Int {
            countryID = String(id11)
        }else {
            countryID = "231"
        }
        
        
        tfexpiration_date.rightViewMode = UITextFieldViewMode.always
        tfexpiration_date.rightView = UIView().addPaddingView(UIImage(named:"arrow_down_w")!)
        
        tfState.rightViewMode = UITextFieldViewMode.always
        tfState.rightView = UIView().addPaddingView(UIImage(named:"arrow_down_w")!)
       
//        tflicence_number.text = "licence Number"
        tfexpiration_date.text! = "Expiration Date"
        tfState.text! = "State"

        
    }
    
    
    
    override func viewWillDisappear(_ animated: Bool) {
        self.title  = ""
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    
    
    
    
    func checkValidation() -> String? {
        if tflicence_number.text == "" && tflicence_number.text?.count == 0{
            return "Please enter licence number"
        }else if tfState.text! == "State" ||   tfState.text! == ""  {
            return "Please select state"
            
        }else if tfexpiration_date.text! == "Expiration Date" {
            return "Please select expiration date"
        }
     
        return nil
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        let length = (textField.text?.count)! + string.count - range.length
        if textField == tflicence_number {
            
            let validCharacterSet = NSCharacterSet(charactersIn: APPConstants.emailAcceptableCharacter + "  ").inverted
            let filter = string.components(separatedBy: validCharacterSet)
            if filter.count == 1 {
                
                return (length > 30) ? false : true
            } else {
                return false
            }
        }
        
        return true
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        
        return true
    }
    
    //***************************************************************//
    //MARK:- KEYBOARD NOTIFICATION METHODS
    func registerForKeyboardNotifications() {
        let notificationCenter = NotificationCenter.default
        notificationCenter.addObserver(self, selector: #selector(adjustForKeyboard), name: Notification.Name.UIKeyboardWillHide, object: nil)
        notificationCenter.addObserver(self, selector: #selector(adjustForKeyboard), name: Notification.Name.UIKeyboardWillChangeFrame, object: nil)
    }
    
    func deregisterFromKeyboardNotifications() {
        NotificationCenter.default.removeObserver(self, name: .UIKeyboardWillShow, object: nil)
        NotificationCenter.default.removeObserver(self, name: .UIKeyboardWillHide, object: nil)
    }
    
    @objc func adjustForKeyboard(notification: Notification) {
        let userInfo = notification.userInfo!
        
        let keyboardScreenEndFrame = (userInfo[UIKeyboardFrameEndUserInfoKey] as! NSValue).cgRectValue
        let keyboardViewEndFrame = view.convert(keyboardScreenEndFrame, from: view.window)
        
        if notification.name == Notification.Name.UIKeyboardWillHide {
            scrollView.contentInset = UIEdgeInsets.zero
            
        } else {
            scrollView.contentInset = UIEdgeInsets(top: 0, left: 0, bottom: keyboardViewEndFrame.height + 10, right: 0)
        }
        
        scrollView.scrollIndicatorInsets = scrollView.contentInset
    }
    
    /////////__________***********************_________
    
    func addDoneButtonOnKeyboard() {
        let doneToolbar: UIToolbar = UIToolbar(frame: CGRect(x: 0, y: 0, width: 320, height: 50))
        doneToolbar.barStyle = UIBarStyle.blackTranslucent
        doneToolbar.barTintColor = appColor
        doneToolbar.tintColor = UIColor.white
        
        let flexSpace = UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.flexibleSpace, target: nil, action: nil)
        
        let next: UIBarButtonItem = UIBarButtonItem(title: "Next", style: UIBarButtonItemStyle.done, target: self, action: #selector(self.nextOfDoneTool))
        let done: UIBarButtonItem = UIBarButtonItem(title: "Done", style: UIBarButtonItemStyle.done, target: self, action: #selector(self.done))
        
        var items:[UIBarButtonItem] = []
        items.append(next)
        items.append(flexSpace)
        items.append(done)
        doneToolbar.items = items
        doneToolbar.sizeToFit()
        self.tflicence_number.inputAccessoryView = doneToolbar
    }
    
    @objc func done() {
          tflicence_number.resignFirstResponder()
    }
    
    @objc func nextOfDoneTool() {
        tflicence_number.resignFirstResponder()
    }
    
    
    
    //>>>>>>>>>>>>>>>>>>>>>>>> PICERVIEW >>>>>>>>>>>>>>>>>>>>>>>>>>>//
    //MARK:- PickerView Delegate & DataSource
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return arrComman.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        
//        if comeFrom == "country" {
//            let dict = arrComman.object(at: row) as! NSDictionary
//            return string(dict, "name")
//        } else
            if comeFrom == "state" {
            let dict = arrComman.object(at: row) as! NSDictionary
            return string(dict, "name")
        } else {
            let dict = arrComman.object(at: row) as! NSDictionary
            return string(dict, "name")
        }
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
        /* if comeFrom == "country" {
         let dict = arrComman.object(at: row) as! NSDictionary
         self.tfexpiration_date.text = string(dict, "name")
         countryID = string(dict, "id")
         
         } else if comeFrom == "state" {
         let dict = arrComman.object(at: row) as! NSDictionary
         self.tfState.text = string(dict, "name")
         stateID = string(dict, "id")
         
         } else {
         let dict = arrComman.object(at: row) as! NSDictionary
         self.tfCity.text = string(dict, "name")
         cityID = string(dict, "id")
         }*/
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        //        if textField == tfZipCode{
        //            tfZipCode.becomeFirstResponder()
        //        }
        
    }
    @IBAction func actionPickerDone(_ sender: Any) {
        
//        if comeFrom == "country" {
//            let dictPkr = arrComman.object(at: pickerView.selectedRow(inComponent: 0)) as! NSDictionary
//            tfexpiration_date.text! = string(dictPkr, "name")
//            countryID = string(dictPkr, "id")
//
//        }
        let dictPkr = arrComman.object(at: pickerView.selectedRow(inComponent: 0)) as! NSDictionary
        tfState.text! = string(dictPkr, "name")
        stateID = string(dictPkr, "id")

        //        else if comeFrom == "state" {
        //            let dictPkr = arrComman.object(at: pickerView.selectedRow(inComponent: 0)) as! NSDictionary
        //            tfState.text! = string(dictPkr, "name")
        //            stateID = string(dictPkr, "id")
        //
        //        }
//        else if comeFrom == "city" {
        //            let dictPkr = arrComman.object(at: pickerView.selectedRow(inComponent: 0)) as! NSDictionary
        //            tfCity.text! = string(dictPkr, "name")
        //            cityID = string(dictPkr, "id")
        //        }
        
        self.removePickerView()
    }
    
    @IBAction func actionPickerClose(_ sender: Any) {
        self.removePickerView()
    }
    
    func removePickerView() {
        viewPicker.isHidden = true
        UIView.animate(withDuration: 0.9, animations: {
            self.viewPicker.frame.origin.y = self.view.frame.size.height
        })
    }
    
    func addPickerView() {
        viewPicker.isHidden = false
        self.view.endEditing(true)
        pickerView.reloadAllComponents()
        pickerView.selectRow(0, inComponent: 0, animated: true)
        UIView.animate(withDuration: 0.5, animations: {
            self.viewPicker.frame.origin.y = self.view.frame.size.height - self.viewPicker.frame.size.height
        })
    }
    
    //================================
    
    //>>>>>>>>>>>>>>>>>>>>>>>> PICERVIEW >>>>>>>>>>>>>>>>>>>>>>>>>>>//
    func ws_countries() {
        Http.instance().json(WebServices.vehicle_list, nil, "GET", ai: true, popup: true, prnt: true, sync: false) { (json, dict, str) in
            
            if json != nil {
                let json1 = json as? NSDictionary
                if number(json1! , "success").boolValue {
                    self.arrComman = NSMutableArray()
                    if let result = json1?.object(forKey: "result") as? NSArray {
                        self.arrComman = result.mutableCopy() as! NSMutableArray
                        self.pickerView.selectRow(0, inComponent: 0, animated: true)
                        self.addPickerView()
                    }
                } else {
                    let msg = string(json1!, "message")
                    let alert = UIAlertController(title: "", message: msg, preferredStyle: UIAlertControllerStyle.alert)
                    alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
                    if UIDevice.current.userInterfaceIdiom == .pad {
                        if let popoverController = alert.popoverPresentationController {
                            popoverController.sourceView = self.view
                            popoverController.sourceRect = self.view.bounds
                        }
                    }
                    self.present(alert, animated: true, completion: nil)
                }
            }
        }
    }
    
    
    @IBAction func actionupdateProfile(_ sender: Any) {
        self.view.endEditing(true)
        if let str = self.checkValidation() {
            Http.alert("", str)
            
        } else {
            
            ws_addProfile()
        }
        
    }
    
    
    
    
    func ws_addProfile() {
        
        
        
        let params = NSMutableDictionary()
        //        params["zipcode"] = tfZipCode.text!
        //        params["city_id"] = cityID
        params["expiration_date"] = date_tmp //  tfexpiration_date.text!
        params["state"] = stateID
        params["licence_number"] = tflicence_number.text!

        //        params["latitude"] = lat
        //        params["longitude"] = long
        
        Http.instance().json(WebServices.add_license, params, "POST", ai: true, popup: true, prnt: true, userInfo.Token(), sync: false) { (json, dict, str) in
            
            if json != nil {
                let json1 = json as? NSDictionary
                if number(json1! , "success").boolValue {
                    let vc = self.storyboard?.instantiateViewController(withIdentifier: "AgreementFCRAView") as! AgreementFCRAView
                    self.navigationController?.pushViewController(vc, animated: true)

                    
                    
//                    let vc = self.storyboard?.instantiateViewController(withIdentifier: "AddSelfeView") as! AddSelfeView
//                    self.navigationController?.pushViewController(vc, animated: true)
                    //                    let vc = self.storyboard?.instantiateViewController(withIdentifier: "SocialSecuirtyVC")as! SocialSecuirtyVC
                    //                    self.navigationController?.pushViewController(vc, animated: true)
                    
                    
                    
                } else {
                    Http.alert("", string(json1! , "message"))
                }
            }
        }
    }
    
  
    @IBAction func actionState(_ sender: Any) {
        self.removeDatePickerView()
        self.view.endEditing(true)
        comeFrom = "state"
        if countryID != "" {
            ws_state()
        } else {
            Http.alert("", "Please first select country.")
            //                let alert = UIAlertController(title: "", message: "Please first select country.", preferredStyle: UIAlertControllerStyle.alert)
            //                alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
            //                self.present(alert, animated: true, completion: nil)
        }
        
    }

    
    func ws_state() {
        let params = NSMutableDictionary()
        params["country_id"] = countryID
        
        Http.instance().json(WebServices.states, params, "GET", ai: true, popup: true, prnt: true, sync: false) { (json, dict, str) in
            
            if json != nil {
                let json1 = json as? NSDictionary
                if number(json1! , "success").boolValue {
                    self.arrComman = NSMutableArray()
                    if let result = json1?.object(forKey: "result") as? NSArray {
                        self.arrComman = result.mutableCopy() as! NSMutableArray
                        self.pickerView.selectRow(0, inComponent: 0, animated: true)
                        self.addPickerView()
                    }
                } else {
                    let msg = string(json1!, "msg")
                    let alert = UIAlertController(title: "", message: msg, preferredStyle: UIAlertControllerStyle.alert)
                    alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
                    if UIDevice.current.userInterfaceIdiom == .pad {
                        if let popoverController = alert.popoverPresentationController {
                            popoverController.sourceView = self.view
                            popoverController.sourceRect = self.view.bounds
                        }
                    }
                    self.present(alert, animated: true, completion: nil)
                }
            }
        }
    }
    
    
    
    @IBAction func actionDate(_ sender: Any) {
        self.view.endEditing(true)
        //
        self.removePickerView()

        datePicker.datePickerMode = .date

        self.datePicker.setDate(Date(), animated: false)
        self.datePicker.minimumDate = Date()
        
        UIView.animate(withDuration: 0.5, animations: {
            self.viewDatePicker.frame.origin.y = self.view.frame.size.height - self.viewDatePicker.frame.size.height
        })
    }
    var date_tmp = ""
    @IBAction func actionDatePickerDone(_ sender: Any) {
        
        date_tmp = dateFormatter.string(from: datePicker.date)
        dateFormatter.dateFormat = "dd MMM, yyyy"// "yyyy-MM-dd"

        tfexpiration_date.text = dateFormatter.string(from: datePicker.date)
        self.removeDatePickerView()
    }
    
    @IBAction func actionDatePickerClose(_ sender: Any) {
        self.removeDatePickerView()
    }
    func removeDatePickerView() {
        UIView.animate(withDuration: 0.9, animations: {
            self.viewDatePicker.frame.origin.y = self.view.frame.size.height
        })
    }
    
    
}


