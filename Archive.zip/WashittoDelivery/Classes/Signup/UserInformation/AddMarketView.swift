//
//  AddMarketView.swift
//  WashittoDelivery
//
//  Created by Rahul on 10/07/18.
//  Copyright © 2018 Himanshu pal. All rights reserved.
//

import UIKit
import HarishFrameworkSwift4

class AddMarketView: UIViewController , UITextFieldDelegate,  UINavigationControllerDelegate, UIPickerViewDelegate, UIPickerViewDataSource {
    
    @IBOutlet var btnAddEditButton: Button!
    @IBOutlet var tfZipCode: TextField!
//    @IBOutlet var tfAddress: TextField!
    @IBOutlet var scrollView: UIScrollView!
    @IBOutlet var tfCountry: UITextField!
    @IBOutlet var tfState: UITextField!
    @IBOutlet var tfCity: UITextField!
    @IBOutlet var viewPicker: UIView!
    @IBOutlet var pickerView: UIPickerView!
    var edit = ""
    var comeFrom = ""
    var countryID = ""
    var stateID = ""
    var cityID = ""
    var arrComman = NSMutableArray()
    var boolProfilePicture = false
    var imgProfilePicture:UIImage? = nil
    var picker:UIImagePickerController? = UIImagePickerController()
    
    //    var mydict:AddressListClass?
    var  lat = Double()
    var long = Double()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.isNavigationBarHidden = true
        self.navigationItem.hidesBackButton = true

        self.removePickerView()
        //  addDoneButtonOnKeyboard()
        registerForKeyboardNotifications()
        /*   self.navigationController?.isNavigationBarHidden = false
         navigationItem.hidesBackButton = false
         navigationController?.navigationBar.shouldRemoveShadow(true)*/
        self.viewPicker.frame.size.width = self.view.frame.size.width
        setDefoultContry()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        tfCountry.rightViewMode = UITextFieldViewMode.always
        tfState.rightViewMode = UITextFieldViewMode.always
        tfCity.rightViewMode = UITextFieldViewMode.always
        tfCountry.rightView = UIView().addPaddingView(UIImage(named:"arrow_down_w")!)
        tfState.rightView = UIView().addPaddingView(UIImage(named:"arrow_down_w")!)
        tfCity.rightView = UIView().addPaddingView(UIImage(named:"arrow_down_w")!)
        
//        btnAddEditButton.setTitle("Add Address", for: .normal)
        
    }
    
    func setDefoultContry(){
        
        // set default country and state
        tfCountry.text! = "United States"
        countryID =  "231"
        
        tfState.text! = "New York"
        stateID = "3956"
        
        
    }
    
    
    override func viewWillDisappear(_ animated: Bool) {
        self.title  = ""
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    
    
    
    
    func checkValidation() -> String? {
        
//        if tfZipCode.text?.count == 0 {
//            return "Please enter zipcode."
//        }
//        else if tfAddress.text == "Address" {
//            return "Please select address"
//        }else
          if tfCountry.text! == "Country" {
            return "Please select country"
        } else if tfState.text! == "State" ||   tfState.text! == ""  {
            return "Please select state"
            
        } else if tfCity.text! == "City" || tfCity.text! == "" {
            return "Please select city"
        }
        
        return nil
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        let length = (textField.text?.count)! + string.count - range.length
        
        if textField == tfZipCode {
            
            let validCharacterSet = NSCharacterSet(charactersIn: APPConstants.phoneNoAcceptableCharacter).inverted
            let filter = string.components(separatedBy: validCharacterSet)
            if filter.count == 1 {
                
                return (length > 6) ? false : true
            } else {
                return false
            }
        }
        
        return true
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        
        return true
    }
    
    //***************************************************************//
    //MARK:- KEYBOARD NOTIFICATION METHODS
    func registerForKeyboardNotifications() {
        let notificationCenter = NotificationCenter.default
        notificationCenter.addObserver(self, selector: #selector(adjustForKeyboard), name: Notification.Name.UIKeyboardWillHide, object: nil)
        notificationCenter.addObserver(self, selector: #selector(adjustForKeyboard), name: Notification.Name.UIKeyboardWillChangeFrame, object: nil)
    }
    
    func deregisterFromKeyboardNotifications() {
        NotificationCenter.default.removeObserver(self, name: .UIKeyboardWillShow, object: nil)
        NotificationCenter.default.removeObserver(self, name: .UIKeyboardWillHide, object: nil)
    }
    
    @objc func adjustForKeyboard(notification: Notification) {
        let userInfo = notification.userInfo!
        
        let keyboardScreenEndFrame = (userInfo[UIKeyboardFrameEndUserInfoKey] as! NSValue).cgRectValue
        let keyboardViewEndFrame = view.convert(keyboardScreenEndFrame, from: view.window)
        
        if notification.name == Notification.Name.UIKeyboardWillHide {
            scrollView.contentInset = UIEdgeInsets.zero
            
        } else {
            scrollView.contentInset = UIEdgeInsets(top: 0, left: 0, bottom: keyboardViewEndFrame.height + 10, right: 0)
        }
        
        scrollView.scrollIndicatorInsets = scrollView.contentInset
    }
    
    /////////__________***********************_________
    
    func addDoneButtonOnKeyboard() {
        let doneToolbar: UIToolbar = UIToolbar(frame: CGRect(x: 0, y: 0, width: 320, height: 50))
        doneToolbar.barStyle = UIBarStyle.blackTranslucent
        doneToolbar.barTintColor = appColor
        doneToolbar.tintColor = UIColor.white
        
        let flexSpace = UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.flexibleSpace, target: nil, action: nil)
        
        let next: UIBarButtonItem = UIBarButtonItem(title: "Next", style: UIBarButtonItemStyle.done, target: self, action: #selector(self.nextOfDoneTool))
        let done: UIBarButtonItem = UIBarButtonItem(title: "Done", style: UIBarButtonItemStyle.done, target: self, action: #selector(self.done))
        
        var items:[UIBarButtonItem] = []
        items.append(next)
        items.append(flexSpace)
        items.append(done)
        doneToolbar.items = items
        doneToolbar.sizeToFit()
//        self.tfZipCode.inputAccessoryView = doneToolbar
    }
    
    @objc func done() {
//        tfZipCode.resignFirstResponder()
    }
    
    @objc func nextOfDoneTool() {
//        tfAddress.becomeFirstResponder()
    }
    
    
    
    //>>>>>>>>>>>>>>>>>>>>>>>> PICERVIEW >>>>>>>>>>>>>>>>>>>>>>>>>>>//
    //MARK:- PickerView Delegate & DataSource
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return arrComman.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        
        if comeFrom == "country" {
            let dict = arrComman.object(at: row) as! NSDictionary
            return string(dict, "name")
        } else if comeFrom == "state" {
            let dict = arrComman.object(at: row) as! NSDictionary
            return string(dict, "name")
        } else {
            let dict = arrComman.object(at: row) as! NSDictionary
            return string(dict, "name")
        }
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
        /* if comeFrom == "country" {
         let dict = arrComman.object(at: row) as! NSDictionary
         self.tfCountry.text = string(dict, "name")
         countryID = string(dict, "id")
         
         } else if comeFrom == "state" {
         let dict = arrComman.object(at: row) as! NSDictionary
         self.tfState.text = string(dict, "name")
         stateID = string(dict, "id")
         
         } else {
         let dict = arrComman.object(at: row) as! NSDictionary
         self.tfCity.text = string(dict, "name")
         cityID = string(dict, "id")
         }*/
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
//        if textField == tfZipCode{
//            tfZipCode.becomeFirstResponder()
//        }
        
    }
    @IBAction func actionPickerDone(_ sender: Any) {
        
        if comeFrom == "country" {
            let dictPkr = arrComman.object(at: pickerView.selectedRow(inComponent: 0)) as! NSDictionary
            tfCountry.text! = string(dictPkr, "name")
            countryID = string(dictPkr, "id")
            
        } else if comeFrom == "state" {
            let dictPkr = arrComman.object(at: pickerView.selectedRow(inComponent: 0)) as! NSDictionary
            tfState.text! = string(dictPkr, "name")
            stateID = string(dictPkr, "id")
            
        } else if comeFrom == "city" {
            let dictPkr = arrComman.object(at: pickerView.selectedRow(inComponent: 0)) as! NSDictionary
            tfCity.text! = string(dictPkr, "name")
            cityID = string(dictPkr, "id")
        }
        
        self.removePickerView()
    }
    
    @IBAction func actionPickerClose(_ sender: Any) {
        self.removePickerView()
    }
    
    func removePickerView() {
        viewPicker.isHidden = true
        UIView.animate(withDuration: 0.9, animations: {
            self.viewPicker.frame.origin.y = self.view.frame.size.height
        })
    }
    
    func addPickerView() {
        viewPicker.isHidden = false
        self.view.endEditing(true)
        pickerView.reloadAllComponents()
        pickerView.selectRow(0, inComponent: 0, animated: true)
        UIView.animate(withDuration: 0.5, animations: {
            self.viewPicker.frame.origin.y = self.view.frame.size.height - self.viewPicker.frame.size.height
        })
    }
    
    //================================
    
    //>>>>>>>>>>>>>>>>>>>>>>>> PICERVIEW >>>>>>>>>>>>>>>>>>>>>>>>>>>//
    func ws_countries() {
        Http.instance().json(WebServices.countries, nil, "GET", ai: true, popup: true, prnt: true, sync: false) { (json, dict, str) in
            
            if json != nil {
                let json1 = json as? NSDictionary
                if number(json1! , "success").boolValue {
                    self.arrComman = NSMutableArray()
                    if let result = json1?.object(forKey: "result") as? NSArray {
                        self.arrComman = result.mutableCopy() as! NSMutableArray
                        self.pickerView.selectRow(0, inComponent: 0, animated: true)
                        self.addPickerView()
                    }
                } else {
                    let msg = string(json1!, "message")
                    let alert = UIAlertController(title: "", message: msg, preferredStyle: UIAlertControllerStyle.alert)
                    alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
                    if UIDevice.current.userInterfaceIdiom == .pad {
                        if let popoverController = alert.popoverPresentationController {
                            popoverController.sourceView = self.view
                            popoverController.sourceRect = self.view.bounds
                        }
                    }
                    self.present(alert, animated: true, completion: nil)
                }
            }
        }
    }
    
    func ws_state() {
        let params = NSMutableDictionary()
        params["country_id"] = countryID
        
        Http.instance().json(WebServices.states, params, "GET", ai: true, popup: true, prnt: true, sync: false) { (json, dict, str) in
            
            if json != nil {
                let json1 = json as? NSDictionary
                if number(json1! , "success").boolValue {
                    self.arrComman = NSMutableArray()
                    if let result = json1?.object(forKey: "result") as? NSArray {
                        self.arrComman = result.mutableCopy() as! NSMutableArray
                        self.pickerView.selectRow(0, inComponent: 0, animated: true)
                        self.addPickerView()
                    }
                } else {
                    let msg = string(json1!, "msg")
                    let alert = UIAlertController(title: "", message: msg, preferredStyle: UIAlertControllerStyle.alert)
                    alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
                    if UIDevice.current.userInterfaceIdiom == .pad {
                        if let popoverController = alert.popoverPresentationController {
                            popoverController.sourceView = self.view
                            popoverController.sourceRect = self.view.bounds
                        }
                    }
                    self.present(alert, animated: true, completion: nil)
                }
            }
        }
    }
    
    func ws_city() {
        let params = NSMutableDictionary()
        params["state_id"] = stateID
        
        Http.instance().json(WebServices.cities, params, "GET", ai: true, popup: true, prnt: true, sync: false) { (json, dict, str) in
            
            if json != nil {
                let json1 = json as? NSDictionary
                if number(json1! , "success").boolValue {
                    self.arrComman = NSMutableArray()
                    if let result = json1?.object(forKey: "result") as? NSArray {
                        self.arrComman = result.mutableCopy() as! NSMutableArray
                        self.pickerView.reloadAllComponents()
                        self.pickerView.selectRow(0, inComponent: 0, animated: true)
                        self.addPickerView()
                    }
                } else {
                    let msg = string(json1!, "msg")
                    let alert = UIAlertController(title: "", message: msg, preferredStyle: UIAlertControllerStyle.alert)
                    alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
                    if UIDevice.current.userInterfaceIdiom == .pad {
                        if let popoverController = alert.popoverPresentationController {
                            popoverController.sourceView = self.view
                            popoverController.sourceRect = self.view.bounds
                        }
                    }
                    self.present(alert, animated: true, completion: nil)
                }
            }
        }
    }
    
    
    @IBAction func actionupdateProfile(_ sender: Any) {
        self.view.endEditing(true)
        if let str = self.checkValidation() {
            Http.alert("", str)
            
        } else {
            
            ws_addProfile()
        }
        
    }
    
    
    
    
    func ws_addProfile() {
       

        
        let params = NSMutableDictionary()
//        params["zipcode"] = tfZipCode.text!
//        params["address"] = tfAddress.text!
        params["city_id"] = cityID
        params["country_id"] = countryID
        params["state_id"] = stateID
//        params["latitude"] = lat
//        params["longitude"] = long
        
        Http.instance().json(WebServices.add_market_select, params, "POST", ai: true, popup: true, prnt: true, userInfo.Token(), sync: false) { (json, dict, str) in
            
            if json != nil {
                let json1 = json as? NSDictionary
                if number(json1! , "success").boolValue {
                    let dd = UserDefaults.standard
                    if let id = Int(self.countryID) {
                        dd.set(id, forKey: "country_id")
                    }else {
                        dd.set(self.countryID, forKey: "country_id")
                    }
                    dd.synchronize()

                    let vc = self.storyboard?.instantiateViewController(withIdentifier: "AddVehicleView") as! AddVehicleView
                    self.navigationController?.pushViewController(vc, animated: true)

                    
                    
                    
                    
                } else {
                    Http.alert("", string(json1! , "message"))
                }
            }
        }
    }
    
    @IBAction func actionCountry(_ sender: Any) {
        self.view.endEditing(true)
        comeFrom = "country"
        tfState.text! = ""
        tfCity.text! = ""
        countryID = ""
        stateID = ""
        cityID = ""
        ws_countries()
    }
    
    @IBAction func actionState(_ sender: Any) {
        
        self.view.endEditing(true)
        comeFrom = "state"
        if countryID != "" {
            tfCity.text! = ""
            ws_state()
        } else {
            Http.alert("", "Please first select country.")
            //                let alert = UIAlertController(title: "", message: "Please first select country.", preferredStyle: UIAlertControllerStyle.alert)
            //                alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
            //                self.present(alert, animated: true, completion: nil)
        }
        
    }
    @IBAction func actionCity(_ sender: Any) {
        if countryID != "" && stateID != ""{
            comeFrom = "city"
            self.view.endEditing(true)
            ws_city()
        } else {
            Http.alert("", "Please first select state.")
            
        }
        
    }
    

 
}
