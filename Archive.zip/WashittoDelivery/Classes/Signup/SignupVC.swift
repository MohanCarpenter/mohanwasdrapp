//
//  ViewController.swift
//  Washitto
//
//  Created by Himanshu on 11/06/18.
//  Copyright © 2018 Himanshu. All rights reserved.
//
import UIKit
import FacebookLogin
import FacebookCore
import FBSDKLoginKit
import FacebookShare
import GoogleSignIn
import Google
import HarishFrameworkSwift4

class SignupVC: UIViewController, GIDSignInUIDelegate, GIDSignInDelegate , UITextFieldDelegate{
    
    @IBOutlet var scrlView: UIScrollView!
    @IBOutlet var lblPrivacyPolicy: UILabel!
    @IBOutlet var btnFacebook: Button!
    @IBOutlet var btnGoogle: Button!
    @IBOutlet var tfEmail: TextField!
    @IBOutlet var tfPassword: TextField!
    @IBOutlet var tfConfPass: TextField!

    
    override func viewDidLoad() {
        super.viewDidLoad()
         self.registerForKeyboardNotifications()
        btnFacebook.setImage(UIImage.imageWithImage(image: UIImage(named: "facebook.png")!, scaledToSize: CGSize(width: 10, height: 25)), for: .normal)
        btnGoogle.setImage(UIImage.imageWithImage(image: UIImage(named: "google.png")!, scaledToSize: CGSize(width: 25, height: 25)), for: .normal)
       
     /*   let myString:NSString = "By joining you agree to our Terms and our Privacy Policy"
     let myMutableString = NSMutableAttributedString(string:myString as String)
    // let  myMutableString = NSMutableAttributedString(string: myString as String, attributes: [NSAttributedStringKey.font:UIFont(name: "VarelaRound-Regular 12.0", size: 12.0)!])
        
        //"I AM KIRIT MODI"
        myMutableString.addAttribute(NSAttributedStringKey.foregroundColor, value: UIColor.orange, range: NSRange(location:28,length:5))
        
        myMutableString.addAttribute(NSAttributedStringKey.foregroundColor, value: UIColor.orange, range: NSRange(location:42,length:7))
        
         myMutableString.addAttribute(NSAttributedStringKey.foregroundColor, value: UIColor.orange, range: NSRange(location:50,length:6))
        
        lblPrivacyPolicy.attributedText = myMutableString
        */
   
        lblPrivacyPolicy.text = "By clicking Next, I represent that I have read, understand, and agree to the washito Agreement and Privacy Policy."
    
        
    }
    override func viewWillAppear(_ animated: Bool) {
        self.title = "Sign Up"
          self.navigationController?.isNavigationBarHidden = false
          navigationItem.hidesBackButton = false
        navigationController?.navigationBar.shouldRemoveShadow(true)
   
    }
    override func viewWillDisappear(_ animated: Bool) {
        self.title = ""
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    @IBAction func actionGoogle(_ sender: Any) {
        kappDelegate.social = "GOOGLE"
        googleLogin ()
    }
    
    @IBAction func actionFacebook(_ sender: Any) {
        kappDelegate.social = "FACEBOOK"
        fbLogin ()
    }
    
    
    
    /***************************** Facebook  ******************************/
    
    func fbLogin () {
        
        let fbLoginManager : FBSDKLoginManager = FBSDKLoginManager()
        
        fbLoginManager.logOut()
        
        fbLoginManager.logIn(withReadPermissions: ["email"], from: self) { (result, error) in
            if (error == nil) {
                
                if ((FBSDKAccessToken.current()) != nil) {
                    
                    Http.startActivityIndicator()
                    
                    FBSDKGraphRequest(graphPath: "me", parameters: ["fields": "id, name, first_name, last_name, picture.type(large), email"]).start(completionHandler: { (connection, result, error) -> Void in
                        if (error == nil) {
                            if let dt = result as? NSDictionary {
                                print(dt)
                                let params = NSMutableDictionary()
                                params["first_name"] = dt["first_name"]
                                params["last_name"] = dt["last_name"]
                                // params["email"] = ""
                                params["phone_number"] = ""
                                params["password"] = ""
                                params["role"] =  "customer"
                                params["device_name"] = UIDevice.current.modelName
                                params["imei"] =    APPConstants.getDeviceId()
                                params["apns_id"] =   kappDelegate.apns
                                params["device_type"] = APPConstants.deviceType
                                params["modal_no"] = UIDevice.current.model
                                params["os_version"] =  UIDevice.current.systemVersion
                                params["social_id"] = dt["id"]
                                params["social_type"] = "facebook"
                              /*  md["first_name"] = dt["first_name"]
                                md["last_name"] = dt["last_name"]
                                md["social_id"] = dt["id"]
                                md["email"] = dt["email"]
                                md["username"] = dt["email"]
                                md["login_type"] = "facebook"
                               // md["device_id"] = PredefinedConstants.userDeviceId
                               // md["device_type"] = PredefinedConstants.deviceType
                                md["notification_id"] = "123"
                                md["lang"] = "en"
                                md["app_version"] = "1.0"
                           
                                var url:String? = nil
                                
                                if let picture = dt["picture"] as? NSDictionary {
                                    if let data = picture["data"] as? NSDictionary {
                                        if let uurl = data["url"] as? String {
                                            url = uurl
                                        }
                                    }
                                }
                                
                                if url == nil {
                                    self.socialLogin(md)
                                } else {
                                    md["social_dp"] = url!
                                    self.socialLogin(md)
                                }*/
                                print(params)//Print FB User Details
                                 self.socialLogin(params)
                            } else {
                               Http.startActivityIndicator()
                            }
                        } else {
                            Http.startActivityIndicator()
                        }
                    })
                } else {
                    self.stopActivityI()
                }
            }
        }
    }
    
    
    
    //MARK: WS_LOGIN
    
    func socialLogin (_ params:NSMutableDictionary) {
        
        Http.instance().json(WebServices.register, params, "POST", ai: true, popup: true, prnt: true, sync: false) { (json, dict, str) in
            
            if json != nil {
                let json1 = json as? NSDictionary
                if number(json1! , "success").boolValue {
                    if let result = json1?["result"] as? NSDictionary {
                        Http.alert("", string(json1! , "message"))
                        
                        if let user = json1?.object(forKey: "result") as? NSDictionary {
                            userInfo.saveLoginInfo(user)
                        }
                        
                        if let token = result.object(forKey: "token") as? String {
                            userInfo.savetoken(token)
                        }
                        if string(result, "is_phone_verified") == "0" && string(result, "phone_number") == "" && string(result, "temp_phone_number") == ""{
                            let vc = self.storyboard?.instantiateViewController(withIdentifier: "ChangeNumberVC") as! ChangeNumberVC
                            self.navigationController?.pushViewController(vc, animated: true)
                            
                            
                        }else if string(result, "is_phone_verified") == "0" && string(result, "phone_number") != "" && string(result, "temp_phone_number") != "" {
                            
                            let vc = self.storyboard?.instantiateViewController(withIdentifier: "VerifyNumberVC") as! VerifyNumberVC
                            vc.mobileNumber = string(result, "temp_phone_number")
                            self.navigationController?.pushViewController(vc, animated: true)
                        }
                        else if string(result, "is_mail_verified") == "0" && string(result, "email") == "" {
                            let vc = self.storyboard?.instantiateViewController(withIdentifier: "AddEmailVC") as! AddEmailVC
                            self.navigationController?.pushViewController(vc, animated: true)
                            
                        }else if string(result, "is_mail_verified") == "0" && string(result, "email") != "" {
                            let vc = self.storyboard?.instantiateViewController(withIdentifier: "VerifyEmailVC") as! VerifyEmailVC
                            vc.myemail = string(result, "email")
                            self.navigationController?.pushViewController(vc, animated: true)
                            
                        }
                        else{
                            self.navigationController?.viewControllers = []
                            let vc = self.storyboard?.instantiateViewController(withIdentifier: "RootViewCustomer") as! RootViewCustomer
                            kappDelegate.window?.rootViewController = vc
                        }
                        
                        
                    }
                }else {
                    Http.alert("", string(json1! , "message"))
                    
                }
                
            }
        }
        
    }
    
    
    func googleLogin () {
        GIDSignIn.sharedInstance().delegate = self
        GIDSignIn.sharedInstance().uiDelegate = self
        GIDSignIn.sharedInstance()?.signIn()
    }
    
    public func sign(_ signIn: GIDSignIn!, didSignInFor user: GIDGoogleUser!, withError error: Error!) {
        if (error == nil) {
            Http.startActivityIndicator()
            
            let userId = user.userID
            //let fullName = user.profile.name
            let givenName = user.profile.givenName
            let familyName = user.profile.familyName
            let email = user.profile.email
            
            let params = NSMutableDictionary()
            params["first_name"] = user.profile.givenName
            params["last_name"] = user.profile.familyName
            // params["email"] = ""
            params["phone_number"] = ""
            params["password"] = ""
            params["role"] =  "customer"
            params["device_name"] = UIDevice.current.modelName
            params["imei"] =    APPConstants.getDeviceId()
            params["apns_id"] =   kappDelegate.apns
            params["device_type"] = APPConstants.deviceType
            params["modal_no"] = UIDevice.current.model
            params["os_version"] =  UIDevice.current.systemVersion
            params["social_id"] = user.userID
            params["social_type"] = "google"
            /*let md = NSMutableDictionary()
            
            md["first_name"] = givenName
            md["last_name"] = familyName
            md["social_id"] = userId
            md["email"] = email
            md["lang"] = "en"
            md["login_type"] = "google"
           // md["device_id"] = PredefinedConstants.userDeviceId
           // md["device_type"] = PredefinedConstants.deviceType
            md["notification_id"] = "123"
            md["app_version"] = "1.0"
            md["signup_type"] = "2"
            md["contact_no"] = ""
            md["username"] = email*/
            
            self.socialLogin(params)
            
            var url:String? = nil
            
           /* if user.profile.hasImage {
                let uurl = user.profile.imageURL(withDimension: 120)
                url = uurl?.absoluteString
            }
            
            if url == nil {
                self.socialLogin(params)
            } else {
                md["social_dp"] = url!
                self.socialLogin(md)
            }*/
        } else {
            print("1 sign error-\(error.localizedDescription)")
            stopActivityI()
        }
    }
    
    func sign(inWillDispatch signIn: GIDSignIn!, error: Error!) {
        if error != nil {
            Http.stopActivityIndicator()
        }
    }
    
    // Present a view that prompts the user to sign in with Google
    func sign(_ signIn: GIDSignIn!, present viewController: UIViewController!) {
        self.present(viewController, animated: true, completion: nil)
    }
    
    // Dismiss the "Sign in with Google" view
    func sign(_ signIn: GIDSignIn!, dismiss viewController: UIViewController!) {
        self.dismiss(animated: true, completion: nil)
        
        Http.stopActivityIndicator()
    }
    
    
    //MARK: FUNCTIONS.
    
    func stopActivityI () {
        Http.stopActivityIndicator()
    }
    
    
    @IBAction func actionLogin(_ sender: Any) {
       // let vc = self.storyboard?.instantiateViewController(withIdentifier: "ProfileVC") as! ProfileVC
        self.navigationController?.popViewController(animated: true)
    }
    override func viewDidDisappear(_ animated: Bool) {
        deregisterFromKeyboardNotifications()
        stopActivityI()
    }
   
    //*************************************************
    //MARK:- KEYBOARD NOTIFICATION METHODS
    func registerForKeyboardNotifications() {
        let notificationCenter = NotificationCenter.default
        notificationCenter.addObserver(self, selector: #selector(adjustForKeyboard), name: Notification.Name.UIKeyboardWillHide, object: nil)
        notificationCenter.addObserver(self, selector: #selector(adjustForKeyboard), name: Notification.Name.UIKeyboardWillChangeFrame, object: nil)
    }
    
    func deregisterFromKeyboardNotifications() {
        NotificationCenter.default.removeObserver(self, name: .UIKeyboardWillShow, object: nil)
        NotificationCenter.default.removeObserver(self, name: .UIKeyboardWillHide, object: nil)
    }
    
    @objc func adjustForKeyboard(notification: Notification) {
        let userInfo = notification.userInfo!
        
        let keyboardScreenEndFrame = (userInfo[UIKeyboardFrameEndUserInfoKey] as! NSValue).cgRectValue
        let keyboardViewEndFrame = view.convert(keyboardScreenEndFrame, from: view.window)
        
        if notification.name == Notification.Name.UIKeyboardWillHide {
            scrlView.contentInset = UIEdgeInsets.zero
        } else {
            scrlView.contentInset = UIEdgeInsets(top: 0, left: 0, bottom: keyboardViewEndFrame.height + 10, right: 0)
        }
        
        scrlView.scrollIndicatorInsets = scrlView.contentInset
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        if (textField.frame.origin.y >= 200) {
            scrlView.setContentOffset(CGPoint(x: 0, y: CGFloat(Int(textField.frame.origin.y - 200))) , animated: true)
        }
    }
    func textFieldDidEndEditing(_ textField: UITextField) {
        
        scrlView.setContentOffset(CGPoint(x: 0, y: 0), animated: true)
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
        if textField == tfEmail {
            tfPassword.becomeFirstResponder()
        }else if textField == tfPassword {
            tfConfPass.becomeFirstResponder()

        }else if textField == tfConfPass {
            textField.resignFirstResponder()
            self.scrlView.setContentOffset(CGPoint(x: 0, y: 0), animated: true)
        }
        
        return true
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        let length = (textField.text?.count)! + string.count - range.length
        
      if textField == tfEmail {
            let validCharacterSet = NSCharacterSet(charactersIn: APPConstants.emailAcceptableCharacter).inverted
            let filter = string.components(separatedBy: validCharacterSet)
            if filter.count == 1 {
                
                return (length > 50) ? false : true
            } else {
                return false
            }
        }
            
        else if textField == tfPassword || textField == tfConfPass{
            
            
            return (length > 31) ? false : true
        }
        return true
    }
    
    @IBAction func actionSignup(_ sender: Any) {
        self.scrlView.setContentOffset(CGPoint(x: 0, y: 0), animated: true)
        self.view.endEditing(true)
        if let str = self.checkValidation() {
            Http.alert("", str)
            
        } else {
            ws_Signup()
            
        }
        
    }
    
    func checkValidation() -> String? {
        if tfEmail.text?.count == 0 {
            return "Please enter your email."
        } else if !Valid.email(tfEmail.text!) {
            return "Please enter valid email."
        } else if tfPassword.text?.count == 0 {
            return "Please enter password."
        } else if (self.tfPassword.text?.count)! < 6 {
            return "Password should be minimum 6 characters."
        }else if (self.tfConfPass.text?.count)! < 6  {
            return "Confirm password should be between 6-20 characters."
        } else if tfConfPass.text?.count == 0 {
            return "Please enter confirm password."
        } else if tfConfPass.text?.count != tfPassword.text?.count {
            return "Password and confirm password does not match."
        }
      
        return nil
    }
 
    
    
    func ws_Signup() {
        let params = NSMutableDictionary()
        params["email"] = tfEmail.text!
        params["password"] = tfPassword.text!
        params["role"] =  "delivery"
        params["device_name"] = UIDevice.current.modelName
        params["imei"] =    APPConstants.getDeviceId()
        params["apns_id"] =   kappDelegate.apns
        params["device_type"] = APPConstants.deviceType
        params["modal_no"] = UIDevice.current.model
        params["os_version"] =  UIDevice.current.systemVersion
        params["social_type"] = "email"

        let defaults = UserDefaults.standard
        if  let notificationid = defaults.object(forKey: "firebasetoken") {
            params["notification_id"] =   ("\(notificationid)")
        }else{
            params["notification_id"] = "123"
        }
        
       // UIDevice.current.deviceInfo(params)
       
        print("params-------", params)
        
        
        Http.instance().json(WebServices.register, params, "POST", ai: true, popup: true, prnt: true, sync: false) { (json, dict, str) in
            
            if json != nil {
                let json1 = json as? NSDictionary
                if number(json1! , "success").boolValue {
                    if let result = json1?["result"] as? NSDictionary {
//                        Http.alert("", string(json1! , "message"))
                        
                        if let user = json1?.object(forKey: "result") as? NSDictionary {
                            userInfo.saveLoginInfo(user)
                        }
                        
                        if let token = result.object(forKey: "token") as? String {
                            userInfo.savetoken(token)
                        }
                        let uDef = UserDefaults.standard
                        
                        uDef.set(self.tfEmail.text!, forKey: "email")
                        uDef.set(self.tfPassword.text!, forKey: "pass")
                        uDef.set(false, forKey: "is_remamber")
                        uDef.set(true, forKey: "is_login")
                        uDef.synchronize()
                        
                        guard let completed_steps = result.object(forKey: "completed_steps") as? Int else {
                            return
                        }
                        
                        kappDelegate.completed_steps = completed_steps
                        
//                        if completed_steps == 1 {
//                        }
                        let vc = self.storyboard?.instantiateViewController(withIdentifier: "AgreementView") as! AgreementView
                        self.navigationController?.pushViewController(vc, animated: true)
                    
                    }
                }else {
                    Http.alert("", string(json1! , "message"))
                    
                }
                
            }
        }
        
        
    }
    
    
    
    
    
}


