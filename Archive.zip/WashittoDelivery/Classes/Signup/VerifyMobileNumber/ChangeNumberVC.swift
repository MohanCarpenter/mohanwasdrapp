//
//  ChangeNumberVC.swift
//  Washitto
//
//  Created by Himanshu on 20/06/18.
//  Copyright © 2018 Himanshu. All rights reserved.
//

import UIKit
import HarishFrameworkSwift4
class ChangeNumberVC: UIViewController ,UITextFieldDelegate{
    @IBOutlet var tfMobileNumber: TextField!
    @IBOutlet var lblTitleMessage: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    override func viewWillAppear(_ animated: Bool) {

    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }

   
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        let length = (textField.text?.count)! + string.count - range.length
        
        if tfMobileNumber == textField {
            
            let validCharacterSet = NSCharacterSet(charactersIn: "0123456789").inverted
            let filter = string.components(separatedBy: validCharacterSet)
            if filter.count == 1 {
                
                return (length > 10) ? false : true
            } else {
                return false
            }
        }
        return true
    }
    
    func checkValidation() -> String? {
        if tfMobileNumber.text?.count == 0 {
            return "Please enter mobile number."
        }else if tfMobileNumber.text!.count < 10 {
            return "Please enter correct mobile number."
        }
        
        return nil
    }
    func ws_ChangePhone() {
        let params = NSMutableDictionary()
        params["phone_number"] = tfMobileNumber.text!
        Http.instance().json(WebServices.changephone, params, "POST", ai: true, popup: true, prnt: true, userInfo.Token(), sync: false) { (json, dict, str) in
            
            if json != nil {
                let json1 = json as? NSDictionary
                if number(json1! , "success").boolValue {
                    Http.alert("", string(json1! , "message"))
                        let vc = self.storyboard?.instantiateViewController(withIdentifier: "VerifyNumberVC") as! VerifyNumberVC
                        vc.mobileNumber = self.tfMobileNumber.text!
                        self.navigationController?.pushViewController(vc, animated: true)
                
                }else {
                    Http.alert("", string(json1! , "message"))
                }
            }
        }
    }
    
    @IBAction func actionSubmit(_ sender: Any) {
        if let str = self.checkValidation() {
            Http.alert("", str)
            
        } else {
            ws_ChangePhone()
            
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        self.title = ""
    }
    
}
