//
//  AppDelegate.swift
//  Washitto
//
//  Created by Himanshu on 11/06/18.
//  Copyright © 2018 Himanshu. All rights reserved.
//1058468472885-fbr94vdju5ejcl87rgrpikqq0lodrl10.apps.googleusercontent.com


import UIKit
import Firebase
import FirebaseInstanceID
import FirebaseMessaging
import UserNotifications
import AudioToolbox

import GoogleSignIn
import Google
import FBSDKCoreKit

import Fabric
import Crashlytics

import GooglePlaces
import GoogleMaps
import HarishFrameworkSwift4
import CoreLocation 


@UIApplicationMain

class AppDelegate: UIResponder, UIApplicationDelegate, GIDSignInDelegate  , CLLocationManagerDelegate{
    var social = ""
    var window: UIWindow?
    var apnsToken = ""
    var comefrom = ""
    var apns = ""
    
    var order_id = ""
    var request_id = ""

    var comefromNoti = ""
    var strBGNotification = ""
    var completed_steps = 0
    var is_socket_login = false
    
    var locManager:CLLocationManager? = CLLocationManager()
    
    
    var Sourabhnotification = NSDictionary()
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey: Any]?) -> Bool {
        GMSServices.provideAPIKey(APPConstants.googleApiKey)
        GMSPlacesClient.provideAPIKey(APPConstants.googleApiKey)
        
        GIDSignIn.sharedInstance().clientID = "350926527209-mpqhfeos6k5ocfm7o239vdvc7efikt99.apps.googleusercontent.com"
//        GMSServices.provideAPIKey("AIzaSyBdVl-cTICSwYKrZ95SuvNw7dbMuDt1KG0")
        UserDefaults.standard.setValue(false, forKey: "_UIConstraintBasedLayoutLogUnsatisfiable")

        Fabric.with([Crashlytics.self])
        FIRApp.configure()
        registerAPNS(application)
        connectToFcm()
        //socket connect
        SOCKETIOCLIENTMANAGER.sharedInstance.establishConnection()
        
        // Add observer for InstanceID token refresh callback.
        NotificationCenter.default.addObserver(self,selector: #selector(self.tokenRefreshNotification),name: NSNotification.Name.firInstanceIDTokenRefresh,object: nil)
        
        NotificationCenter.default.post(name: NSNotification.Name(rawValue: "ReceiveRemoteNotificationNew"), object: nil, userInfo: nil)
        
        if FIRInstanceID.instanceID().token() != nil {
            
            if let refreshedToken = FIRInstanceID.instanceID().token(){
                let defaults = UserDefaults.standard
                
                print("InstanceID token: \(refreshedToken)")
                defaults.setValue(refreshedToken, forKey: "firebasetoken")
                apnsToken = refreshedToken
            }
        }
        
        if #available(iOS 10, *) {
            UNUserNotificationCenter.current().requestAuthorization(options: [.badge,.sound,.alert], completionHandler: { (granted, error) in
                DispatchQueue.main.sync {
                    application.registerForRemoteNotifications()
                }
            })
        }else{
            let notificationSettings = UIUserNotificationSettings(types: [.badge,.sound,.alert], categories: nil)
            UIApplication.shared.registerUserNotificationSettings(notificationSettings)
            UIApplication.shared.registerForRemoteNotifications()
        }
        application.statusBarStyle = .lightContent
        
        UINavigationBar.appearance().titleTextAttributes =  [NSAttributedStringKey.foregroundColor : UIColor.white] // nav text color
        UINavigationBar.appearance().isTranslucent = false
        UINavigationBar.appearance().tintColor = UIColor.white //set back btn color
        UINavigationBar.appearance().barStyle = .blackOpaque
        
        if #available(iOS 10, *) {
            UNUserNotificationCenter.current().requestAuthorization(options:[.badge, .alert, .sound]){ (granted, error) in }
            application.registerForRemoteNotifications()
        }
        
        //Neeleshwari ==============
        //when app killed and notification is come hp
        if launchOptions?[UIApplicationLaunchOptionsKey.remoteNotification] != nil {
            // Do your task here
            let remoteNotif = launchOptions?[UIApplicationLaunchOptionsKey.remoteNotification] as? NSDictionary
            Sourabhnotification = remoteNotif!
            strBGNotification = "neeleshwari"
            DispatchQueue.main.asyncAfter(deadline: .now() + 1) { // change 5 to desired number of seconds
                NotificationCenter.default.post(name: Notification.Name(rawValue: "ReceiveRemoteNotificationNew"), object: self, userInfo: nil)
                print(" nnn 9 ==============")
            }
        }
      
        
        return true
    }
    
    func applicationWillResignActive(_ application: UIApplication) {
        // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
        // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
    }
    
    func applicationDidEnterBackground(_ application: UIApplication) {
        
        
    }
    
    func applicationWillEnterForeground(_ application: UIApplication) {
        // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
    }
    
    func applicationDidBecomeActive(_ application: UIApplication) {
        // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
        connectToFcm()
    }
    
    func applicationWillTerminate(_ application: UIApplication) {
        // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
    }
    
    func registerAPNS (_ application: UIApplication) {
        
        
        if #available(iOS 10.0, *) {
            let authOptions: UNAuthorizationOptions = [.alert, .badge, .sound]
            UNUserNotificationCenter.current().requestAuthorization(
                options: authOptions,
                completionHandler: {_, _ in })
            
            // For iOS 10 display notification (sent via APNS)
            UNUserNotificationCenter.current().delegate = self
            // For iOS 10 data message (sent via FCM)
            //FIRMessaging.messaging().remoteMessageDelegate = self
            
        } else {
            let settings: UIUserNotificationSettings =
                UIUserNotificationSettings(types: [.alert, .badge, .sound], categories: nil)
            application.registerUserNotificationSettings(settings)
        }
        
        application.registerForRemoteNotifications()
        
    }
    
    @objc func tokenRefreshNotification(notification: NSNotification) {
        if FIRInstanceID.instanceID().token() != nil {
            let refreshedToken = FIRInstanceID.instanceID().token()!
            
            let defaults = UserDefaults.standard
            defaults.setValue(refreshedToken, forKey: "firebasetoken")
            
            print("InstanceID token: \(refreshedToken)")
            apnsToken = refreshedToken
            print("apnsToken: \(apnsToken)")
        } else {
            connectToFcm()
        }
        // Connect to FCM since connection may have failed when attempted before having a token.
        print(" nnn 2 ==============")
        //Http.alert("", " nnn 2 ==============")
    }
    
    func connectToFcm() {
        FIRMessaging.messaging().connect { (error) in
            if (error != nil) {
                print("Unable to connect with FCM. \(String(describing: error))")
            } else {
                print("Connected to FCM.")
            }
        }
    }
    
    
    
    func application(_ application: UIApplication, didRegisterForRemoteNotificationsWithDeviceToken deviceToken: Data) {
        apns = deviceToken.reduce("", {$0 + String(format: "%02X",    $1)})
        // kDeviceToken=tokenString
        print("apns: \(apns)")
        
        
        FIRInstanceID.instanceID().setAPNSToken(deviceToken as Data, type: .sandbox)
        if FIRInstanceID.instanceID().token() != nil {
            let refreshedToken = FIRInstanceID.instanceID().token()!
            let defaults = UserDefaults.standard
            defaults.setValue(refreshedToken, forKey: "firebasetoken")
            print("InstanceID token: \(refreshedToken)")
            apnsToken = refreshedToken
            print("apnsToken: \(apnsToken)")
        }
    }
    
    
    func application(application: UIApplication, didFailToRegisterForRemoteNotificationsWithError error: NSError) {
        apnsToken = "2bc062e8a3259535e68e0e9ddc60b0792dc190831a5a1ed5f08c31964b13ed31"
        print("Couldn't register: \(error)")
        print(" nnn 3 ==============")
        
        //Http.alert("", " nnn 3 ==============")
        
    }
    
    func application(application: UIApplication, didReceiveRemoteNotification userInfo: [NSObject : AnyObject]) {
        print("Notif register: \(userInfo)")
        
        let appReceiptTime  = NSData()
        print("time notification arrival\(appReceiptTime)")
        print(" nnn 4 ==============")
        //Http.alert("", " nnn 4 ==============")
    }
    
    private func application(application: UIApplication, didReceiveRemoteNotification userInfo: [NSObject : AnyObject],fetchCompletionHandler completionHandler: (UIBackgroundFetchResult) -> Void) {
        let appReceiptTime  = NSDate()
        print("time notification arrival\(appReceiptTime)")
        
        
        FIRMessaging.messaging().appDidReceiveMessage(userInfo)
        print(FIRMessaging.messaging().appDidReceiveMessage(userInfo))
        print(userInfo)
        
        print(" nnn 5 ==============")
    }
    
    //get notification here from fcm server hp
    func application(_ application: UIApplication, didReceiveRemoteNotification userInfo: [AnyHashable : Any]) {
        print("userInfo-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=--=-=-=-=-==\(userInfo)")
        
        
        
        NotificationCenter.default.post(name: NSNotification.Name(rawValue: "ReceiveRemoteNotificationNew"), object: nil, userInfo: userInfo)
        print(" nnn 6 ==============")
        //Http.alert("", " nnn 6 ==============")
    }
    
    func application(_ application: UIApplication, didFailToRegisterForRemoteNotificationsWithError error: Error) {
        print("error-\(error)-")
        print(" nnn 7 ==============")
        //Http.alert("", " nnn 7 ==============")
    }
    
    
    
    //-=-=-=-=-=-=-=-=-=-=-=-=-==-=-=fcm-=-=-=-=-=-=xxxxxxxxxxxx
    /***************************** Google  ******************************/
    
    @available(iOS 9.0, *)
    func application(_ application: UIApplication, open url: URL, options: [UIApplicationOpenURLOptionsKey : Any])
        -> Bool {
            if social == "FACEBOOK" {
                return FBSDKApplicationDelegate.sharedInstance().application(application, open: url, sourceApplication: options[UIApplicationOpenURLOptionsKey.sourceApplication] as? String, annotation: [:])
            } else if social == "GOOGLE" {
                return GIDSignIn.sharedInstance().handle(url, sourceApplication:options[UIApplicationOpenURLOptionsKey.sourceApplication] as? String, annotation: [:])
            }
            
            social = ""
            print(" nnn 8 ==============")
            //Http.alert("", " nnn 8 ==============")
            
            return false
    }
    
    
    public func sign(_ signIn: GIDSignIn!, didSignInFor user: GIDGoogleUser!, withError error: Error!) {
        if (error == nil) {
            // Perform any operations on signed in user here.
            /* let userId = user.userID                  // For client-side use only!
             let idToken = user.authentication.idToken // Safe to send to the server
             let fullName = user.profile.name
             let givenName = user.profile.givenName
             let familyName = user.profile.familyName
             let email = user.profile.email
             
             print("userId-\(userId)-")
             print("idToken-\(idToken)-")
             print("fullName-\(fullName)-")
             print("givenName-\(givenName)-")
             print("familyName-\(familyName)-")
             print("email-\(email)-")*/
        } else {
            print("sign error-\(error.localizedDescription)")
        }
    }
    
    func sign(_ signIn: GIDSignIn!, didDisconnectWith user:GIDGoogleUser!,
              withError error: Error!) {
        // Perform any operations when the user disconnects from app here.
        // ...
        print("signIn error-\(error.localizedDescription)")
    }
    
    
    func application(_ application: UIApplication, didReceiveRemoteNotification userInfo: [AnyHashable: Any],
                     fetchCompletionHandler completionHandler: @escaping (UIBackgroundFetchResult) -> Void) {
        print(userInfo)
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 5) { // change 2 to desired number of seconds
            // Your code with delay
            
            NotificationCenter.default.post(name: Notification.Name(rawValue: "ReceiveRemoteNotificationNew"), object: self, userInfo: userInfo)
            print(" nnn 9 ==============")
            //Http.alert("", " nnn 9 ==============")
        }
        
        completionHandler(UIBackgroundFetchResult.newData)
    }
    func curLocation() {
//        if (CLLocationManager.locationServicesEnabled()) {
//        }
//        if locManager != nil {
            locManager = CLLocationManager()

            locManager?.delegate = self
            locManager?.desiredAccuracy = kCLLocationAccuracyBest

            locManager?.requestAlwaysAuthorization()
            locManager?.requestWhenInUseAuthorization()

            locManager?.distanceFilter = 10
            locManager?.startUpdatingLocation()
            locManager?.startUpdatingHeading()

            // Check authorizationStatus
            let authorizationStatus = CLLocationManager.authorizationStatus()
            // List out all responses
            
            switch authorizationStatus {
            case .authorizedAlways:
                print("authorized")
            case .authorizedWhenInUse:
                print("authorized when in use")
            case .denied:
                print("denied")
            case .notDetermined:
                print("not determined")
            case .restricted:
                print("restricted")
            }
            
            // Get the location
            locManager?.startUpdatingLocation()
            
            if(CLLocationManager.authorizationStatus() == CLAuthorizationStatus.authorizedWhenInUse ||
                CLLocationManager.authorizationStatus() == CLAuthorizationStatus.authorizedAlways) {
                // Extract the location from CLLocationManager
//                let userLocation = locManager?.location
                
                // Check to see if it is nil
//                if userLocation != nil {
//                    //print("location is \(userLocation)")
//                } else {
//                    //print("location is nil")
//                }
            } else {
                if (CLLocationManager.authorizationStatus() == .denied) { // CLLocationManager.locationServicesEnabled() ||
                    locManager?.requestWhenInUseAuthorization()
//                    curLocation()
                }
                //print("not authorized")
            }
            
//        }else {
//            locManager?.requestWhenInUseAuthorization()
//        }
    }
    func askForLocationFetch(){
//        denied
    }
 
    var lastLocation:CLLocation? = nil

    func locationManager(_ manager: CLLocationManager, didUpdateHeading newHeading: CLHeading) {
        if manager.location?.coordinate.latitude != nil {
            let position111 = CLLocation(latitude: (manager.location?.coordinate.latitude)!, longitude: (manager.location?.coordinate.longitude)!)
            let  heading:Double = newHeading.trueHeading;
            
            if (lastLocation != nil) {
                
                if position111.distance(from: lastLocation!) > 5 {
                    print("heading---->",heading)
                    SOCKETIOCLIENTMANAGER.sharedInstance.updateMyLocation((manager.location?.coordinate.latitude)!,  (manager.location?.coordinate.longitude)!, heading)
                    lastLocation = position111
                }
            }else {
                lastLocation = position111
                SOCKETIOCLIENTMANAGER.sharedInstance.updateMyLocation((manager.location?.coordinate.latitude)!,  (manager.location?.coordinate.longitude)!, heading)
            }
            
        }
      

        
    }

    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        if (status == .authorizedWhenInUse  || status == .authorizedAlways) {
            // User has granted autorization to location, get location
//            curLocation()
            locManager?.startUpdatingLocation()
        }else {
           

        }

    }
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        if (manager.location?.coordinate.latitude) != nil &&  (manager.location?.coordinate.longitude) != nil{
//            var degree = 0.0
//              let head = manager.location?.course ?? 0
//            print("course----->",head)

//            if  let head = manager.location?.course  {
//                degree = head
//            }
        /*
            let position111 = CLLocation(latitude: (manager.location?.coordinate.latitude)!, longitude: (manager.location?.coordinate.longitude)!)
            let  heading:Double = 0.0 //newHeading.trueHeading;
            
            if (lastLocation != nil) {
                
                if position111.distance(from: lastLocation!) > 10 {
                    print("heading---->",heading)
                    SOCKETIOCLIENTMANAGER.sharedInstance.updateMyLocation((manager.location?.coordinate.latitude)!,  (manager.location?.coordinate.longitude)!, heading)
                }
            }else {
                SOCKETIOCLIENTMANAGER.sharedInstance.updateMyLocation((manager.location?.coordinate.latitude)!,  (manager.location?.coordinate.longitude)!, heading)
            }
            
            lastLocation = position111

            */
            
        }
    }
}


@available(iOS 10, *)
extension AppDelegate : UNUserNotificationCenterDelegate {
    
    
    // Receive displayed notifications for iOS 10 devices.
    func userNotificationCenter(_ center: UNUserNotificationCenter,
                                willPresent notification: UNNotification,
                                withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        let userInfo = notification.request.content.userInfo
        //himmmmm
        NotificationCenter.default.post(name: NSNotification.Name(rawValue: "ReceiveRemoteNotificationNew"), object: nil, userInfo: userInfo)
        
        // Print full message.
        print("userInfo 1st")
        print(userInfo)
        
        let id = userInfo["id"]
        let firstName = userInfo["first_name"]
        
        
        // Change this to your preferred presentation option
        completionHandler([])
    }
    
    func userNotificationCenter(_ center: UNUserNotificationCenter,
                                didReceive response: UNNotificationResponse,
                                withCompletionHandler completionHandler: @escaping () -> Void) {
        let userInfo = response.notification.request.content.userInfo
        
        NotificationCenter.default.post(name: NSNotification.Name(rawValue: "ReceiveRemoteNotificationNew"), object: nil, userInfo: userInfo)
        
        print("userInfo 2nd")
        print(userInfo)
        
        let id = userInfo["id"]
        let firstName = userInfo["first_name"]
        
        print(id ?? "")
        print(firstName ?? "")
        
        completionHandler()
    }
    
    

}
