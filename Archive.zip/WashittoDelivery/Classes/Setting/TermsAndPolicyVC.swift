//
//  TermsAndPolicyVC.swift
//  WashittoVendor
//
//  Created by Kavya mac 5 on 10/07/18.
//  Copyright © 2018 Himanshu pal. All rights reserved.
//

import UIKit
import HarishFrameworkSwift4

class TermsAndPolicyVC: UIViewController , UIWebViewDelegate{
    
    @IBOutlet var lblClassTitle: UILabel!
    @IBOutlet var webView: UIWebView!
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    
    //variables
    
    var strClassTitle = ""
    
    //MARK:- Life cycle Methods
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.DisplayAndDelegates()
      
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    override func viewWillAppear(_ animated: Bool) {
        
        self.navigationController?.isNavigationBarHidden = false
        navigationItem.hidesBackButton = false
        navigationController?.navigationBar.shouldRemoveShadow(true)
        self.setImageNavigation()
        
        rightMenuNavigationButton()
      
        if strClassTitle == "TermsAndConditions" {
             lblClassTitle.text = "Terms & Conditions".uppercased()
        }else{
             lblClassTitle.text = "Privacy Policy".uppercased()
        }
        self.ws_Terms_Policy()
    }
    
    func rightMenuNavigationButton()  {
        let button1 = UIBarButtonItem(image: UIImage(named: "menu"), style: .plain, target: self, action: #selector(actionRightMenuButton)) //
        self.navigationItem.rightBarButtonItem = button1
    }
    
    @objc func actionRightMenuButton() {
        // _ = self.navigationController?.popViewController(animated: true)
        self.sideMenuViewController.presentRightMenuViewController()
    }
    
    // MARK: - FUNCTIONS

    func DisplayAndDelegates() {
        
        webView.delegate = self
        webView.isOpaque = false
        webView.backgroundColor = UIColor.clear
        webView.scrollView.showsHorizontalScrollIndicator = false
        activityIndicator.isHidden = false
        
        //Static url
        
      //  let url = URL(string: "https://www.google.co.in")
      //  let loadRequest = URLRequest(url: url! as URL)
      //  webView.loadRequest(loadRequest)
        
    }
    
    //MARK:- webView delegates
    func webViewDidStartLoad(_ webView : UIWebView) {
        activityIndicator.startAnimating()
        activityIndicator.isHidden = false
    }
    
    func webViewDidFinishLoad(_ webView: UIWebView) {
        activityIndicator.stopAnimating()
        activityIndicator.isHidden = true
    }
    
    func webView(_ webView: UIWebView, didFailLoadWithError error: Error) {
        activityIndicator.isHidden = true
    }
    

     //MARK:- PrivacyPolicy  & TermsAndConditions

    func ws_Terms_Policy() {
        
        let params = NSMutableDictionary()
        
        var strUrl = WebServices.terms_and_Policy
        // type = terms / policy / fleet_agreement / fcra_agreement / state_agreement / consent_agreement
         if strClassTitle == "TermsAndConditions" {
            
//            params["type"]  = "terms"
            strUrl = WebServices.agreement_content_type+"terms"
            //"\(WebServices.terms_and_Policy)terms"
        }else {
//            params["type"]  = "policy"
            strUrl = WebServices.agreement_content_type+"policy"
            //"\(WebServices.terms_and_Policy)policy"
        }
        
          Http.instance().json(strUrl, nil, "GET", ai: true, popup: true, prnt: true, sync: false) { (json, dict, str) in
            
            if json != nil {
                let json1 = json as? NSDictionary
                if number(json1! , "success").boolValue {
                    if let result = json1?["result"] as? NSDictionary {
                         //self.dictResult = result.mutableCopy() as! NSDictionary
                        // self.createArrayTime ()
                       
                        if let content = result.object(forKey: "content") {
                         
                            self.webView.loadHTMLString(content as! String, baseURL: nil)
                        }
                    }
                    print(json1!)
                }else {
                    Http.alert("", string(json1! , "message"))
                }
            }
        }
    }
    
    
    
    
    
}








