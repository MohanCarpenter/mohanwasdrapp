//
//  AboutAppVC.swift
//  Stupitt
//
//  Created by Himanshu on 20/02/18.
//  Copyright © 2018 mac. All rights reserved.
//

import UIKit
import MessageUI
import HarishFrameworkSwift4
import UIKit
import MapKit
class AboutAppVC: UIViewController,MFMailComposeViewControllerDelegate {
    
    @IBOutlet var lblversion: UILabel!
    @IBOutlet var lblDiscription: UILabel!
    @IBOutlet var lblcall: UILabel!
    @IBOutlet var lblEmail: UILabel!
    @IBOutlet var lblweb: UILabel!
    @IBOutlet var lblMapAddress: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        self.ws_BaseInfo()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override func viewWillAppear(_ animated: Bool) {
        rightMenuNavigationButton() 
    }
    
    func rightMenuNavigationButton()  {
        let button1 = UIBarButtonItem(image: UIImage(named: "menu"), style: .plain, target: self, action: #selector(actionRightMenuButton)) //
        self.navigationItem.rightBarButtonItem = button1
    }
    
    @objc func actionRightMenuButton() {
        // _ = self.navigationController?.popViewController(animated: true)
        self.sideMenuViewController.presentRightMenuViewController()
    }
    
    //MARK:- Functions
    
    func displayAppInfo()  {
       
        if let version = Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String {
            print(version)
            lblversion.text = "V \(version)"
        }
        
        if let buildVersion = Bundle.main.infoDictionary?["CFBundleVersion"] as? String {
            print(buildVersion)
          lblDiscription.text = "Build (\(buildVersion))"
        }
      
        lblcall.text = string(dictResult, "contact_number")
        lblEmail.text = string(dictResult, "contact_email")
        email = string(dictResult, "contact_email")
        lblweb.text = string(dictResult, "contact_website")
        lblMapAddress.text = string(dictResult, "contact_address")
    }
    
 
    //MARK:- Button Actions
    
    @IBAction func actionCall(_ sender: Any) {
        
        let contact_number = string(dictResult, "contact_number")
        
        callNumber(contact_number)
        //        let parameterString =  String(format:"tel://%@","9074235235")
        //        print(parameterString)
        //
        //        let url:NSURL = NSURL(string: parameterString as String)!
        //        UIApplication.shared.openURL(url as URL)
    }
    
    var email = "washitto@gmail.com"
    
    @IBAction func actionMail(_ sender: Any) {
        let mailComposeViewController = configuredMailComposeViewController()
        if MFMailComposeViewController.canSendMail() {
            self.present(mailComposeViewController, animated: true, completion: nil)
        } else {
            self.showSendMailErrorAlert()
        }
    }
    
    func configuredMailComposeViewController() -> MFMailComposeViewController {
        let mailComposerVC = MFMailComposeViewController()
        mailComposerVC.mailComposeDelegate = self
        mailComposerVC.setToRecipients([email])
        mailComposerVC.setSubject("Message")
        mailComposerVC.setMessageBody("Sending e-mail in-app", isHTML: false)
        
        return mailComposerVC
    }
    
    func showSendMailErrorAlert() {
        Http.alert("Could Not Send Email", "Your device could not send e-mail.  Please check e-mail configuration and try again.")
    }
    
    // MARK: MFMailComposeViewControllerDelegate Method
    func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {
        controller.dismiss(animated: true, completion: nil)
    }
    
    
    @IBAction func actionWeb(_ sender: Any) {
        var website = string(dictResult, "contact_website")
        
        if !website.contains("http://") && !website.contains("https://"){
            website = "http://" + website
            print("doznt contains http://")
        }
       print("website-->>\(website)")
        let url : NSURL = NSURL(string: website)!
        if UIApplication.shared.canOpenURL(url as URL) {
            if #available(iOS 10.0, *) {
                UIApplication.shared.open(url as URL, options: [:], completionHandler: nil)
           
            } else {
                UIApplication.shared.openURL(url as URL)
            }
        }
        
    }
    
    @IBAction func actionMap(_ sender: Any) {
        
        //  if let result = (dictResult as AnyObject).object(forKey: "address") as? NSDictionary{
        let lat = string(dictResult, "contact_latitude")
        let long = string(dictResult, "contact_longitude")
        
        //   let url = "http://maps.apple.com/maps?saddr=\(lat),\(long)"
        //  UIApplication.shared.openURL(URL(string:url)!)
        
        let latitude: CLLocationDegrees = Double(lat)!
        let longitude: CLLocationDegrees = Double(long)!
        
        let regionDistance:CLLocationDistance = 10000
        let coordinates = CLLocationCoordinate2DMake(latitude, longitude)
        let regionSpan = MKCoordinateRegionMakeWithDistance(coordinates, regionDistance, regionDistance)
        let options = [
            MKLaunchOptionsMapCenterKey: NSValue(mkCoordinate: regionSpan.center),
            MKLaunchOptionsMapSpanKey: NSValue(mkCoordinateSpan: regionSpan.span)
        ]
        let placemark = MKPlacemark(coordinate: coordinates, addressDictionary: nil)
        let mapItem = MKMapItem(placemark: placemark)
        mapItem.name = "Washitto"
        mapItem.openInMaps(launchOptions: options)
        
        //   }
        ///for apple map  ° N,
        
        // Open and show coordinate
        
        
        // Navigate from one coordinate to another
        /* let url = "http://maps.apple.com/maps?saddr=\(from.latitude),\(from.longitude)&daddr=\(to.latitude),\(to.longitude)"
         UIApplication.shared.openURL(URL(string:url)!)*/
        
        
        
        //for google map
        /* if (UIApplication.shared.canOpenURL(NSURL(string:"comgooglemaps://")! as URL)) {
         UIApplication.shared.openURL(NSURL(string:
         "comgooglemaps://?saddr=&daddr=\(22.7196),\(75.8577)&directionsmode=driving")! as URL)
         
         } else {
         NSLog("Can't use comgooglemaps://");
         }
         
         let strLat : String = "23.035007"
         let strLong : String = "72.529324"
         
         let strLat1 : String = "23.033331"
         let strLong2 : String = "72.524510"
         if (UIApplication.shared.canOpenURL(URL(string:"comgooglemaps://")!)) {
         UIApplication.shared.openURL(URL(string:"comgooglemaps://?saddr=\(strLat),\(strLong)&daddr=\(strLat1),\(strLong2)&directionsmode=driving&zoom=14&views=traffic")!)
         }
         else {
         print("Can't use comgooglemaps://");
         }*/
        
    }
    
    
    //var dictData = NSDictionary()
    var dictResult = NSDictionary()
    
    // MARK:- ws_BaseInfo
    
    func ws_BaseInfo(){
        
        Http.instance().json(WebServices.baseapi, nil, "GET", ai: true, popup: true, prnt: true, userInfo.Token(), sync: false) { (json, dict, str) in
            
            if json != nil {
                let json1 = json as? NSDictionary
                if number(json1! , "success").boolValue {
                    if let result = json1?["result"] as? NSDictionary {
                        // self.dictResult = result.mutableCopy() as! NSDictionary
                        // self.createArrayTime ()
                        
                        if let contacts = (result as AnyObject).object(forKey: "contacts") as? NSDictionary{
                            
                            self.dictResult = contacts.mutableCopy() as! NSDictionary
                            print("dictResult-->>",self.dictResult)
                            self.displayAppInfo()
                        }
                    }
                    print(json1!)
                }else {
                    Http.alert("", string(json1! , "message"))
                }
            }
        }
    }
   
    
}

