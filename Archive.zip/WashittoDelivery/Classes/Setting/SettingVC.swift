//
//  SettingVC.swift
//  WashittoVendor
//
//  Created by Himanshu on 09/07/18.
//  Copyright © 2018 Himanshu pal. All rights reserved.
//

import UIKit
import HarishFrameworkSwift4

class SettingVC: UIViewController {
    
    @IBOutlet weak var imgSwitchNotification: UIImageView!
    @IBOutlet weak var imgSwitchSound: UIImageView!
    @IBOutlet weak var imgSwitchVibration: UIImageView!
    
    @IBOutlet weak var btnSwitchNotification: UIButton!
    @IBOutlet weak var btnSwitchSound: UIButton!
    @IBOutlet weak var btnSwitchVibration: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        /*  var img = 0
         for i in 0..<84 {
         
         print("UIImage(named: \"str_\(i).png\")!,")
         }*/
        self.displayDefaultInfo()
        
        
    }
    override func viewWillAppear(_ animated: Bool) {
        // self.title = "Sign Up"
        self.navigationController?.isNavigationBarHidden = false
        navigationItem.hidesBackButton = false
        navigationController?.navigationBar.shouldRemoveShadow(true)
        self.setImageNavigation()
        //  self.sideMenuViewController.panGestureEnabled = false
        
    }
    override func viewWillDisappear(_ animated: Bool) {
        self.title = ""
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    @IBAction func actionMenu(_ sender: Any) {
        self.sideMenuViewController.presentRightMenuViewController()
    }
    
    func displayDefaultInfo()  {
        
        if let userdetail:NSDictionary = userInfo.getLoginInfo()  {
            print("userdetail ======>",userdetail)
            
            let is_notification_enable = number(userdetail , "is_notification_enable").boolValue
            
            
            if is_notification_enable {
                btnSwitchVibration.isUserInteractionEnabled = true
                btnSwitchSound.isUserInteractionEnabled = true
                
                btnSwitchNotification.isSelected = true
                imgSwitchNotification.image = UIImage(named: "switch_on")
                
                let is_sound_enable = number(userdetail , "is_sound_enable").boolValue
                
                if is_sound_enable {
                    btnSwitchSound.isSelected = true
                    imgSwitchSound.image = UIImage(named: "switch_on")
                }else{
                    
                    btnSwitchSound.isSelected = false
                    imgSwitchSound.image = UIImage(named: "switch_off")
                }
                
                let is_vibration_enable = number(userdetail , "is_notification_enable").boolValue
                
                if is_vibration_enable {
                    btnSwitchVibration.isSelected = true
                    imgSwitchVibration.image = UIImage(named: "switch_on")
                }else{
                    
                    btnSwitchVibration.isSelected = false
                    imgSwitchVibration.image = UIImage(named: "switch_off")
                }
                
            }else{
                
                // btnSwitchNotification.isSelected = false
                btnSwitchNotification.isSelected = false
                imgSwitchNotification.image = UIImage(named: "switch_off")
                
                imgSwitchSound.image = UIImage(named: "switch_off")
                imgSwitchVibration.image = UIImage(named: "switch_off")
                
                btnSwitchSound.isSelected = false
                btnSwitchVibration.isSelected = false
                
                btnSwitchVibration.isUserInteractionEnabled = false
                btnSwitchSound.isUserInteractionEnabled = false
                
                //ws_UpdateSetting(strParameter:"is_sound_enable",strValue:"0")
                //ws_UpdateSetting(strParameter:"is_vibration_enable",strValue:"0")
                
            }
        }
        
        
    }
    
    
    //MARK:- Button Actions
    @IBAction func actionNotification(_ sender: Any) {
        
        
        if imgSwitchNotification.image == UIImage(named: "switch_off"){
            ws_UpdateSetting(strParameter:"is_notification_enable",strValue:"1", isGlobel: "Notification")
            
        }else{
            ws_UpdateSetting(strParameter:"is_notification_enable",strValue:"0", isGlobel: "Notification")
        }
        
        
        
        
        /*
         if btnSwitchNotification.isSelected {
         btnSwitchNotification.isSelected = false
         imgSwitchNotification.image = UIImage(named: "switch_off")
         ws_UpdateSetting(strParameter:"is_notification_enable",strValue:"0", isGlobel: "Yes")
         imgSwitchSound.image = UIImage(named: "switch_off")
         imgSwitchVibration.image = UIImage(named: "switch_off")
         
         btnSwitchSound.isSelected = false
         btnSwitchVibration.isSelected = false
         
         btnSwitchVibration.isUserInteractionEnabled = false
         btnSwitchSound.isUserInteractionEnabled = false
         
         }else{
         btnSwitchVibration.isUserInteractionEnabled = true
         btnSwitchSound.isUserInteractionEnabled = true
         
         btnSwitchNotification.isSelected = true
         imgSwitchNotification.image = UIImage(named: "switch_on")
         
         btnSwitchSound.isSelected = false
         btnSwitchVibration.isSelected = false
         
         imgSwitchSound.image = UIImage(named: "switch_on")
         imgSwitchVibration.image = UIImage(named: "switch_on")
         ws_UpdateSetting(strParameter:"is_notification_enable",strValue:"1", isGlobel: "Yes")
         }*/
        
    }
    
    @IBAction func actionSound(_ sender: Any) {
        
        
        if imgSwitchSound.image == UIImage(named: "switch_off"){
            ws_UpdateSetting(strParameter:"is_sound_enable",strValue:"1", isGlobel: "Sound")
            
        }else{
            ws_UpdateSetting(strParameter:"is_sound_enable",strValue:"0", isGlobel: "Sound")
        }
        
        
        //        if btnSwitchSound.isSelected {
        //            btnSwitchSound.isSelected = false
        //            imgSwitchSound.image = UIImage(named: "switch_off")
        //
        //            ws_UpdateSetting(strParameter:"is_sound_enable",strValue:"0", isGlobel: "Sound")
        //
        //        }else{
        //            btnSwitchSound.isSelected = true
        //            imgSwitchSound.image = UIImage(named: "switch_on")
        //            ws_UpdateSetting(strParameter:"is_sound_enable",strValue:"1", isGlobel: "Sound")
        //        }
        
    }
    
    @IBAction func actionVibration(_ sender: Any) {
        
        if imgSwitchVibration.image == UIImage(named: "switch_off"){
            ws_UpdateSetting(strParameter:"is_vibration_enable",strValue:"1", isGlobel: "Vibration")
            
        }else{
            ws_UpdateSetting(strParameter:"is_vibration_enable",strValue:"0", isGlobel: "Vibration")
        }
        
        
        
        //        if btnSwitchVibration.isSelected {
        //            btnSwitchVibration.isSelected = false
        //            imgSwitchVibration.image = UIImage(named: "switch_off")
        //            ws_UpdateSetting(strParameter:"is_vibration_enable",strValue:"0", isGlobel: "Vibration")
        //        }else{
        //            btnSwitchVibration.isSelected = true
        //            imgSwitchVibration.image = UIImage(named: "switch_on")
        //            ws_UpdateSetting(strParameter:"is_vibration_enable",strValue:"1", isGlobel: "Vibration")
        //        }
        
    }
    
    @IBAction func actionAboutApp(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "AboutAppVC") as! AboutAppVC
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func actionTermsConditions(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "TermsAndPolicyVC") as! TermsAndPolicyVC
        vc.strClassTitle = "TermsAndConditions"
        self.navigationController?.pushViewController(vc, animated: true)
    }
    @IBAction func actionPrivacyPolicy(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "TermsAndPolicyVC") as! TermsAndPolicyVC
        vc.strClassTitle = "PrivacyPolicy"
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    //MARK:- ws_UpdateSetting
    func ws_UpdateSetting(strParameter:String,strValue:String,isGlobel:String) {
        
        let params = NSMutableDictionary()
        
        if strParameter ==  "is_notification_enable"{
            params["is_notification_enable"]  = strValue
            params["is_sound_enable"]  = strValue
            params["is_vibration_enable"]  = strValue
        }else if strParameter ==  "is_sound_enable"{
            params["is_sound_enable"]  = strValue
        }else  if strParameter ==  "is_vibration_enable"{
            params["is_vibration_enable"]  = strValue
        }
        
        Http.instance().json(WebServices.update_settings, params, "POST", ai: true, popup: true, prnt: true, userInfo.Token(),  sync: false) { (json, params, strJson) in
            
            if json != nil {
                
                let json = json as? NSDictionary
                if number(json! , "success").boolValue {
                    
                    if let userdetail:NSDictionary = userInfo.getLoginInfo()  {
                        print("userdetail ======>",userdetail)
                        
                        let dictSetting = userdetail.mutableCopy() as! NSMutableDictionary
                        
                        if isGlobel == "Notification"{
                            
                            if self.imgSwitchNotification.image == UIImage(named: "switch_off"){
                                self.imgSwitchNotification.image = UIImage(named: "switch_on")
                                self.imgSwitchSound.image = UIImage(named: "switch_on")
                                self.imgSwitchVibration.image = UIImage(named: "switch_on")
                                
                                self.btnSwitchVibration.isUserInteractionEnabled = true
                                self.btnSwitchSound.isUserInteractionEnabled = true
                                
                            }else{
                                self.imgSwitchNotification.image = UIImage(named: "switch_off")
                                self.imgSwitchSound.image = UIImage(named: "switch_off")
                                self.imgSwitchVibration.image = UIImage(named: "switch_off")
                                
                                self.btnSwitchVibration.isUserInteractionEnabled = false
                                self.btnSwitchSound.isUserInteractionEnabled = false
                                
                                
                            }
                            
                            dictSetting.removeObject(forKey: "is_notification_enable")
                            dictSetting.removeObject(forKey: "is_sound_enable")
                            dictSetting.removeObject(forKey: "is_vibration_enable")
                            
                            dictSetting["is_notification_enable"] = strValue
                            dictSetting["is_sound_enable"] = strValue
                            dictSetting["is_vibration_enable"] = strValue
                            
                        }else if isGlobel == "Sound"{
                            
                            if self.imgSwitchSound.image == UIImage(named: "switch_off"){
                                self.imgSwitchSound.image = UIImage(named: "switch_on")
                            }else{
                                self.imgSwitchSound.image = UIImage(named: "switch_off")
                            }
                            
                            
                            dictSetting.removeObject(forKey: "is_sound_enable")
                            
                            dictSetting["is_sound_enable"] = strValue
                            
                            
                        }else if isGlobel == "Vibration"{
                            if self.imgSwitchVibration.image == UIImage(named: "switch_off"){
                                self.imgSwitchVibration.image = UIImage(named: "switch_on")
                            }else{
                                self.imgSwitchVibration.image = UIImage(named: "switch_off")
                            }
                            
                            dictSetting.removeObject(forKey: "is_vibration_enable")
                            
                            dictSetting["is_vibration_enable"] = strValue
                            
                        }
                        print("dictSetting ======>",dictSetting)
                        userInfo.saveLoginInfo(dictSetting)
                        //self.displayDefaultInfo()
                    }
                }
                
            }else {
                Http.alert("", string(json as! NSDictionary , "message"))
                
            }
        }
    }
    
    
    
    
    
    
    
}
