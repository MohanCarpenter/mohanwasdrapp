//
//  ForgotPassword.swift
//  Washitto
//
//  Created by Himanshu on 28/06/18.
//  Copyright © 2018 Himanshu. All rights reserved.
//

import UIKit
import HarishFrameworkSwift4
class ForgotPassword: UIViewController , UITextFieldDelegate{
    @IBOutlet var tfEmail: TextField!

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    override func viewWillAppear(_ animated: Bool) {
        self.title = "Forgot Password"
        self.navigationController?.isNavigationBarHidden = false
        navigationItem.hidesBackButton = false
        navigationController?.navigationBar.shouldRemoveShadow(true)
        
    }
    override func viewWillDisappear(_ animated: Bool) {
        self.title = ""
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
         textField.resignFirstResponder()
        return true
    }
    
    func ws_ForgotPassword() {
        let params = NSMutableDictionary()
        params["email"] = tfEmail.text!
        
        Http.instance().json(WebServices.forgotpassword, params, "POST", ai: true, popup: true, prnt: true, userInfo.Token(), sync: false) { (json, dict, str) in
            
            if json != nil {
                let json1 = json as? NSDictionary
                if number(json1! , "success").boolValue {
                    Http.alert("", string(json1! , "message"))
                    self.navigationController?.popViewController(animated: true)
                }else {
                    Http.alert("", string(json1! , "message"))
                }
            }
        }
    }
    
  
    @IBAction func actionForgotPassword(_ sender: Any) {
        self.view.endEditing(true)
        if let str = self.checkValidation() {
            Http.alert("", str)
            
        } else {
            ws_ForgotPassword()
            
        }
        
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        let length = (textField.text?.count)! + string.count - range.length
        
    if textField == tfEmail {
            let validCharacterSet = NSCharacterSet(charactersIn: APPConstants.emailAcceptableCharacter).inverted
            let filter = string.components(separatedBy: validCharacterSet)
            if filter.count == 1 {
                
                return (length > 50) ? false : true
            } else {
                return false
            }
        }
            
       
        return true
    }
    
    func checkValidation() -> String? {
         if tfEmail.text?.count == 0 {
            return "Please enter your email."
        } else if !Valid.email(tfEmail.text!) {
            return "Please enter valid email."
        }
        
        
        return nil
    }

}
