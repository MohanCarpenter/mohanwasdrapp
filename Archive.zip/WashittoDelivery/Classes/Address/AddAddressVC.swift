//
//  EditProfileVC.swift
//  EcoGadiDriver
//
//  Created by Kavya Mac Mini 1 on 20/06/18.
//  Copyright © 2018 Kavya Mac Mini 1. All rights reserved.
//

import UIKit
import HarishFrameworkSwift4
import CoreLocation
import GooglePlaces
import GooglePlacePicker

class AddAddressVC: UIViewController, UITextFieldDelegate,  UINavigationControllerDelegate ,CLLocationManagerDelegate,GMSPlacePickerViewControllerDelegate,AudioPlayerViewDelegate{
    
    @IBOutlet var btnAddEditButton: Button!
    @IBOutlet var lblAddEditAddress: UILabel!
    @IBOutlet var tfZipCode: TextField!
    @IBOutlet var tfAddress: TextField!
    @IBOutlet var scrollView: UIScrollView!
    @IBOutlet var tfCountry: UITextField!
    @IBOutlet var tfState: UITextField!
    @IBOutlet var tfCity: UITextField!
    
    var edit = ""
    var comeFrom = ""
    var countryID = ""
    var stateID = ""
    var cityID = ""
    var arrComman = NSMutableArray()
    var boolProfilePicture = false
    var imgProfilePicture:UIImage? = nil
    var picker:UIImagePickerController? = UIImagePickerController()
    
    var mydict:AddressListClass?
    var arrtblList = NSMutableArray()

    var  lat = Double()
    var long = Double()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
      //  addDoneButtonOnKeyboard()
        registerForKeyboardNotifications()
        self.navigationController?.isNavigationBarHidden = false
        navigationItem.hidesBackButton = false
        navigationController?.navigationBar.shouldRemoveShadow(true)
        self.setImageNavigation()
        setDefaultCountry()
    }
    func setDefaultCountry(){
        
        // set default country and state
        tfCountry.text! = "United States"
        countryID =  "231"
        
        tfState.text! = "New York"
        stateID = "3956"
        
        tfCountry.rightViewMode = UITextFieldViewMode.always
        tfState.rightViewMode = UITextFieldViewMode.always
        tfCity.rightViewMode = UITextFieldViewMode.always
        tfCountry.rightView = UIView().addPaddingView(UIImage(named:"drop_down")!)
        tfState.rightView = UIView().addPaddingView(UIImage(named:"drop_down")!)
        tfCity.rightView = UIView().addPaddingView(UIImage(named:"drop_down")!)
        
        ws_AddressList()
        
        if edit == "yes"{
            
            
            
            
            lblAddEditAddress.text = "Update Address"
            btnAddEditButton.setTitle("Update Address", for: .normal)
        }else{
            lblAddEditAddress.text = "Add Address"
            btnAddEditButton.setTitle("Add Address", for: .normal)
            
        }
        
        rightMenuNavigationButton()

    }
    
    
   
 // http://18.206.160.19/washitto/api/v1/address
    
    func ws_AddressList() {
        
        Http.instance().json(WebServices.address, nil, "GET", ai: true, popup: true, prnt: true, userInfo.Token(), sync: false) { (json, dict, str) in
            
            if json != nil {
                let json1 = json as? NSDictionary
                if number(json1! , "success").boolValue {
                    self.arrtblList = NSMutableArray()
                    if let arr = json1?.object(forKey: "result") as? NSArray {
                    

                        for i in 0..<arr.count {
                            let dict = arr.object(at: i) as! NSDictionary
                            print(dict)
                            if number(dict, "is_default").intValue ==  1 {
                                let ob = AddressListClass()
                                ob.address =  string(dict, "address")
                                ob.city_id =  string(dict, "city_id")
                                ob.city_name =  string(dict, "city_name")
                                ob.country_id =  string(dict, "country_id")
                                ob.country_name =  string(dict, "country_name")
                                ob.full_address =  string(dict, "full_address")
                                ob.id =  string(dict, "id")
                                ob.is_default =  string(dict, "is_default")
                                ob.latitude =  string(dict, "latitude")
                                ob.longitude =  string(dict, "longitude")
                                ob.state_id =  string(dict, "state_id")
                                ob.state_name =  string(dict, "state_name")
                                ob.status =  string(dict, "status")
                                ob.user_id =  string(dict, "user_id")
                                ob.zipcode =  string(dict, "zipcode")
                                self.mydict = ob
                                self.setAddress()
                            }
                            // is_default
                          
//                            self.setAddress() arrtblList.add(ob)
                        }
                        
                    }
                    
                    
                }
            }
        }
    }
    func setAddress(){
        lat = Double((mydict?.latitude)!)!
        long = Double((mydict?.longitude)!)!
        tfZipCode.text! = (mydict?.zipcode)!
        tfAddress.text! = (mydict?.address)!
        tfCountry.text! = (mydict?.country_name)!
        countryID = (mydict?.country_id)!
        tfState.text = mydict?.state_name
        stateID = (mydict?.state_id)!
        tfCity.text = mydict?.city_name
        cityID = (mydict?.city_id)!
    }
    
    func rightMenuNavigationButton()  {
        let button1 = UIBarButtonItem(image: UIImage(named: "menu"), style: .plain, target: self, action: #selector(actionRightMenuButton)) //
        self.navigationItem.rightBarButtonItem = button1
    }
    
    @objc func actionRightMenuButton() {
        // _ = self.navigationController?.popViewController(animated: true)
        self.sideMenuViewController.presentRightMenuViewController()
    }
    
    @objc func actionWithParam(sender: UIButton){
        _ = self.navigationController?.popViewController(animated: true)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        self.title  = ""
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
 
    func checkValidation() -> String? {
        
        if tfAddress.text == "Address" {
            return "Please enter address"
        }
        else  if tfCountry.text! == "Country" {
            return "Please select country"
        } else if tfState.text! == "State" ||   tfState.text! == ""  {
            return "Please select state"
            
        } else if tfCity.text! == "City" || tfCity.text! == "" {
            return "Please select city"
        }else if tfZipCode.text?.count == 0 {
            return "Please enter zipcode."
        }
        
        return nil
    }

    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        let length = (textField.text?.count)! + string.count - range.length
        
        if textField == tfZipCode {
            
            let validCharacterSet = NSCharacterSet(charactersIn: APPConstants.phoneNoAcceptableCharacter).inverted
            let filter = string.components(separatedBy: validCharacterSet)
            if filter.count == 1 {
                
                return (length > 6) ? false : true
            } else {
                return false
            }
        }
        
        return true
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        
        return true
    }
    
    //***************************************************************//
    //MARK:- KEYBOARD NOTIFICATION METHODS
    func registerForKeyboardNotifications() {
        let notificationCenter = NotificationCenter.default
        notificationCenter.addObserver(self, selector: #selector(adjustForKeyboard), name: Notification.Name.UIKeyboardWillHide, object: nil)
        notificationCenter.addObserver(self, selector: #selector(adjustForKeyboard), name: Notification.Name.UIKeyboardWillChangeFrame, object: nil)
    }
    
    func deregisterFromKeyboardNotifications() {
        NotificationCenter.default.removeObserver(self, name: .UIKeyboardWillShow, object: nil)
        NotificationCenter.default.removeObserver(self, name: .UIKeyboardWillHide, object: nil)
    }
    
    @objc func adjustForKeyboard(notification: Notification) {
        let userInfo = notification.userInfo!
        
        let keyboardScreenEndFrame = (userInfo[UIKeyboardFrameEndUserInfoKey] as! NSValue).cgRectValue
        let keyboardViewEndFrame = view.convert(keyboardScreenEndFrame, from: view.window)
        
        if notification.name == Notification.Name.UIKeyboardWillHide {
            scrollView.contentInset = UIEdgeInsets.zero
            
        } else {
            scrollView.contentInset = UIEdgeInsets(top: 0, left: 0, bottom: keyboardViewEndFrame.height + 10, right: 0)
        }
        
        scrollView.scrollIndicatorInsets = scrollView.contentInset
    }
    
    /////////__________***********************_________
    
    func addDoneButtonOnKeyboard() {
        let doneToolbar: UIToolbar = UIToolbar(frame: CGRect(x: 0, y: 0, width: 320, height: 50))
        doneToolbar.barStyle = UIBarStyle.blackTranslucent
        doneToolbar.barTintColor = appColor
        doneToolbar.tintColor = UIColor.white
        
        let flexSpace = UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.flexibleSpace, target: nil, action: nil)
        
        let next: UIBarButtonItem = UIBarButtonItem(title: "Next", style: UIBarButtonItemStyle.done, target: self, action: #selector(self.nextOfDoneTool))
        let done: UIBarButtonItem = UIBarButtonItem(title: "Done", style: UIBarButtonItemStyle.done, target: self, action: #selector(self.done))
        
        var items:[UIBarButtonItem] = []
        items.append(next)
        items.append(flexSpace)
        items.append(done)
        doneToolbar.items = items
        doneToolbar.sizeToFit()
        self.tfZipCode.inputAccessoryView = doneToolbar
    }
    
    @objc func done() {
        tfZipCode.resignFirstResponder()
    }
    
    @objc func nextOfDoneTool() {
        tfAddress.becomeFirstResponder()
    }
 
    @IBAction func actionupdateProfile(_ sender: Any) {
        self.view.endEditing(true)
        if let str = self.checkValidation() {
            Http.alert("", str)
            
        } else {
            if edit == "yes"{
             
                ws_editProfile()
            }else{
                ws_addProfile()
            }
        }
        
    }
    
    
    func ws_editProfile() {
        
        let params = NSMutableDictionary()
        params["zipcode"] = tfZipCode.text!
        params["address"] = tfAddress.text!
        params["city_id"] = cityID
        params["country_id"] = countryID
        params["state_id"] = stateID
        params["latitude"] = lat
        params["longitude"] = long
        params["id"] = mydict?.id
        
        Http.instance().json(WebServices.addressedit, params, "POST", ai: true, popup: true, prnt: true, userInfo.Token(), sync: false) { (json, dict, str) in
            
            if json != nil {
                let json1 = json as? NSDictionary
                if number(json1! , "success").boolValue {
                    
                    self.navigationController?.popViewController(animated: true)
                    Http.alert("", string(json1! , "message"))
                } else {
                    Http.alert("", string(json1! , "message"))
                }
            }
        }
    }
    
    func ws_addProfile() {
       
        let params = NSMutableDictionary()
        params["zipcode"] = tfZipCode.text!
        params["address"] = tfAddress.text!
        params["city_id"] = cityID
        params["country_id"] = countryID
        params["state_id"] = stateID
        params["latitude"] = lat
        params["longitude"] = long
        
       Http.instance().json(WebServices.addressadd, params, "POST", ai: true, popup: true, prnt: true, userInfo.Token(), sync: false) { (json, dict, str) in
            
            if json != nil {
                let json1 = json as? NSDictionary
                if number(json1! , "success").boolValue {
                    
                    self.navigationController?.popViewController(animated: true)
                    Http.alert("", string(json1! , "message"))
                } else {
                    Http.alert("", string(json1! , "message"))
                }
            }
        }
    }
    
    @IBAction func actionCountry(_ sender: Any) {
        self.view.endEditing(true)
        comeFrom = "Country"
        tfState.text! = ""
        tfCity.text! = ""
        countryID = ""
        stateID = ""
        cityID = ""
        let audio = self.storyboard?.instantiateViewController(withIdentifier:"SelectCountryVC") as! SelectCountryVC
        audio.delegate = self
        audio.comefrom  = "Country"
        self.present(audio, animated: false, completion: {
            print("Country")
        })
    }
    
    @IBAction func actionState(_ sender: Any) {
        
        self.view.endEditing(true)
        comeFrom = "State"
        if countryID != "" {
            tfCity.text! = ""
            let audio = self.storyboard?.instantiateViewController(withIdentifier:"SelectCountryVC") as! SelectCountryVC
            audio.delegate = self
            audio.comefrom  = "State"
            audio.comeid = countryID
            self.present(audio, animated: false, completion: {
                print("State ")
            })
        } else {
            Http.alert("", "Please first select country.")
            //                let alert = UIAlertController(title: "", message: "Please first select country.", preferredStyle: UIAlertControllerStyle.alert)
            //                alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
            //                self.present(alert, animated: true, completion: nil)
        }
        
    }
    @IBAction func actionCity(_ sender: Any) {
        if countryID != "" && stateID != ""{
            comeFrom = "City"
            self.view.endEditing(true)
            let audio = self.storyboard?.instantiateViewController(withIdentifier:"SelectCountryVC") as! SelectCountryVC
            audio.delegate = self
            audio.comefrom  = "City"
            audio.comeid = stateID
            self.present(audio, animated: false, completion: {
                print("ACity")
            })
            
        } else {
            Http.alert("", "Please first select state.")
            
        }
    }
    
    
    func select(_ id: String, _ name: String) {
        if comeFrom == "Country"{
            tfCountry.text = name
            countryID = id
        }else if comeFrom == "State"{
            tfState.text = name
            stateID = id
        }else if comeFrom == "City"{
            tfCity.text = name
            cityID = id
        }
        print(id)
        print(name)
    }
    
    
    @IBAction func actionplacePicker(_ sender: Any) {
//        tfAddress.text = ""
        let config = GMSPlacePickerConfig(viewport: nil)
        let placePicker = GMSPlacePickerViewController(config: config)
        
        placePicker.delegate = self
        
        let autocompleteController = GMSAutocompleteViewController()
        autocompleteController.delegate = self as? GMSAutocompleteViewControllerDelegate
        UINavigationBar.appearance().tintColor = UIColor.white
        //UISearchBar.appearance.textField.setTextColor = UIColor.red
        if #available(iOS 9.0, *) {
            UITextField.appearance(whenContainedInInstancesOf: [UISearchBar.self]).defaultTextAttributes = [NSAttributedStringKey.foregroundColor.rawValue: UIColor.white]
        } else {
            // Fallback on earlier versions
        }
        UISearchBar.appearance().barStyle = UIBarStyle.default
    //    self.present(autocompleteController, animated: true, completion:nil)
        
        
        present(placePicker, animated: true, completion: nil)
        
    }
    var locationCoordinates = CLLocationCoordinate2D()
    func placePicker(_ viewController: GMSPlacePickerViewController, didPick place: GMSPlace) {
        // Dismiss the place picker, as it cannot dismiss itself.
        viewController.dismiss(animated: true, completion: nil)
        
//print("Place name --->\(place.name) -placeID------>\(place.placeID) -place----->\(place)")

        
       locationCoordinates = place.coordinate
        lat = locationCoordinates.latitude
        long = locationCoordinates.longitude
        
        if let add = place.formattedAddress {
        if String(place.name) != "" {
          //  print("Place address ----->\(add)")
            
            self.tfAddress.text = String(place.name)
            
        }else {
            searchAddress()
        }
        }else{
          searchAddress()
        }
    }
    
    func searchAddress(){
        let strApi = "https://maps.googleapis.com/maps/api/geocode/json?address=\(lat),\(long)&key=\(APPConstants.googleApiKey)"
        
        print("strApi------->>",strApi)
        Http.instance().json(strApi, nil, "GET", ai: true, popup: false, prnt: false, completionHandler: { (json, params, responce)  in
            
            if let result1 = json   {
            print("json>>\(json!)")
              
                if let result = (result1 as AnyObject).object(forKey: "results") as? NSArray {
                    var zero = ""
                    var one = ""
                    var two = ""
                    var three = ""
                    var four = ""
                    if let address = result.object(at: 0)as? NSDictionary {
                       // print(address)
                        if let addresscomponents = address.object(forKey: "address_components")as? NSArray{
                            if   let number  = addresscomponents.object(at: 0)as? NSDictionary{
                                zero = string(number, "long_name")
                            }
                            
                            if   let number  = addresscomponents.object(at: 1)as? NSDictionary{
                                one = string(number, "long_name")
                            }
                            if   let number  = addresscomponents.object(at: 2)as? NSDictionary{
                                two = string(number, "long_name")
                            }
                            if   let number  = addresscomponents.object(at: 3)as? NSDictionary{
                                three = string(number, "long_name")
                            }
                            if   let number  = addresscomponents.object(at: 4)as? NSDictionary{
                                four = string(number, "long_name")
                            }
                        }
                    }
                   
                    self.tfAddress.text = String(format: "%@ %@, %@ %@",one,two,three,four)
                }
                
            }
        })
    }
    
    func placePickerDidCancel(_ viewController: GMSPlacePickerViewController) {
        // Dismiss the place picker, as it cannot dismiss itself.
        viewController.dismiss(animated: true, completion: nil)
        
        print("No place selected")
    }
}


class AddressListClass : NSObject {
    var address = ""
    var city_id = ""
    var city_name = ""
    var country_id = ""
    var country_name = ""
    var full_address = ""
    var id = ""
    var is_default = ""
    var latitude = ""
    var longitude = ""
    var state_id = ""
    var state_name = ""
    var status  = ""
    var user_id = ""
    var zipcode  = ""
    
}
