//
//  SelectCountryVC.swift
//  WashittoVendor
//
//  Created by Himanshu on 20/07/18.
//  Copyright © 2018 Himanshu pal. All rights reserved.
//

import UIKit
import HarishFrameworkSwift4
@objc protocol AudioPlayerViewDelegate {
    
    @objc  func select(_ id : String, _ name : String)
}

class SelectCountryVC: UIViewController, UITextFieldDelegate  , UITableViewDelegate, UITableViewDataSource{
    
    
 var delegate: AudioPlayerViewDelegate?
    
    var arrCity =  NSMutableArray()
    var arrfinal = NSMutableArray()
    @IBOutlet var tblCity: UITableView!
    var countryID = ""
    var stateID = ""
    var cityID = ""
    var comefrom = ""
    var comeid = ""
    @IBOutlet var lblTitle: UILabel!
    @IBOutlet var tfSearch: UITextField!
    @IBOutlet weak var lblRecord: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tfSearch.addTarget(self, action: #selector(SearchDidChange(_:)), for: .editingChanged)
         lblRecord.isHidden = true
        print(arrCity)
        if comefrom == "Country"{
            lblTitle.text = "Country"
            self.ws_countries()
        }else if comefrom == "State"{
            lblTitle.text = "State"
           countryID  = comeid
           self.ws_state()
        }else if comefrom == "City"{
            lblTitle.text = "City"
            stateID = comeid
            self.ws_city()
        }
        else if comefrom == "Detergent"{
            print("arrCity\(arrCity)")
            lblTitle.text = "Select Detergent"
            tblCity.reloadData()
            self.arrfinal = self.arrCity
            self.lblRecord.isHidden = true
        }
        else if comefrom == "Softener"{
            lblTitle.text = "Select Softener"
             tblCity.reloadData()
            self.arrfinal = self.arrCity
            self.lblRecord.isHidden = true
        }
        

       
    }

    @objc func SearchDidChange(_ textField: UITextField) {
        arrCity = NSMutableArray()
        if textField.text!.count == 0 {
            arrCity = arrfinal
        }
        
        for i in 0..<arrfinal.count {
            
            if comefrom == "Detergent" ||  comefrom == "Softener" {
                
                let ob = arrfinal[i] as? NSDictionary
                let mname = ob?.object(forKey: "title")as! String
                if mname.lowercased().range(of: textField.text!.lowercased()) != nil {
                    
                    arrCity.add(ob!)
                }
            }else{
                let ob = arrfinal[i] as? NSDictionary
                let mname = ob?.object(forKey: "name")as! String
                if mname.lowercased().range(of: textField.text!.lowercased()) != nil {
                    
                    arrCity.add(ob!)
                }
            }
          
            
        }
        lblRecord.isHidden = true
        if arrCity.count == 0 {
            lblRecord.isHidden = false
        }
        
        tblCity.reloadData()
    }
     func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        tfSearch.resignFirstResponder()
        
        return true
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //MARK:- TABLEVIEW_DELEGATE
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrCity.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cityCell", for: indexPath) as! cityCell
        if comefrom == "Detergent" ||  comefrom == "Softener" {
            let ob = arrCity.object(at: indexPath.row) as! NSDictionary
               let name = string(ob, "title")
            let value = string(ob, "value")
          //  cell.lblcity.text = name + "      $" + value
           
            //Neeleshwari_mehra_____________ august 1
            
            cell.lblcity.text = name
            cell.lblValue.text = "$" + value
            
            cell.lblcity.textColor = appColor
            cell.lblValue.textColor = appColor
            cell.lblValue.isHidden = false
            
        }else{
            cell.lblValue.isHidden = true
            let ob = arrCity.object(at: indexPath.row) as! NSDictionary
            cell.lblcity.text = string(ob, "name")
        }

        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
         let ob = arrCity.object(at: indexPath.row) as! NSDictionary
        if comefrom == "Detergent" ||  comefrom == "Softener" {
         
             self.delegate?.select(string(ob, "key"), string(ob, "title"))
            self.dismiss(animated: true, completion: nil)
        }else{
            
            self.delegate?.select(string(ob, "id"), string(ob, "name"))
            self.dismiss(animated: true, completion: nil)
        }
    }
    
    
    @IBAction func action_select(_ sender : AnyObject) {
       
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func action_Remove(_ sender : AnyObject) {
        self.dismiss(animated: true, completion: nil)
    }
    
   
    
    
    //>>>>>>>>>>>>>>>>>>>>>>>> PICERVIEW >>>>>>>>>>>>>>>>>>>>>>>>>>>//
    func ws_countries() {
        Http.instance().json(WebServices.countries, nil, "GET", ai: true, popup: true, prnt: true, sync: false) { (json, dict, str) in
            
            if json != nil {
                let json1 = json as? NSDictionary
                if number(json1! , "success").boolValue {
                     self.arrCity = NSMutableArray()
                    if let result = json1?.object(forKey: "result") as? NSArray {
                        self.arrCity = result.mutableCopy() as! NSMutableArray
                        
                        self.tblCity.reloadData()
                        self.arrfinal = self.arrCity
                        self.lblRecord.isHidden = true
                        
                        
                    }
                } else {
                    let msg = string(json1!, "message")
                    let alert = UIAlertController(title: "", message: msg, preferredStyle: UIAlertControllerStyle.alert)
                    alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                }
            }
        }
    }
    
    func ws_state() {
        let params = NSMutableDictionary()
        params["country_id"] = countryID
        
        Http.instance().json(WebServices.states, params, "GET", ai: true, popup: true, prnt: true, sync: false) { (json, dict, str) in
            
            if json != nil {
                let json1 = json as? NSDictionary
                if number(json1! , "success").boolValue {
                    self.arrCity = NSMutableArray()
                    if let result = json1?.object(forKey: "result") as? NSArray {
                        self.arrCity = result.mutableCopy() as! NSMutableArray
                        
                        self.tblCity.reloadData()
                        self.arrfinal = self.arrCity
                        self.lblRecord.isHidden = true
                        
                        
                    }
                } else {
                    let msg = string(json1!, "msg")
                    let alert = UIAlertController(title: "", message: msg, preferredStyle: UIAlertControllerStyle.alert)
                    alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                }
            }
        }
    }
    
    func ws_city() {
        let params = NSMutableDictionary()
        params["state_id"] = stateID
        
        Http.instance().json(WebServices.cities, params, "GET", ai: true, popup: true, prnt: true, sync: false) { (json, dict, str) in
            
            if json != nil {
                let json1 = json as? NSDictionary
                if number(json1! , "success").boolValue {
                    self.arrCity = NSMutableArray()
                    if let result = json1?.object(forKey: "result") as? NSArray {
                        self.arrCity = result.mutableCopy() as! NSMutableArray
                        
                        self.tblCity.reloadData()
                        self.arrfinal = self.arrCity
                        self.lblRecord.isHidden = true
                        
                        
                    }
                } else {
                    let msg = string(json1!, "msg")
                    let alert = UIAlertController(title: "", message: msg, preferredStyle: UIAlertControllerStyle.alert)
                    alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                }
            }
        }
    }
    
    
    

}
class cityCell: UITableViewCell {
    
    @IBOutlet var lblcity: UILabel!
    @IBOutlet var lblValue: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
    }
   
}

