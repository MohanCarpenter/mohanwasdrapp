//
//  EditProfileVC.swift
//  Washitto
//
//  Created by Himanshu on 26/06/18.
//  Copyright © 2018 Himanshu. All rights reserved.
//

import UIKit
import HarishFrameworkSwift4
class EditProfileVC: UIViewController , UITextFieldDelegate,UIImagePickerControllerDelegate, UINavigationControllerDelegate, UIPopoverControllerDelegate {

    @IBOutlet var lblEmail: UILabel!
    @IBOutlet var ScrlView: UIScrollView!
    @IBOutlet var tfFirstName: TextField!
    @IBOutlet var lblMobileMo: UILabel!
    
    @IBOutlet var imgUser: UIImageView!
    @IBOutlet var tflastName: TextField!
    var imgProfilePicture:UIImage? = nil
    override func viewDidLoad() {
        super.viewDidLoad()
        self.registerForKeyboardNotifications()
        // Do any additional setup after loading the view.
         self.setImageNavigation()
        
        if let userdetail:NSDictionary = userInfo.getLoginInfo()  {
            print("userdetail ======>",userdetail)
            if let firstname = userdetail.object(forKey: "first_name") as? String {
                tfFirstName.text = firstname
                tflastName.text = (userdetail.object(forKey: "last_name") as? String)
                lblMobileMo.text = string(userdetail, "phone_number")
                lblEmail.text = string(userdetail, "email")
            }
            if let path = userdetail.object(forKey: "profile_image") as? String {
                let imgurl = APPConstants.upload_url + path
                let URL =  NSURL(string: imgurl)
                self.imgUser.sd_setImage(with: URL as URL!, placeholderImage: UIImage(named: "noimage.png"),  options: SDWebImageOptions.retryFailed)
            }else{
                self.imgUser.image = UIImage(named : "noimage.png")
            }
        }
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
      
    }
    override func viewWillDisappear(_ animated: Bool) {
        self.title = ""
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //*************************************************
    //MARK:- KEYBOARD NOTIFICATION METHODS
    func registerForKeyboardNotifications() {
        let notificationCenter = NotificationCenter.default
        notificationCenter.addObserver(self, selector: #selector(adjustForKeyboard), name: Notification.Name.UIKeyboardWillHide, object: nil)
        notificationCenter.addObserver(self, selector: #selector(adjustForKeyboard), name: Notification.Name.UIKeyboardWillChangeFrame, object: nil)
    }
    
    func deregisterFromKeyboardNotifications() {
        NotificationCenter.default.removeObserver(self, name: .UIKeyboardWillShow, object: nil)
        NotificationCenter.default.removeObserver(self, name: .UIKeyboardWillHide, object: nil)
    }
    
    @objc func adjustForKeyboard(notification: Notification) {
        let userInfo = notification.userInfo!
        
        let keyboardScreenEndFrame = (userInfo[UIKeyboardFrameEndUserInfoKey] as! NSValue).cgRectValue
        let keyboardViewEndFrame = view.convert(keyboardScreenEndFrame, from: view.window)
        
        if notification.name == Notification.Name.UIKeyboardWillHide {
            ScrlView.contentInset = UIEdgeInsets.zero
        } else {
            ScrlView.contentInset = UIEdgeInsets(top: 0, left: 0, bottom: keyboardViewEndFrame.height + 10, right: 0)
        }
        
        ScrlView.scrollIndicatorInsets = ScrlView.contentInset
    }
  
    @IBAction func actionUploadProfile(_ sender: Any) {
        self.view.endEditing(true)
        let actionSheet = UIAlertController(title: nil, message: nil, preferredStyle: UIAlertControllerStyle.actionSheet)
        
        let camera = "Camera"
        let gallery = "Gallery"
        let cancel = "Cancel"
        
        
        actionSheet.addAction(UIAlertAction(title: camera, style: UIAlertActionStyle.default, handler: { (alert:UIAlertAction!) -> Void in
            self.camera()
        }))
        
        actionSheet.addAction(UIAlertAction(title: gallery, style: UIAlertActionStyle.default, handler: { (alert:UIAlertAction!) -> Void in
            self.photoLibrary()
        }))
        
        actionSheet.addAction(UIAlertAction(title: cancel, style: UIAlertActionStyle.cancel, handler: nil))
        
        if UIDevice.current.userInterfaceIdiom == .pad {
            if let popoverController = actionSheet.popoverPresentationController {
                popoverController.sourceView = sender as? UIView
                popoverController.sourceRect = (sender as AnyObject).bounds
            }
        }
        self.present(actionSheet, animated: true, completion: nil)
    }
    
    
    
    
    func camera() {
        if UIImagePickerController.isSourceTypeAvailable(UIImagePickerControllerSourceType.camera) {
            let imagePicker = UIImagePickerController()
            imagePicker.delegate = self
            imagePicker.sourceType = UIImagePickerControllerSourceType.camera;
            imagePicker.allowsEditing = true
            self.present(imagePicker, animated: true, completion: nil)
        }
    }
    
    
    func photoLibrary() {
        if UIImagePickerController.isSourceTypeAvailable(UIImagePickerControllerSourceType.photoLibrary) {
            let imagePicker = UIImagePickerController()
            imagePicker.delegate = self
            imagePicker.sourceType = UIImagePickerControllerSourceType.photoLibrary;
            imagePicker.allowsEditing = true
            self.present(imagePicker, animated: true, completion: nil)
        }
    }
    
    
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        var img:UIImage? = info[UIImagePickerControllerOriginalImage] as? UIImage
        if let iii = info[UIImagePickerControllerEditedImage] as? UIImage {
            img = iii
        }
        if (img != nil) {
            imgProfilePicture = img
            imgUser.image = img
            
        }
        picker.dismiss(animated: true, completion: nil);
    }
    
    
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController){
        picker.dismiss(animated: true, completion: nil)
    }
    
    //MARK: TEXTFIELD DELEGATE
    func textFieldDidBeginEditing(_ textField: UITextField) {
    
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
     
        textField.resignFirstResponder()
        ScrlView.setContentOffset(CGPoint(x: 0, y: 0) , animated: true)
        return true
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        let length = (textField.text?.count)! + string.count - range.length
       if tfFirstName == textField {
            let validCharacterSet = NSCharacterSet(charactersIn: APPConstants.NameAcceptableCharacter).inverted
            let filter = string.components(separatedBy: validCharacterSet)
            if filter.count == 1 {
                
                return (length > 50) ? false : true
            } else {
                return false
            }
        }
        else if tflastName == textField {
            let validCharacterSet = NSCharacterSet(charactersIn: APPConstants.NameAcceptableCharacter).inverted
            let filter = string.components(separatedBy: validCharacterSet)
            if filter.count == 1 {
                
                return (length > 50) ? false : true
            } else {
                return false
            }
        }
        
        return true
    }
    

    
    
    func ws_EditProfile() {
        let params = NSMutableDictionary()
        params["first_name"]  = tfFirstName.text!
        params["last_name"]  = tflastName.text!
        
        let images = NSMutableArray()
        if imgProfilePicture != nil {
            let md = NSMutableDictionary()
            md["param"] = "profile_image"
            md["image"] = imgProfilePicture!
            images.add(md)
        }
        
    
       Http.instance().json(WebServices.editprofile, params, "POST", ai: true, popup: true, prnt: true, userInfo.Token(), images, sync: false) { (json, params, strJson) in
            
            
            if json != nil {
                
                let json = json as? NSDictionary
                if number(json! , "success").boolValue {
                    
                    Http.alert("", string(json! , "message"))
                    self.navigationController?.popViewController(animated: true)
                    
                }
                
            }else {
                Http.alert("", string(json as! NSDictionary , "message"))
                
            }
        }
    }
    

    
    func checkValidation() -> String? {
        if tfFirstName.text?.count == 0  {
            return "Please enter first name."
        }
        else if tflastName.text!.count == 0  {
            return "Please select region."
        }
        
        
        return nil
    }
    
    @IBAction func actionUpdateProfile(_ sender: Any) {
        self.view.endEditing(true)
        ScrlView.setContentOffset(CGPoint(x: 0, y: 0), animated: true)
        if let str = checkValidation() {
            Http.alert("", str)
        } else {
            self.ws_EditProfile()
        }
    }
    
    @IBAction func actionMobile(_ sender: Any) {
        kappDelegate.comefrom = "editprofile"
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ChangeNumberVC") as! ChangeNumberVC
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func actionEmail(_ sender: Any) {
        kappDelegate.comefrom = "addemail"
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "AddEmailVC") as! AddEmailVC
        self.navigationController?.pushViewController(vc, animated: true)
    }
}
