//
//  ProfileVC.swift
//  Washitto
//
//  Created by Himanshu on 13/06/18.
//  Copyright © 2018 Himanshu. All rights reserved.
//

import UIKit
import HarishFrameworkSwift4
class ProfileVC: UIViewController {

    @IBOutlet var imgUser: UIImageView!
    
    @IBOutlet var lblName: UILabel!
    @IBOutlet var lblMobileNo: UILabel!
    @IBOutlet var lblPlanName: UILabel!
    @IBOutlet var lblRewardPoints: UILabel!
    @IBOutlet var lblEmail: UILabel!

    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.isNavigationBarHidden = false
        navigationItem.hidesBackButton = false
        navigationController?.navigationBar.shouldRemoveShadow(true)
        self.setImageNavigation()
        if  kappDelegate.is_socket_login {
            kappDelegate.curLocation()
        }

    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        // get detail from api
        
        GetUserDetail.myDetailHp(completionHandler: {_ in
            
            if let userdetail:NSDictionary = userInfo.getLoginInfo()  {
//                print("userdetail ======>",userdetail)
                if let dictPlanName = userdetail.object(forKey: "plan") as? NSDictionary {
                    
                    self.lblPlanName.text = string(dictPlanName, "title")
//                    self.plan_name = string(dictPlanName, "title")
//                    print("plan_name ======>",self.plan_name)
                    
//                    if self.plan_name.count == 0{
//                        self.lblPlanName.text = "Select Plan"
//                    }
                }else{
                    self.lblPlanName.text = "Select Plan"
                }
                if let firstname = userdetail.object(forKey: "first_name") as? String {
                    let lastname = userdetail.object(forKey: "last_name") as! String
                    self.lblName.text = firstname + " " + lastname
                }
                
                if let path = userdetail.object(forKey: "profile_image") as? String {
                    let imgurl = APPConstants.upload_url + path
                    let URL =  NSURL(string: imgurl)
                    self.imgUser.sd_setImage(with: URL as URL!, placeholderImage: UIImage(named: "noimage.png"),  options: SDWebImageOptions.retryFailed)
                }else{
                    self.imgUser.image = UIImage(named : "noimage.png")
                }
                let aaa = string(userdetail, "phone_number")
                
                let fullString = NSMutableAttributedString(string: "")
                let image1Attachment = NSTextAttachment()
                image1Attachment.image = UIImage.imageWithImage(image: UIImage(named: "phone_icon.png")!, scaledToSize: CGSize(width: 10.0, height: 10.0))
                
                let image1String = NSAttributedString(attachment: image1Attachment)
                fullString.append(image1String)
                fullString.append(NSAttributedString(string: " " + aaa))
                self.lblMobileNo.text = aaa //  .attributedText = fullString
                self.lblEmail.text = string(userdetail, "email")
            }
            
        })
      
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        self.title = ""
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    @IBAction func actionRightnav(_ sender: Any) {
        self.sideMenuViewController.presentRightMenuViewController()

    }
    
    @IBAction func actionChangePassword(_ sender: Any) {
         let vc = self.storyboard?.instantiateViewController(withIdentifier: "ChangePasswordVC") as! ChangePasswordVC
              self.navigationController?.pushViewController(vc, animated: true)
    }
    @IBAction func actionMemberPlan(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "MembershipPlansVC") as! MembershipPlansVC
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func actionAddressList(_ sender: Any) {
        
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "AddAddressVC") as! AddAddressVC
        vc.edit = "yes"
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func actionRewardpoint(_ sender: Any) {
        //
        //        let vc = self.storyboard?.instantiateViewController(withIdentifier: "SelectAddressVC") as! SelectAddressVC
        //        self.navigationController?.pushViewController(vc, animated: true)
    }
    @IBAction func actionEdit(_ sender: Any) {
                let vc = self.storyboard?.instantiateViewController(withIdentifier: "EditProfileVC") as! EditProfileVC
                self.navigationController?.pushViewController(vc, animated: true)
    }
    
    
    

}
