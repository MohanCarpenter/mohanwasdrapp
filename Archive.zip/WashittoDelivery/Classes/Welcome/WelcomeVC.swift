//
//  WelcomeVC.swift
//  Washitto
//
//  Created by Himanshu on 12/06/18.
//  Copyright © 2018 Himanshu. All rights reserved.
//

import UIKit
import HarishFrameworkSwift4
class WelcomeVC: UIViewController {
 @IBOutlet var imglogo: UIImageView!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.isNavigationBarHidden = true
      //  self.imglogo.transform = CGAffineTransform(scaleX: 0.6, y: 0.6)

      /*  UIView.animate(withDuration: 2.0,
                       delay: 0,
                       usingSpringWithDamping: CGFloat(0.20),
                       initialSpringVelocity: CGFloat(6.0),
                       options: UIViewAnimationOptions.allowUserInteraction,
                       animations: {
                        self.imglogo.transform = CGAffineTransform.identity
        },
                       completion: { Void in()
                        
        }
        )*/
    }
    
    override func viewWillAppear(_ animated: Bool) {
        let userIDPass = getEmailPass()
        if (userIDPass.0 != nil) && (userIDPass.1 != nil) && is_user_login(){
            ws_Signin(userIDPass.0!, userIDPass.1!)
        }else {
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "SigninVC") as! SigninVC
            self.navigationController?.pushViewController(vc, animated: true)
        }
      
      
    }
   
    override func viewWillDisappear(_ animated: Bool) {
        self.title = ""
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    func ws_Signin( _ email :String , _ pass :String ) {
        let uDef = UserDefaults.standard
      

        let params = NSMutableDictionary()
        params["username"] = email
        params["password"] = pass
        params["role"] =  "delivery"
        params["device_name"] = UIDevice.current.modelName
        params["imei"] =    APPConstants.getDeviceId()
        params["apns_id"] =   kappDelegate.apns
        params["device_type"] = APPConstants.deviceType
        params["modal_no"] = UIDevice.current.model
        params["os_version"] =  UIDevice.current.systemVersion
        params["social_type"] = "email"
        
        let defaults = UserDefaults.standard
        if  let notificationid = defaults.object(forKey: "firebasetoken") {
            params["notification_id"] =   ("\(notificationid)")
        }else{
            params["notification_id"] = "123"
        }
        
        // UIDevice.current.deviceInfo(params)
        
        print("params-------", params)
        Http.instance().json(WebServices.login, params, "POST", ai: true, popup: true, prnt: true, sync: false) { (json, dict, str) in
            
            if let json1 = json as? NSDictionary {
                
                if number(json1 , "success").boolValue {
                    if let result = json1["result"] as? NSDictionary {
                        //   Http.alert("", string(json1! , "message"))
                        
                        if let user = json1.object(forKey: "result") as? NSDictionary {
                            if let delivery_address = user.object(forKey: "delivery_address") as? NSDictionary {
                                if let country_id = delivery_address.object(forKey: "country_id") as? Int {
                                    uDef.set(country_id, forKey: "country_id")
                                }
                                
                            }
                            
                            userInfo.saveLoginInfo(user)
                        }
                        
                        
                        if let token = result.object(forKey: "token") as? String {
                            userInfo.savetoken(token)
                        }
                        
                        if let user_key = result.object(forKey: "user_key") as? String {
                            uDef.set(user_key, forKey: "user_key")

                            SOCKETIOCLIENTMANAGER.sharedInstance.loginConnection()

                        }
                        uDef.synchronize()

                        
                        guard let completed_steps = result.object(forKey: "completed_steps") as? Int else {
                            let vc = self.storyboard?.instantiateViewController(withIdentifier: "SigninVC") as! SigninVC
                            self.navigationController?.pushViewController(vc, animated: true)

                            return
                        }
                        
                        kappDelegate.completed_steps = completed_steps
                        
                        if completed_steps == 1 {
                            let vc = self.storyboard?.instantiateViewController(withIdentifier: "AgreementView") as! AgreementView
                            self.navigationController?.pushViewController(vc, animated: true)
                        }else if completed_steps == 2 {
                            let vc = self.storyboard?.instantiateViewController(withIdentifier: "UserInformationView") as! UserInformationView
                            self.navigationController?.pushViewController(vc, animated: true)
                            
                        }else if completed_steps == 3 {
                            let vc = self.storyboard?.instantiateViewController(withIdentifier: "VerifyNumberVC") as! VerifyNumberVC
                            vc.mobileNumber = string(result, "phone_number")
                            self.navigationController?.pushViewController(vc, animated: true)
                            
                        }else if completed_steps == 4 {
                            let vc = self.storyboard?.instantiateViewController(withIdentifier: "AddAddressSignupVC") as! AddAddressSignupVC
                            self.navigationController?.pushViewController(vc, animated: true)
                            
                        }else if completed_steps == 5 {
                            let vc = self.storyboard?.instantiateViewController(withIdentifier: "AddMarketView") as! AddMarketView
                            self.navigationController?.pushViewController(vc, animated: true)
                            
                        }else if completed_steps == 6 {
                            
                            let vc = self.storyboard?.instantiateViewController(withIdentifier: "AddVehicleView") as! AddVehicleView
                            self.navigationController?.pushViewController(vc, animated: true)
                            
                        }else if completed_steps == 7 {
                            if Int(string(result, "license_screen")) == 1 {
                                let vc = self.storyboard?.instantiateViewController(withIdentifier: "AddLicenseinforView") as! AddLicenseinforView
                                self.navigationController?.pushViewController(vc, animated: true)
                                
                            }else {
                                
                                let vc = self.storyboard?.instantiateViewController(withIdentifier: "AgreementFCRAView") as! AgreementFCRAView
                                self.navigationController?.pushViewController(vc, animated: true)
                            }
                        }else if completed_steps == 8 {
                            
                            let vc = self.storyboard?.instantiateViewController(withIdentifier: "AgreementStateView") as! AgreementStateView
                            self.navigationController?.pushViewController(vc, animated: true)
                            
                        }else if completed_steps == 9 {
                            
                            let vc = self.storyboard?.instantiateViewController(withIdentifier: "SocialSecuirtyVC") as! SocialSecuirtyVC
                            self.navigationController?.pushViewController(vc, animated: true)
                        }else if completed_steps == 10 {
                            let vc = self.storyboard?.instantiateViewController(withIdentifier: "AddSelfeView") as! AddSelfeView
                            self.navigationController?.pushViewController(vc, animated: true)
                        }else  {
                            self.navigationController?.viewControllers = []
                            let vc = self.storyboard?.instantiateViewController(withIdentifier: "RootViewCustomer") as! RootViewCustomer
                            kappDelegate.window?.rootViewController = vc
                        }
                      
                    }else {
                        let vc = self.storyboard?.instantiateViewController(withIdentifier: "SigninVC") as! SigninVC
                        self.navigationController?.pushViewController(vc, animated: true)

                    }
                }else {
                    let vc = self.storyboard?.instantiateViewController(withIdentifier: "SigninVC") as! SigninVC
                    self.navigationController?.pushViewController(vc, animated: true)

                }
                
            }else {
                let vc = self.storyboard?.instantiateViewController(withIdentifier: "SigninVC") as! SigninVC
                self.navigationController?.pushViewController(vc, animated: true)
                
            }
        }
        
        
    }
    
    
    

}
func is_user_login()-> Bool {
    let uDef = UserDefaults.standard
    if uDef.object(forKey: "is_login") as? Bool   == true   {
        return true
    }
    return false
}
func getEmailPass() -> (String?,String?, Bool?){
    let uDef = UserDefaults.standard
    
    var is_remamber = false
    if uDef.object(forKey: "is_remamber") as? Bool   == true   {
        is_remamber = true
        
    }
        
    guard let email  = uDef.value(forKey: "email") as? String else {
        return (nil,nil,nil)
        
    }
    guard let pass  = uDef.value(forKey: "pass") as? String  else {
        return (nil,nil,nil)
        
    }
    
    return (email,pass,is_remamber)
    
    
//    return (nil,nil,nil)
    
}
