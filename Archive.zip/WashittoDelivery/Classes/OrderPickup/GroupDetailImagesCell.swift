//
//  GroupDetailImagesCell.swift
//  Stupitt
//
//  Created by Rahul on 28/03/18.
//  Copyright © 2018 mac. All rights reserved.
//

import UIKit
public protocol  GroupDetailImagesCellDelegate {
    func cellRemoveImages(_ indexPath:IndexPath)
}

class GroupDetailImagesCell: UICollectionViewCell {
    var delegate : GroupDetailImagesCellDelegate?
   var indexPath: IndexPath?
    @IBOutlet var imgPost: UIImageView!
    @IBOutlet var btnCrose: UIButton!


    
    @IBAction func actionRemoveImage(_ sender: Any) {
        delegate?.cellRemoveImages(indexPath!)
    }
}
