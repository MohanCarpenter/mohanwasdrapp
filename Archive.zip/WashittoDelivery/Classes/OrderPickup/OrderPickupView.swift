//
//  OrderPickupView.swift
//  WashittoDelivery
//
//  Created by Rahul on 01/08/18.
//  Copyright © 2018 Himanshu pal. All rights reserved.
//

import UIKit
import HarishFrameworkSwift4

class OrderPickupView: UIViewController , UIImagePickerControllerDelegate, UINavigationControllerDelegate, UIPopoverControllerDelegate , UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout , GroupDetailImagesCellDelegate{
  var request_type  = ""
    @IBOutlet var collectionInagesView: UICollectionView!
    let demo = UIImage(named: "Camera.png")
    var images: [UIImage] = []
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.isNavigationBarHidden = false
        navigationItem.hidesBackButton = false
        navigationController?.navigationBar.shouldRemoveShadow(true)
        self.setImageNavigation()
        
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()
        images.append(demo!)

        collectionInagesView.layer.cornerRadius = 10
        collectionInagesView.clipsToBounds = true
        
        collectionInagesView.delegate = self
        collectionInagesView.dataSource = self
        var Width = collectionInagesView.frame.size.width / 2.0 - 8.0
      
        if UIDevice.current.userInterfaceIdiom == .pad {
            Width = collectionInagesView.frame.size.width / 4.0 - 8.0
        }
        
        let cellWidth : CGFloat = Width
        let cellheight : CGFloat = cellWidth//myCollectionView.frame.size.width / 4.0 //- 2.0
        
        
        let cellSize = CGSize(width: cellWidth , height:cellheight)
        
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .vertical //.horizontal
        layout.itemSize = cellSize
        layout.sectionInset = UIEdgeInsets(top: 1, left: 1, bottom: 1, right: 1)
        layout.minimumLineSpacing = 1.0
        layout.minimumInteritemSpacing = 1.0
        collectionInagesView.setCollectionViewLayout(layout, animated: true)

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //MARK:- UICollectionView
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        return self.images.count
    }
    
    // make a cell for each cell index path
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        // get a reference to our storyboard cell
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "GroupDetailImagesCell", for: indexPath as IndexPath) as! GroupDetailImagesCell
        cell.btnCrose.layer.cornerRadius = 12
        if let dict:UIImage = self.images[indexPath.item] as? UIImage {
            if demo == dict {
                cell.btnCrose.isHidden = true
            }else {
                cell.btnCrose.isHidden = false
            }
            cell.imgPost.image = dict
        }
        cell.delegate = self
        cell.indexPath = indexPath
        cell.imgPost.layer.cornerRadius = 10
        cell.imgPost.clipsToBounds = true
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if let dict:UIImage = self.images[indexPath.item] as? UIImage {
            if demo == dict {
                actionPostVideo(collectionView)
            }
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        var Width = collectionInagesView.frame.size.width / 2.0 - 8.0
        
        if UIDevice.current.userInterfaceIdiom == .pad {
            Width = collectionInagesView.frame.size.width / 4.0 - 8.0
        }
        return CGSize(width: Width, height: Width)
    }

    
    func cellRemoveImages(_ indexPath:IndexPath) {
        self.images.remove(at: indexPath.row)
        if images.count < 5 {
            images.append(demo!)
        }
        collectionInagesView.reloadData()
    }

     func actionPostVideo(_ sender: Any) {
        
        let actionSheet = UIAlertController(title: nil, message: nil, preferredStyle: UIAlertControllerStyle.actionSheet)
        
        let camera = "Camera"
        let gallery = "Gallery"
        let cancel = "Cancel"
        
        
        actionSheet.addAction(UIAlertAction(title: camera, style: UIAlertActionStyle.default, handler: { (alert:UIAlertAction!) -> Void in
            self.camera()
        }))
        
        actionSheet.addAction(UIAlertAction(title: gallery, style: UIAlertActionStyle.default, handler: { (alert:UIAlertAction!) -> Void in
            self.photoLibrary()
        }))
        
        actionSheet.addAction(UIAlertAction(title: cancel, style: UIAlertActionStyle.cancel, handler: nil))
        if UIDevice.current.userInterfaceIdiom == .pad {
            if let popoverController = actionSheet.popoverPresentationController {
                popoverController.permittedArrowDirections = .init(rawValue: 0)

                popoverController.sourceView = self.view

                popoverController.sourceRect = CGRect(x: self.view.bounds.midX, y: self.view.bounds.midY, width: 0, height: 0) 
                popoverController.backgroundColor = UIColor.white

                    //self.view.bounds//(sender as AnyObject).bounds
            }
        }
        self.present(actionSheet, animated: true, completion: nil)
    }
    @IBAction func actionPost(_ sender: Any) {
//        if images.count > 4 {
//            images.remove(at: images.count-1)
//        }
        
       
      
        
        ws_OrderPicked()
    }
    
    //MARK:- Camera
    func camera() {
        if UIImagePickerController.isSourceTypeAvailable(UIImagePickerControllerSourceType.camera) {
            let imagePicker = UIImagePickerController()
            imagePicker.delegate = self
            imagePicker.sourceType = UIImagePickerControllerSourceType.camera;
            imagePicker.allowsEditing = true
            self.present(imagePicker, animated: true, completion: nil)
        }
    }
    
    
    func photoLibrary() {
        if UIImagePickerController.isSourceTypeAvailable(UIImagePickerControllerSourceType.photoLibrary) {
            let imagePicker = UIImagePickerController()
            imagePicker.delegate = self
            imagePicker.sourceType = UIImagePickerControllerSourceType.photoLibrary;
            imagePicker.allowsEditing = true
            self.present(imagePicker, animated: true, completion: nil)
        }
    }
    
    var typeOfPost = "text"
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        var img:UIImage? = info[UIImagePickerControllerOriginalImage] as? UIImage
        if let iii = info[UIImagePickerControllerEditedImage] as? UIImage {
            img = iii
        }
        
        if (img != nil) {
            
            if let iii = info[UIImagePickerControllerEditedImage] as? UIImage {
                img = iii
                if let data = UIImageJPEGRepresentation(img!, 0.3) {
                    print(data.count)
                    
                    img =  UIImage(data: data)
                }
            }
            
            images.remove(at: images.count-1)
            images.append(img!)
            if images.count < 5 {
                images.append(demo!)
            }
            
        }
        picker.dismiss(animated: true, completion: nil);
        collectionInagesView.reloadData()
        typeOfPost = "image"
        
    }
    
    
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController){
        picker.dismiss(animated: true, completion: nil)
    }
    var orderid = ""
    var request_id = ""
    
    func ws_OrderPicked(){
        let params = NSMutableDictionary()
        params["request_id"] = request_id
        params["request_type"] = request_type
        params["order_id"] = orderid
        let images11 = NSMutableArray()
        
        
        for i in 0..<(images.count) {
            
            if images[i] != demo! {
                if i == 0 {
                    
                    let md = NSMutableDictionary()
                    md["param"] = "photo_1"
                    md["image"] = images[i]
                    images11.add(md)
                    
                }else if i == 1 {
                    let md = NSMutableDictionary()
                    md["param"] = "photo_2"
                    md["image"] = images[i]
                    images11.add(md)
                    
                }else if i == 2 {
                    let md = NSMutableDictionary()
                    md["param"] = "photo_3"
                    md["image"] = images[i]
                    images11.add(md)
                    
                }else if i == 3 {
                    let md = NSMutableDictionary()
                    md["param"] = "photo_4"
                    md["image"] = images[i]
                    images11.add(md)
                    
                }else if i == 4 {
                    let md = NSMutableDictionary()
                    md["param"] = "photo_5"
                    md["image"] = images[i]
                    images11.add(md)
                    
                }
            } // .append(demo!)
         
            
        }
       
        
        
        Http.instance().json(WebServices.orders_picked, params, "POST", ai: true, popup: true, prnt: true, userInfo.Token(), images11, sync: false) { (json, dict, str) in
            
            if json != nil {
                let json1 = json as? NSDictionary
                if number(json1! , "success").boolValue {
                    Http.alert("", string(json1! , "message"))
                    self.sideMenuViewController.setContentViewController(self.storyboard?.instantiateViewController(withIdentifier: "order_nav"), animated: true)

//                    self.navigationController?.popViewController(animated: true)
                }else {
                    //                    self.navigationController?.popViewController(animated: true)
                    Http.alert("", string(json1! , "message"))
                }
            }
        }
    }
    func ws_createPost(){
       
        self.view.endEditing(true)
        let reach = Reachability.init(hostname: "google.com")
        
        if (reach?.isReachable)! {
            Http.instance().startActivityIndicator()
            let param = NSMutableDictionary(dictionary: ["title":"", "description":"", "type":"image", "group_id":"group_id"])
            let request = NSMutableURLRequest(url: NSURL(string: ("WebServices.api_Post" .addingPercentEncoding( withAllowedCharacters: .urlQueryAllowed)!))! as URL)
            
            let config = URLSessionConfiguration.default
            config.timeoutIntervalForRequest = 180.0
            config.timeoutIntervalForResource = 180.0
            config.requestCachePolicy = .reloadIgnoringLocalAndRemoteCacheData
            let session = URLSession(configuration: config)
            request.httpMethod = "POST"
            var data:Data! = Data()
            do {
                let boundary = generateBoundaryString()
                request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
                
                
                for (key, value) in param {
                    data.append("Content-Disposition: form-data; name=\"\(key)\"\r\n\r\n".data(using: String.Encoding.ascii)!)
                    data.append("\(value)".data(using: String.Encoding.utf8)!)
                    data.append("\r\n--\(boundary)\r\n".data(using: String.Encoding.utf8)!)
                }
                
                if images != nil {
                    for i in 0..<(images.count) {
                        
                        //                        let md = images?[i] as! NSMutableDictionary
                        
                        //                        let param = md["param"] as! String
                        let image = images[i] // md["image"] as! UIImage
                        
                        //let image_data = UIImagePNGRepresentation(image)
                        let image_data = UIImageJPEGRepresentation(image, 0.5)
                        //   print("image-\(param)-\(image)-\(String(describing: image_data?.count))-")
                        
                        let fname = "test\(i).png"
                        let iiiii = "files[]"
                        data.append("--\(boundary)\r\n".data(using: String.Encoding.utf8)!)
                        data.append("Content-Disposition: form-data; name=\"\(iiiii)\"; filename=\"\(fname)\"\r\n".data(using: String.Encoding.utf8)!)
                        
                        data.append("--\(boundary)\r\n".data(using: String.Encoding.utf8)!)
                        data.append("Content-Type: application/octet-stream\r\n\r\n".data(using: String.Encoding.utf8)!)
                        
                        data.append(image_data!)
                        data.append("\r\n".data(using: String.Encoding.utf8)!)
                        
                        data.append("--\(boundary)--\r\n".data(using: String.Encoding.utf8)!)
                    }
                }
                
                request.httpBody = data
                
                
                
            }catch {
                
                print("JSON serialization failed:  \(error)")
            }
            
            if let user:NSDictionary = NSDictionary() {
                
                if let access_token:String = user.object(forKey: "access_token") as? String {
                    if let token_type:String = user.object(forKey: "token_type") as? String {
                        
                        request.addValue(token_type  + " " +  access_token, forHTTPHeaderField: "Authorization")
                    }
                }
            }
            request.addValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
            request.addValue("application/json", forHTTPHeaderField: "Accept")
            request.addValue("\(data.count)", forHTTPHeaderField: "Content-Length")
            
            
            let task = session.dataTask(with: request as URLRequest, completionHandler: {(data, response, error) in
                Http.instance().stopActivityIndicator()
                if error != nil {
                    print("error=\(error!)")
                    Http.alert("", APPConstants.kCouldnotconnect)
                    return
                }
                print("******* response = \(response)")
                let responseString = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
                print("routes.php ****** response data = \(responseString!)",data!.count)
                do {
                    //       let json:Any? = try JSONSerialization.jsonObject(with: data!, options: .allowFragments) as? Any
                    if let userObject: NSDictionary = (try? JSONSerialization.jsonObject(with: data!, options: []) as! NSDictionary) {
                        print("jsonObject = \(userObject)")
                        DispatchQueue.main.async {
                            print("Hello")
//                            if self.comefrom == "createpost"{
//                                let vc = self.storyboard?.instantiateViewController(withIdentifier: "HomeViewController") as! HomeViewController
//                                self.navigationController?.pushViewController(vc, animated: true)
//                            }else{
//                                self.navigationController?.popViewController(animated: true)
//                            }
                            
                        }
                        
                        // Http.alert("", string(userObject , "message"))
                    }
                    
                } catch {
                    print("error---",error)
                    
                }
            })
            task.resume()
        }else {
            Http.alert("Network message!", APPConstants.kInternetNotAvailable)
        }
        
     
    }
}
