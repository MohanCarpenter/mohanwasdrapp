//
//  MHNService.swift
//  WashittoDelivery
//
//  Created by Rahul on 13/08/18.
//  Copyright © 2018 Himanshu pal. All rights reserved.
//

import UIKit

class MHNService  : NSObject{
    static let sharedInstance: MHNService = {
        let instance = MHNService()
        return instance
    }()

    
    func httpMethodDelete() {
        let ss = "https://"
        let url = URL(string: ss)!

        var request = URLRequest(url: url)
        request.httpMethod = "DELETE"
        let token  = ""  // send in header
        request.addValue(token, forHTTPHeaderField: "Authorization")
        request.addValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
        request.addValue("application/json", forHTTPHeaderField: "Accept")
        
 /*       if let user:NSDictionary = userInfo.getsavetoken() {
            if let access_token:String = user.object(forKey: "access_token") as? String {
                if let token_type:String = user.object(forKey: "token_type") as? String {
                    request.addValue(token_type  + " " +  access_token, forHTTPHeaderField: "Authorization")
                    request.addValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
                    request.addValue("application/json", forHTTPHeaderField: "Accept")
                    //                    NSMutableDictionary(dictionary: ["Authorization": token_type  + " " +  access_token,"Content-Type":"application/x-www-form-urlencoded"])
                }
            }
        }*/
        
        let postData = "".data(using: .utf8)
        //"user_id=\(userInfo.userid())".data(using: .utf8) //  "&profile=image"
        request.httpBody = postData
        let task = URLSession.shared.dataTask(with: request as URLRequest) { data, response, error in
            if error != nil {
                print("error=\(error!)")
                return
            }
            if data == nil {
                return
            }
            do {
                let jsonData = try JSONSerialization.data(withJSONObject: data!, options: .prettyPrinted)
                // here "jsonData" is the dictionary encoded in JSON data
                
                let decoded = try JSONSerialization.jsonObject(with: jsonData, options: [])
                // here "decoded" is of type `Any`, decoded from JSON data
                
                // you can now cast it with the right type
                if let dictFromJSON = decoded as? NSDictionary{
                    // use dictFromJSON
                     print("dictFromJSON=->\(dictFromJSON)")
                    
                }
            } catch {
                print(error.localizedDescription)
            }

            
            
            //                        print("******* response = \(response)")
            //                        let responseString = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
            //                        print("routes.php ****** response data = \(responseString!)",data!.count)
            do {
                //       let json:Any? = try JSONSerialization.jsonObject(with: data!, options: .allowFragments) as? Any
                if let userObject: NSDictionary = (try? JSONSerialization.jsonObject(with: data!, options: []) as! NSDictionary) {
                    print("jsonObject = \(userObject)")
//                    Http.alert("", string(userObject , "message"))
                    //    self.ws_GroupList()
                    
                }
                
            } catch {
                print("error---",error)
                
            }
            
        }
        task.resume()
        
    }
    
    
    
    
}
