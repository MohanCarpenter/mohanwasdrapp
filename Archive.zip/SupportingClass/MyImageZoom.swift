//
//  MyImageZoom.swift
//  WashittoDelivery
//
//  Created by Rahul on 03/08/18.
//  Copyright © 2018 Himanshu pal. All rights reserved.
//

import UIKit

class MyImageZoom: UIViewController , UIScrollViewDelegate {
    var imageToZoom :UIImage?  = nil
    var imageName = ""
    @IBOutlet weak var scrollView: UIScrollView!

    @IBOutlet weak var scrollViewZoom: UIScrollView!
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet var btnClose: UIButton!
    //  @IBOutlet weak var imageSizeToggleButton: UIButton!
    @IBOutlet weak var pageControl: UIPageControl!

    @IBOutlet weak var imageConstraintTop: NSLayoutConstraint!
    @IBOutlet weak var imageConstraintRight: NSLayoutConstraint!
    @IBOutlet weak var imageConstraintLeft: NSLayoutConstraint!
    @IBOutlet weak var imageConstraintBottom: NSLayoutConstraint!
    
    var lastZoomScale: CGFloat = -1
    @IBOutlet  var blurEffect: UIBlurEffect!
    @IBOutlet  var blurEffectView: UIVisualEffectView!

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
//        scrollView.isHidden = true
//        scrollView.isHidden = false
        
         blurEffect = UIBlurEffect(style: UIBlurEffectStyle.dark)
         blurEffectView = UIVisualEffectView(effect: blurEffect)
        blurEffectView.frame = view.bounds
//        view.addSubview(blurEffectView)

        
        scrollViewZoom.isHidden = true
        scrollView.isHidden = false
        btnClose.layer.cornerRadius = btnClose.frame.size.height/2
        
      
//        if  let URL =  URL(string: imageName) {
//            imageView.sd_setImage(with: URL , placeholderImage: UIImage(named: "noimage.png"),  options: SDWebImageOptions.retryFailed)
//
//        }else {
//              imageView.image = UIImage(named:"noimage.png")
//        }
        viewChange()
        
//        if imageToZoom != nil {
//            imageView.image = imageToZoom
//        }else {
//            imageView.image = UIImage(named:"")
//
//        }
        
        scrollView.delegate = self
//        scrollViewZoom.delegate = self

        updateZoom()
        updateConstraints()
    }
    
    @IBAction func dismiss(_ sender: Any) {
        if isClick {
            scrollView.isHidden = true
            isClick = false
        }else {
            self.dismiss(animated: false, completion: nil)
        }


    }
    //MARK: --
    // Update zoom scale and constraints with animation.
    @available(iOS 8.0, *)
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        
        super.viewWillTransition(to: size, with: coordinator)
        
        coordinator.animate(alongsideTransition: { [weak self] _ in
            self?.updateZoom()
            }, completion: nil)
    }
    
  
    override func willAnimateRotation(to toInterfaceOrientation: UIInterfaceOrientation, duration: TimeInterval) {
        
        super.willAnimateRotation(to: toInterfaceOrientation, duration: duration)
        updateZoom()
    }
    
    func updateConstraints() {
        if let image = imageView.image {
            let imageWidth = image.size.width
            let imageHeight = image.size.height
            
            let viewWidth = scrollView.bounds.size.width
            let viewHeight = scrollView.bounds.size.height
            
            // center image if it is smaller than the scroll view
            var hPadding = (viewWidth - scrollView.zoomScale * imageWidth) / 2
            if hPadding < 0 { hPadding = 0 }
            
            var vPadding = (viewHeight - scrollView.zoomScale * imageHeight) / 2
            if vPadding < 0 { vPadding = 0 }
            
            imageConstraintLeft.constant = hPadding
            imageConstraintRight.constant = hPadding
            
            imageConstraintTop.constant = vPadding
            imageConstraintBottom.constant = vPadding
            
            view.layoutIfNeeded()
        }
    }
    
    // Zoom to show as much image as possible unless image is smaller than the scroll view
    fileprivate func updateZoom() {
        if let image = imageView.image {
            var minZoom = min(scrollView.bounds.size.width / image.size.width, scrollView.bounds.size.height / image.size.height)
//
//            var minZoom = min((scrollView.bounds.size.width / image.size.width)/2, (scrollView.bounds.size.height / image.size.height)/2)


            if minZoom > 1 { minZoom = 1 }
            
            scrollView.minimumZoomScale = minZoom // 0.2 * minZoom
            
            // Force scrollViewDidZoom fire if zoom did not change
            if minZoom == lastZoomScale { minZoom += 0.000001 }
            
            scrollView.zoomScale = minZoom
            lastZoomScale = minZoom
        }
    }
    var slides:[Slide] = [];
    func viewChange() {

        slides = createSlides()
        setupSlideScrollView(slides: slides)
        
        pageControl.numberOfPages = slides.count
        pageControl.currentPage = 0
        view.bringSubview(toFront: pageControl)
    }
    func setupSlideScrollView(slides : [Slide]) {
        scrollViewZoom.frame = CGRect(x: 0, y: 0, width: view.frame.width, height: scrollViewZoom.frame.height)
        scrollViewZoom.contentSize = CGSize(width: view.frame.width * CGFloat(slides.count), height: scrollViewZoom.frame.height)
        scrollViewZoom.isPagingEnabled = true
        
        for i in 0 ..< slides.count {
            slides[i].frame = CGRect(x: view.frame.width * CGFloat(i), y: 0, width: view.frame.width, height: scrollViewZoom.frame.height)
            scrollViewZoom.addSubview(slides[i])
        }
    }
    var arrImages = NSArray()
    func createSlides() -> [Slide] {
        
        if  let URL =  URL(string: imageName) {
            imageView.sd_setImage(with: URL , placeholderImage: UIImage(named: "noimage.png"),  options: SDWebImageOptions.retryFailed)
            
        }
        else {
//            imageView.image = UIImage(named:"noimage.png")
        }
        print("count --->",arrImages.count)
        var slider = [Slide]()
        for ii  in 0 ..< arrImages.count {
            let dict  = arrImages.object(at: ii) as? NSDictionary
         
            let slide1:Slide = Bundle.main.loadNibNamed("Slide", owner: self, options: nil)?.first as! Slide
            slide1.imageView.image = UIImage(named: "ic_onboarding_1")

            if let path = dict?.object(forKey: "image") as? String {
                let imgurl = APPConstants.upload_url + path

                if  let URL =  URL(string: imgurl) {
                    slide1.imageView.sd_setImage(with: URL , placeholderImage: UIImage(named: "noimage.png"),  options: SDWebImageOptions.retryFailed)
                }
//                slide1.imageView.sd_setImage(with: imgurl , placeholderImage: UIImage(named: "noimage.png"),  options: SDWebImageOptions.retryFailed)
            }
            
            
            slide1.myFirstButton.addTarget(self, action:#selector(pressed(_:)), for: .touchUpInside)
            slider.append(slide1)
            
        }
        return slider
        
        /*let slide1:Slide = Bundle.main.loadNibNamed("Slide", owner: self, options: nil)?.first as! Slide
        
        slide1.imageView.image = UIImage(named: "ic_onboarding_1")
        slide1.myFirstButton.addTarget(self, action:#selector(pressed(_:)), for: .touchUpInside)

        let slide2:Slide = Bundle.main.loadNibNamed("Slide", owner: self, options: nil)?.first as! Slide
        slide2.imageView.image = UIImage(named: "ic_onboarding_2")
       
//
        slide2.myFirstButton.addTarget(self, action:#selector(pressed(_:)), for: .touchUpInside)

        let slide3:Slide = Bundle.main.loadNibNamed("Slide", owner: self, options: nil)?.first as! Slide
        slide3.imageView.image = UIImage(named: "ic_onboarding_3")
        slide3.myFirstButton.addTarget(self, action:#selector(pressed(_:)), for: .touchUpInside)

        let slide4:Slide = Bundle.main.loadNibNamed("Slide", owner: self, options: nil)?.first as! Slide
        slide4.imageView.image = UIImage(named: "ic_onboarding_4")
        slide4.myFirstButton.addTarget(self, action:#selector(pressed(_:)), for: .touchUpInside)

        
        let slide5:Slide = Bundle.main.loadNibNamed("Slide", owner: self, options: nil)?.first as! Slide
        slide5.imageView.image = UIImage(named: "ic_onboarding_5")
        slide5.myFirstButton.addTarget(self, action:#selector(pressed(_:)), for: .touchUpInside)

        return [slide1, slide2, slide3, slide4, slide5]
        */
    }
    var isClick = false
    @objc func pressed(_ sender: UIButton!) {
        scrollView.isHidden = false
        isClick = true
    }
    func fade(fromRed: CGFloat, fromGreen: CGFloat, fromBlue: CGFloat, fromAlpha: CGFloat, toRed: CGFloat, toGreen: CGFloat, toBlue: CGFloat, toAlpha: CGFloat, withPercentage percentage: CGFloat) -> UIColor {
        
        let red: CGFloat = (toRed - fromRed) * percentage + fromRed
        let green: CGFloat = (toGreen - fromGreen) * percentage + fromGreen
        let blue: CGFloat = (toBlue - fromBlue) * percentage + fromBlue
        let alpha: CGFloat = (toAlpha - fromAlpha) * percentage + fromAlpha
        
        // return the fade colour
        return UIColor(red: red, green: green, blue: blue, alpha: alpha)
    }
    func scrollView(_ scrollView: UIScrollView, didScrollToPercentageOffset percentageHorizontalOffset: CGFloat) {
        if scrollViewZoom == scrollView {
            if(pageControl.currentPage == 0) {
                let pageUnselectedColor: UIColor = fade(fromRed: 255/255, fromGreen: 255/255, fromBlue: 255/255, fromAlpha: 1, toRed: 103/255, toGreen: 58/255, toBlue: 183/255, toAlpha: 1, withPercentage: percentageHorizontalOffset * 3)
                pageControl.pageIndicatorTintColor = pageUnselectedColor
                
                
                let bgColor: UIColor = fade(fromRed: 103/255, fromGreen: 58/255, fromBlue: 183/255, fromAlpha: 1, toRed: 255/255, toGreen: 255/255, toBlue: 255/255, toAlpha: 1, withPercentage: percentageHorizontalOffset * 3)
                slides[pageControl.currentPage].backgroundColor = bgColor
                
                let pageSelectedColor: UIColor = fade(fromRed: 81/255, fromGreen: 36/255, fromBlue: 152/255, fromAlpha: 1, toRed: 103/255, toGreen: 58/255, toBlue: 183/255, toAlpha: 1, withPercentage: percentageHorizontalOffset * 3)
                pageControl.currentPageIndicatorTintColor = pageSelectedColor
            }
        }
   
    }
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        if scrollViewZoom == scrollView {
            
            let pageIndex = Int(round(scrollView.contentOffset.x/view.frame.width))
            pageControl.currentPage = pageIndex
            
            
          
           /*
             let maximumHorizontalOffset: CGFloat = scrollView.contentSize.width - scrollView.frame.width
             let currentHorizontalOffset: CGFloat = scrollView.contentOffset.x
             
             // vertical
             let maximumVerticalOffset: CGFloat = scrollView.contentSize.height - scrollView.frame.height
             let currentVerticalOffset: CGFloat = scrollView.contentOffset.y
             
             let percentageHorizontalOffset: CGFloat = currentHorizontalOffset / maximumHorizontalOffset
             let percentageVerticalOffset: CGFloat = currentVerticalOffset / maximumVerticalOffset
             
             
               let percentOffset: CGPoint = CGPoint(x: percentageHorizontalOffset, y: percentageVerticalOffset)
            if(percentOffset.x > 0 && percentOffset.x <= 0.25) {
                
                slides[0].imageView.transform = CGAffineTransform(scaleX: (0.25-percentOffset.x)/0.25, y: (0.25-percentOffset.x)/0.25)
                slides[1].imageView.transform = CGAffineTransform(scaleX: percentOffset.x/0.25, y: percentOffset.x/0.25)
                
            } else if(percentOffset.x > 0.25 && percentOffset.x <= 0.50) {
                slides[1].imageView.transform = CGAffineTransform(scaleX: (0.50-percentOffset.x)/0.25, y: (0.50-percentOffset.x)/0.25)
                slides[2].imageView.transform = CGAffineTransform(scaleX: percentOffset.x/0.50, y: percentOffset.x/0.50)
                
            } else if(percentOffset.x > 0.50 && percentOffset.x <= 0.75) {
                slides[2].imageView.transform = CGAffineTransform(scaleX: (0.75-percentOffset.x)/0.25, y: (0.75-percentOffset.x)/0.25)
                slides[3].imageView.transform = CGAffineTransform(scaleX: percentOffset.x/0.75, y: percentOffset.x/0.75)
                
            } else if(percentOffset.x > 0.75 && percentOffset.x <= 1) {
                slides[3].imageView.transform = CGAffineTransform(scaleX: (1-percentOffset.x)/0.25, y: (1-percentOffset.x)/0.25)
                slides[4].imageView.transform = CGAffineTransform(scaleX: percentOffset.x, y: percentOffset.x)
            }
            */
        }
    }
    
    // UIScrollViewDelegate
    // -----------------------
    
    func scrollViewDidZoom(_ scrollView: UIScrollView) {
        if scrollViewZoom != scrollView {
            updateConstraints()
        }
    }
    
    func viewForZooming(in scrollView: UIScrollView) -> UIView? {
        if scrollViewZoom != scrollView {
            return imageView
           /* let maximumHorizontalOffset: CGFloat = scrollView.contentSize.width - scrollView.frame.width
            let currentHorizontalOffset: CGFloat = scrollView.contentOffset.x
            
            // vertical
            let maximumVerticalOffset: CGFloat = scrollView.contentSize.height - scrollView.frame.height
            let currentVerticalOffset: CGFloat = scrollView.contentOffset.y
            
            let percentageHorizontalOffset: CGFloat = currentHorizontalOffset / maximumHorizontalOffset
            let percentageVerticalOffset: CGFloat = currentVerticalOffset / maximumVerticalOffset
            
            
            
            let percentOffset: CGPoint = CGPoint(x: percentageHorizontalOffset, y: percentageVerticalOffset)
            
            if(percentOffset.x > 0 && percentOffset.x <= 0.25) {
                
                return slides[1].imageView
                
            } else if(percentOffset.x > 0.25 && percentOffset.x <= 0.50) {
                return slides[2].imageView
                
            } else if(percentOffset.x > 0.50 && percentOffset.x <= 0.75) {
                
                return slides[3].imageView
                
            } else if(percentOffset.x > 0.75 && percentOffset.x <= 1) {
                return slides[4].imageView
            }
            
            
            */
        }
        return nil

    }
    
}
