//
//  SOCKETIOCLIENTMANAGER.swift
//  WashittoDelivery
//
//  Created by Rahul on 17/07/18.
//  Copyright © 2018 Himanshu pal. All rights reserved.
//

import UIKit
import SocketIO

let SOCKETIOCLIENTmanager = SocketManager(socketURL: URL(string: "http://18.206.160.19:8000")!, config: [.log(true), .compress])
let socket = SOCKETIOCLIENTmanager.defaultSocket

class SOCKETIOCLIENTMANAGER: NSObject {
    
    
    
    //    let manager = SocketManager(socketURL: URL(string: "http://localhost:8080")!, config: [.log(true), .compress])
    //    let socket = manager.defaultSocket
    static let sharedInstance = SOCKETIOCLIENTMANAGER()
    
    override init() {
        super.init()
    }
    // SOCKETIOCLIENTMANAGER
    
    //    var socket: SocketIOClient = SocketIOClient(manager: NSURL(string: "http://18.206.160.19:8000/login")! as URL, nsp: "")
    
    
    func establishConnection() {
        socket.on(clientEvent: .connect) {data, ack in
//            print("<---------------- socket ----------------> connected")
            
        }
        
        
        socket.connect()
        
        socketHandler()
        //        socket.emit("login", with: SocketData())
        
        
        //        ("login", cur).timingOut(after: 0) {data in
        //        }
    }
    
    func loginConnection() {
        
        //        self.establishConnection()
        
        if let userkey = UserDefaults.standard.value(forKey:"user_key" ) as? String {
            if  let ss = self.convetr(userkey) { // (["user_key": userkey])
                //               socket.emit("login", ss)
                socket.emitWithAck("login", ss).timingOut(after: 0) { (data) in
                    print ("<---------------- login ----------------> -\(data)--")
                    kappDelegate.is_socket_login = true
                    kappDelegate.curLocation()

                    if #available(iOS 10, *) {
                    } else {
                        // Fallback on earlier versions
                    }
                }
            }
            //            socket.emit("login", ["user_key":"\(userkey)"])
            
            
        }
        
        //            let   nsdi = NSDictionary(dictionary: ["user_key": userkey])
        //            socket.emit("login", nsdi) // "1531490760633"
        
        
        // "[user_key:1531490760633]"
        //
        
        //        socket.emit("login",  "{user_key:1531490760633}")   // "user_key":"1531490760633"
        
        //        socket.emit("login", ["user_key": user_key]) // "1531490760633"
        // _ latitude:Any , _ longitude :Any
        
    }
    
    func updateMyLocation(_ latitude:Double , _ longitude :Double, _ rotation: Double){
        //            let head = locationManager.location?.course ?? 0
        //            marker. rotation = head
        if let userkey = UserDefaults.standard.value(forKey:"user_key" ) as? String {
            if  let param = self.convetrMyLocationJson(userkey, latitude, longitude, rotation){
                //               socket.emit("login", ss)
                socket.emitWithAck("update-location", param).timingOut(after: 0) { (data) in
//                    print ("<---------------- update-location ----------------> -\(data)--")
                    
                }
            }
            
        }else {
            socket.disconnect()
        }
    }
    func convetrMyLocationJson(_ user_key:String, _ latitude:Double , _ longitude :Double, _ rotation: Double) -> String?{
        let dic = ["user_key":user_key, "latitude":String(latitude), "longitude":String(longitude) ,"degree": String(rotation) ]
        
        let encoder = JSONEncoder()
        if let jsonData = try? encoder.encode(dic) {
            if let jsonString = String(data: jsonData, encoding: .utf8) {
                //                print(jsonString.replacingOccurrences(of: "", with: ""))
                return jsonString
            }
        }
        return nil
    }
    func convetr(_ user_key:String) -> String?{
        
        let dic = ["user_key": user_key]
        
        let encoder = JSONEncoder()
        if let jsonData = try? encoder.encode(dic) {
            if let jsonString = String(data: jsonData, encoding: .utf8) {
                //                print(jsonString.replacingOccurrences(of: "", with: ""))
                return jsonString
            }
        }
        return nil
    }
    
    func closeConnection() {
        socket.disconnect()
    }
    
    func socketHandler() {
        
        socket.on ("connect") { data, ack in
//            print ("<---------------- socket ----------------> connected-\(data)-\(ack)-")
        }
        
        socket.on ("error") { data, ack in
//            print ("<---------------- socket ----------------> connect error-\(data)-\(ack)-")
        }
        
        socket.onAny {
//            print("<---------------- socket ----------------> got event: \($0.event) with items \(String(describing: $0.items))")
            
            let evt = "\($0.event)"
            if evt == "connected"{
                // sjdskj j
            }
        }
    }
    
    
}
