//
//  MYZOOMVIEW.swift
//  WashittoDelivery
//
//  Created by Rahul on 14/08/18.
//  Copyright © 2018 Himanshu pal. All rights reserved.
//

import UIKit

class MYZOOMVIEW: UIViewController , UIImagePickerControllerDelegate, UINavigationControllerDelegate, UIPopoverControllerDelegate , UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout  {
  
    @IBOutlet var collectionInagesView: UICollectionView!

    override func viewDidLoad() {
        super.viewDidLoad()
        //                 image = "photos/b3c748a2023a4959329333817525c705.png";
        //                image = "photos/fdbe77b8627414043c62996ebad1a994.png";

        

        arrImages = NSMutableArray()
        
        arrImages.add(NSDictionary(dictionary: ["image" : "photos/b3c748a2023a4959329333817525c705.png"]))
        arrImages.add(NSDictionary(dictionary: ["image" : "photos/fdbe77b8627414043c62996ebad1a994.png"]))

        collectionInagesView.layer.cornerRadius = 10
        collectionInagesView.clipsToBounds = true
        
        collectionInagesView.delegate = self
        collectionInagesView.dataSource = self
        var Width = collectionInagesView.frame.size.width / 2.0 - 8.0
        
        if UIDevice.current.userInterfaceIdiom == .pad {
            Width = collectionInagesView.frame.size.width / 4.0 - 8.0
        }
        
        let cellWidth : CGFloat = Width
        let cellheight : CGFloat = cellWidth//myCollectionView.frame.size.width / 4.0 //- 2.0
        
        
        let cellSize = CGSize(width: cellWidth , height:cellheight)
        
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .horizontal //.horizontal
        layout.itemSize = cellSize
        layout.sectionInset = UIEdgeInsets(top: 1, left: 1, bottom: 1, right: 1)
        layout.minimumLineSpacing = 1.0
        layout.minimumInteritemSpacing = 1.0
        collectionInagesView.setCollectionViewLayout(layout, animated: true)

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    var arrImages = NSMutableArray()

    
    //MARK:- UICollectionView
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        return self.arrImages.count
    }
    
    // make a cell for each cell index path
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        // get a reference to our storyboard cell
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "GroupDetailImagesCell", for: indexPath as IndexPath) as! GroupDetailImagesCell
        let userdetail = self.arrImages.object(at: indexPath.row) as! NSDictionary
        if let path = userdetail.object(forKey: "image") as? String {
            let imgurl = APPConstants.upload_url + path
            let URL =  NSURL(string: imgurl)
            cell.imgPost.sd_setImage(with: URL as URL!, placeholderImage: UIImage(named: "noimage.png"),  options: SDWebImageOptions.retryFailed)
            //            cell.imgPost.setImage
            
        }
        cell.imgPost.layer.cornerRadius = 10
        cell.imgPost.clipsToBounds = true
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
     
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        var Width = collectionInagesView.frame.size.width / 2.0 - 8.0
        
        if UIDevice.current.userInterfaceIdiom == .pad {
            Width = collectionInagesView.frame.size.width / 4.0 - 8.0
        }
        return CGSize(width: Width, height: collectionInagesView.frame.size.height)
    }

   

}
