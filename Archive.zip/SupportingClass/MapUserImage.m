//
//  MapUserImage.m
//  WashittoDelivery
//
//  Created by Rahul on 24/07/18.
//  Copyright © 2018 Himanshu pal. All rights reserved.
//

#import "MapUserImage.h"

@implementation MapUserImage

+(UIImage *)imageWithBorderFromImage:(UIImage *)image
{
    float radius = image.size.height / 2.0;
    
    UIImageView *imageView = [[UIImageView alloc] initWithImage:image];
    CALayer *layer = [CALayer layer];
    layer = [imageView layer];
    
    layer.masksToBounds = YES;
    layer.cornerRadius = radius;
    
    UIGraphicsBeginImageContext(imageView.bounds.size);
    [layer renderInContext:UIGraphicsGetCurrentContext()];
    UIImage *roundedImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return roundedImage;
}

+ (UIImage*)mergeImage:(UIImage *) pinImage withImage:(UIImage *) userImage
{
    // get size of the first image
    CGImageRef firstImageRef = pinImage.CGImage;
    CGFloat firstWidth = CGImageGetWidth(firstImageRef);
    CGFloat firstHeight = CGImageGetHeight(firstImageRef);
    
    // get size of the second image
    CGImageRef secondImageRef = userImage.CGImage;
    CGFloat secondWidth = CGImageGetWidth(secondImageRef);
    CGFloat secondHeight = CGImageGetHeight(secondImageRef);
    
    //NSLog(@"harish -%@-%@-%@-%@-", firstWidth, firstHeight, secondWidth, secondHeight);
    
    // build merged size
    //CGSize mergedSize = CGSizeMake(MAX(firstWidth, secondWidth), MAX(firstHeight, secondHeight));
    
    CGSize mergedSize = CGSizeMake(firstWidth, firstHeight);
    
    // capture image context ref
    UIGraphicsBeginImageContext(mergedSize);
    
    //Draw images onto the context
    [pinImage drawInRect:CGRectMake(0, 0, firstWidth, firstHeight)];
    //[userImage drawInRect:CGRectMake(0, 0, secondWidth, secondHeight)];
    
    
    CGFloat gap = 4.0;
    CGFloat newW = firstWidth - (2 * gap);
    
    CGFloat secondWidth1 = newW;
    CGFloat secondHeight1 = newW;
    [userImage drawInRect:CGRectMake(gap, gap, secondWidth1, secondHeight1)];
    
    
    // assign context to new UIImage
    UIImage *newImage = UIGraphicsGetImageFromCurrentImageContext();
    
    // end context
    UIGraphicsEndImageContext();
    
    return newImage;
}


@end
