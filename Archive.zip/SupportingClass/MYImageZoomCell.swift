//
//  MYImageZoomCell.swift
//  WashittoDelivery
//
//  Created by Rahul on 14/08/18.
//  Copyright © 2018 Himanshu pal. All rights reserved.
//

import UIKit

class MYImageZoomCell: UICollectionViewCell  , UIScrollViewDelegate{
    @IBOutlet var imgPost: UIImageView!
    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var imageConstraintTop: NSLayoutConstraint!
    @IBOutlet weak var imageConstraintRight: NSLayoutConstraint!
    @IBOutlet weak var imageConstraintLeft: NSLayoutConstraint!
    @IBOutlet weak var imageConstraintBottom: NSLayoutConstraint!
    
    var lastZoomScale: CGFloat = -1

    func callDelegate(){
        scrollView.delegate = self
//        updateZoom()

    }
  /*  @available(iOS 8.0, *)
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        
        super.viewWillTransition(to: size, with: coordinator)
        
        coordinator.animate(alongsideTransition: { [weak self] _ in
            self?.updateZoom()
            }, completion: nil)
    }
    
    
    override func willAnimateRotation(
        to toInterfaceOrientation: UIInterfaceOrientation, duration: TimeInterval) {
        
        super.willAnimateRotation(to: toInterfaceOrientation, duration: duration)
        updateZoom()
    }
   
    func updateConstraints() {
        if let image = imageView.image {
            let imageWidth = image.size.width
            let imageHeight = image.size.height
            
            let viewWidth = scrollView.bounds.size.width
            let viewHeight = scrollView.bounds.size.height
            
            // center image if it is smaller than the scroll view
            var hPadding = (viewWidth - scrollView.zoomScale * imageWidth) / 2
            if hPadding < 0 { hPadding = 0 }
            
            var vPadding = (viewHeight - scrollView.zoomScale * imageHeight) / 2
            if vPadding < 0 { vPadding = 0 }
            
            imageConstraintLeft.constant = hPadding
            imageConstraintRight.constant = hPadding
            
            imageConstraintTop.constant = vPadding
            imageConstraintBottom.constant = vPadding
            
            view.layoutIfNeeded()
        }
    }
    
    // Zoom to show as much image as possible unless image is smaller than the scroll view
    fileprivate func updateZoom() {
        if let image = imageView.image {
            //            var minZoom = min(scrollView.bounds.size.width / image.size.width, scrollView.bounds.size.height / image.size.height)
            //
            var minZoom = min((scrollView.bounds.size.width / image.size.width)/2, (scrollView.bounds.size.height / image.size.height)/2)
            
            
            if minZoom > 1 { minZoom = 1 }
            
            scrollView.minimumZoomScale = minZoom // 0.2 * minZoom
            
            // Force scrollViewDidZoom fire if zoom did not change
            if minZoom == lastZoomScale { minZoom += 0.000001 }
            
            scrollView.zoomScale = minZoom
            lastZoomScale = minZoom
        }
    }
    */
}
