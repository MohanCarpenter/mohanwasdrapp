//
//  ObjectClasses.swift
//  ShaktiChat
//
//  Created by mac on 24/10/17.
//  Copyright © 2017 himanshuPal_kavya. All rights reserved.
//

import UIKit
import HarishFrameworkSwift4


class WebServices: NSObject {
    
   // Serverhost: http://ec2-18-216-195-235.us-east-2.compute.amazonaws.com
   // Localhost: http://192.168.11.78:8000
    
  //  static let Live_server = "http://ec2-18-216-195-235.us-east-2.compute.amazonaws.com/api/"
  // static let server_url = Live_server + "baseurl"
 //   static let BaseUrl  = baseUrlData.base_url()
    //http://18.206.160.19/washitto/api/v1/
    //http://192.168.11.84/washitto/api/v1/
    static let BaseUrl  = "http://18.206.160.19/washitto/api/v1/"
     static let logout = BaseUrl + "logout"
    
    static let register = BaseUrl + "del/register"
    static let login = BaseUrl + "del/login"
    static let verify = BaseUrl + "verify" // /verify
    static let resendotp = BaseUrl + "resend-otp"
    static let changephone = BaseUrl + "change-phone"
    static let changepassword = BaseUrl + "change-password"
    static let editprofile = BaseUrl + "edit-profile"
    static let changeemail = BaseUrl + "change-email"
    static let getuser = BaseUrl + "get-user"
    static let countries = BaseUrl + "countries"
    static let states = BaseUrl + "states"
    static let cities = BaseUrl + "cities"
    static let addressadd = BaseUrl + "address/add" //
//    static let addressedit = BaseUrl + "address/edit"
    static let forgotpassword = BaseUrl + "forgot-password"
//    static let address = BaseUrl + "address"
//    static let addressdelete = BaseUrl + "address/delete"
//    static let addressmakedefault = BaseUrl + "address/make-default"
//    static let services = BaseUrl + "services"
    static let baseapi = BaseUrl + "base-api"
//    static let orderscreate = BaseUrl + "orders/create"
    static let accept_fleet = BaseUrl + "del/accept-agreement"
    static let add_user_info = BaseUrl + "del/add-user-info"
    static let add_market_select = BaseUrl + "del/add-market-select"
    static let vehicle_list = BaseUrl + "vehicle-list"
    static let add_license = BaseUrl + "del/add-license"
    static let add_vehicle = BaseUrl + "del/add-vehicle"
    static let agreement_content_type = BaseUrl + "content/"
    static let add_ssn = BaseUrl + "del/add-ssn"

    static let add_selfie = BaseUrl + "del/add-selfie"
    static let notificationlist = BaseUrl + "notification/list"
    static let notificationclear = BaseUrl + "notification/clear"

    static let update_settings = BaseUrl + "update-settings"
    static let terms_and_Policy = BaseUrl + "notification/clear"
    static let orderslist = BaseUrl + "orders/list"
    static let ordersdetails = BaseUrl + "orders/details"

    static let ordersaccept = BaseUrl + "orders/delboy-accept"
    static let orders_picked = BaseUrl + "orders/picked-from-customer"
    static let deliver_to_customer = BaseUrl + "orders/deliver-to-customer"
    static let addressedit = BaseUrl + "address/edit"
    static let address = BaseUrl + "address"

    static let plan_list = BaseUrl + "plan/list"
    static let plan_purchase = BaseUrl + "plan/purchase"

}

class GetUserDetail: NSObject  {
    
   static func myDetailHp(completionHandler: @escaping (Bool) -> Void){
        Http.instance().json(WebServices.getuser, nil, "GET", ai: true, popup: true, prnt: true, userInfo.Token(), sync: false) { (json, dict, str) in
            
            if json != nil {
                let json1 = json as? NSDictionary
                if number(json1! , "success").boolValue {
                    if let result = json1?["result"] as? NSDictionary {
                        
                        if let user = json1?.object(forKey: "result") as? NSDictionary {
                            
                            userInfo.saveLoginInfo(user)
                            completionHandler(true)
                        }
                        
                        if let token = result.object(forKey: "token") as? String {
                            userInfo.savetoken(token)
                        }
                       
                    }
                }else {
                    Http.alert("", string(json1! , "message"))
                }
            }
        }
    }
    
}

class Valid: NSObject {
    
    let NameAcceptableCharacter = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ "
    
    class func email(_ testStr:String) -> Bool {
        var count = 0
        
        for r in testStr.characters {
            
            if r == "@" {
                count += 1
            }
        }
        
        if count > 1 {
            return false
        }
        
        do {
            let regex = try NSRegularExpression(pattern: "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}", options: .caseInsensitive)
            return regex.firstMatch(in: testStr, options: NSRegularExpression.MatchingOptions(rawValue: 0), range: NSMakeRange(0, testStr.count)) != nil
        } catch {
            print("hgkjhgjkgh")
            return false
        }
    }
    
    class func url (_ testStr:String) -> Bool {
        
        do {
            let regex = try NSRegularExpression(pattern: "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}", options: .caseInsensitive)
            return regex.firstMatch(in: testStr, options: NSRegularExpression.MatchingOptions(rawValue: 0), range: NSMakeRange(0, testStr.count)) != nil
        } catch {
            return false
        }
    }
    
    class func fiscale(_ testStr: String) -> Bool {
        
        do {
            let regex = try NSRegularExpression(pattern: "[A-Za-z]{6}[0-9lmnpqrstuvLMNPQRSTUV]{2}[abcdehlmprstABCDEHLMPRST]{1}[0-9lmnpqrstuvLMNPQRSTUV]{2}[A-Za-z]{1}[0-9lmnpqrstuvLMNPQRSTUV]{3}[A-Za-z]{1}", options: .caseInsensitive)
            return regex.firstMatch(in: testStr, options: NSRegularExpression.MatchingOptions(rawValue: 0), range: NSMakeRange(0, testStr.count)) != nil
            
        } catch {
            return false
        }
    }
    
    class func password (_ testStr: String) -> Bool {
        
        if testStr.count < 8 {
            return false
        }
        return true
    }
    
    class func name(strTest: String) -> Bool {
        
        let numberCharacters = NSCharacterSet.decimalDigits
        
        if strTest.rangeOfCharacter(from: numberCharacters) != nil {
            return false
        }
        else if strTest.rangeOfCharacter(from: numberCharacters) == nil {
            return true
        }
        return true
    }
}






class appColour: NSObject {
    
 //"f46c0b"
static let orangeColour = UIColor(red:244/255.0 , green: 108/255.0, blue: 11/255.0, alpha: 1.0)
    
    
 static   let lightGrayColor = UIColor(hex : "ced2dd")
 static   let darkColor = UIColor(hex : "8c8c8c")
   // static let greenColour = UIColor(red:98/255.0 , green: 197/255.0, blue: 38/255.0, alpha: 1.0)
    
    
    static  let Pending = UIColor(hex: "ffd009")
    static  let Completed = UIColor(hex: "41b655")
    static  let Accepted = UIColor(hex: "0384c5")
    static  let Rejected = UIColor(hex: "d90000")
    static  let Canceled = UIColor(hex: "ff000a")
    static  let Accepted_by_other = UIColor(hex: "3062c8")
    static  let Pickup_driver_assigned = UIColor(hex: "6023bc")
    static  let Picked_by_driver = UIColor(hex: "0170c1")
    static  let Received_driver_to_vendor = UIColor(hex: "ed6408")
    static  let Ready_for_dispatch = UIColor(hex: "56abaa")
    static  let Drop_driver_assigned = UIColor(hex: "28544e")
    static  let Received_vendor_to_driver = UIColor(hex: "953500")
    static  let Received_by_customer = UIColor(hex: "03dcc5")
  
    func getColor(_ strStatus:String) -> UIColor {
        if strStatus == "Pending" {
            return UIColor(hex: "6023bc")
        }else  if strStatus == "Accepted" {
           return UIColor(hex: "6023bc")
//            cell.lblStatus.backgroundColor = allAppColor.Accepted
            
        }else  if strStatus == "Completed" {
            return UIColor(hex:"41b655" )
        }else  if strStatus == "Pickup_driver_assigned" {
            return UIColor(hex: "6023bc")

//            cell.lblStatus.backgroundColor = allAppColor.Pickup_driver_assigned
        }
            
        else  if strStatus == "Picked_by_driver" {
            return UIColor(hex: "0170c1")

//            cell.lblStatus.backgroundColor = allAppColor.Picked_by_driver
        }
        else  if strStatus == "Received_driver_to_vendor" {
            return UIColor(hex: "ed6408")
//            cell.lblStatus.backgroundColor = allAppColor.Received_driver_to_vendor
        }
            
        else  if strStatus == "Ready_for_dispatch" {
//            cell.lblStatus.backgroundColor = allAppColor.Ready_for_dispatch
            
            return UIColor(hex: "56abaa")

        }else  if strStatus == "Drop_driver_assigned" {
            return UIColor(hex: "28544e")
//            cell.lblStatus.backgroundColor = allAppColor.Drop_driver_assigned
        }
        else  if strStatus == "Received_vendor_to_driver" {
            return UIColor(hex: "953500")
//            cell.lblStatus.backgroundColor = allAppColor.Received_vendor_to_driver
        }
            
        else  if strStatus == "Received_by_customer" {
            return UIColor(hex: "03dcc5")
//            cell.lblStatus.backgroundColor = allAppColor.Received_by_customer
        } else  if strStatus == "Pickedup" {
            return UIColor(hex: "0170c1")
            //            cell.lblStatus.backgroundColor = allAppColor.Received_by_customer
        }
            
        else {
            return UIColor.lightGray
            
        }
        
//        static  let Pending = UIColor(hex: "ffd009")
//        static  let Completed = UIColor(hex: "41b655")
//        static  let Accepted = UIColor(hex: "0384c5")
//        static  let Rejected = UIColor(hex: "d90000")
//        static  let Canceled = UIColor(hex: "ff000a")
//        static  let Accepted_by_other = UIColor(hex: "3062c8")
//        static  let Pickup_driver_assigned = UIColor(hex: "6023bc")
//        static  let Picked_by_driver = UIColor(hex: "0170c1")
//        static  let Received_driver_to_vendor = UIColor(hex: "ed6408")
//        static  let Ready_for_dispatch = UIColor(hex: "56abaa")
//        static  let Drop_driver_assigned = UIColor(hex: "28544e")
//        static  let Received_vendor_to_driver = UIColor(hex: "953500")
//        static  let Received_by_customer = UIColor(hex: "03dcc5")

        
    }
}




class CompletedSteps {
    
    /*
     "completed_steps
     1 = registration done(email and password)
     2 = fleet_agreement done
     3 = user_information added(first name, last name and phone number)
     4 = phone_verification done
     5 = addres_added
     6 = market_city_added
     7 = vehicle_added
     8 = review_FCRA_discloser
     9 = ssn_added
     10 = selfie_added"
     */
    
    var registration:Bool = false
    var fleet_agreement:Bool = false
    var user_information:Bool = false
    var phone_verification:Bool = false
    var addres_added:Bool = false
    var market_city_added:Bool = false
    var vehicle_added:Bool = false
    var review_FCRA_discloser:Bool = false
    var ssn_added:Bool = false
    var selfie_added:Bool = false

    
//    init(registration:Bool?,fleet_agreement:Bool?, user_information:Bool?, phone_verification:Bool?, addres_added:Bool?, market_city_added:Bool?, vehicle_added:Bool?, review_FCRA_discloser:Bool?,    ssn_added:Bool?, selfie_added:Bool?) {
//        self.registration = registration
//        self.fleet_agreement = fleet_agreement
//        self.user_information = user_information
//        self.phone_verification = phone_verification
//        self.addres_added = addres_added
//        self.market_city_added = market_city_added
//        self.vehicle_added = vehicle_added
//        self.review_FCRA_discloser = review_FCRA_discloser
//        self.ssn_added = ssn_added
//        self.selfie_added = selfie_added
//
//    }

  
   
    
}
class MyCompletedSteps {

    class public func saveSteps (_ ob:NSDictionary) {
        /*
         "completed_steps" = 1;
         email = "mhn@kavya.com";
         "is_address_added" = 0;
         "is_blocked" = 0;
         
         "is_license_added" = 0;
         "is_mail_verified" = 0;
         "is_notification_enable" = 1;
         "is_phone_verified" = 0;
         "is_security_info" = 0;
         "license_screen" = 0;
         "otp_attempt" = 0;
         */
        
        
        let  step =  CompletedSteps()
        if bool(ob, "is_address_added") {
            step.addres_added = true
        }
        if bool(ob, "is_license_added") {
            step.addres_added = true
        }
        
        step.user_information = false
        step.phone_verification = false
        step.market_city_added = false
        step.vehicle_added = false
        step.review_FCRA_discloser = false
        step.ssn_added = false
        step.selfie_added = false
        
        step.registration = true
        step.fleet_agreement = true
        
//        kappDelegate.MyAccountStep = step
//        self.saveCompletedSteps(step)
        
    }
    
    class public func archiveCompletedSteps(_ steps:CompletedSteps) -> NSData {
        let archivedObject = NSKeyedArchiver.archivedData(withRootObject: steps)
        return archivedObject as NSData
    }
    
    class public func retrieveCompletedSteps(_ data:NSData) -> CompletedSteps? {
        if let data = NSKeyedUnarchiver.unarchiveObject(with: data as Data) as? CompletedSteps {
            return data
        }else {
            return nil
        }
        //        return (NSKeyedUnarchiver.unarchiveObject(with: data as Data) as? CompletedSteps)!
    }
    class public func MyCompletedSteps()  -> CompletedSteps? {
//        if let data = UserDefaults.standard.value(forKey: "CompletedSteps") as? NSData {
//            return self.retrieveCompletedSteps(data)
//        }
        return nil
        
    }
    
    class public func saveCompletedSteps (_ ob:CompletedSteps) {
        let defaults = UserDefaults.standard
        defaults.set(archiveCompletedSteps(ob), forKey: "CompletedSteps")
        defaults.synchronize()
    }
    
 
    
    
}



class APPConstants: NSObject {
    static let upload_url = "http://18.206.160.19/washitto/public/uploads/"
    static let client_secret = "AN76rLRjJYqpbjjS2Iazr1zYldJhzWSoOm0aARnV"
    static let cloth_url =  "http://18.206.160.19/washitto/public/uploads/cloths/"

   // static let grant_type = "password"
   // static let scope = "*"
    static let msg_placeHolder = "What's on your mind?"
 static let kCouldnotconnect = "Could not connect to the server. Please try again later."
    static let kInternetNotAvailable = "Please establish network connection."

    
    static let fontRobotoRegular = "Roboto-Regular"
    static let fontRobotoBold = "Roboto-Bold"
    
    
//    static let googleApiKey = "AIzaSyAOKUw-89p70cgSYwRFjRJ005aIY4B2Qc4"

     static let googleApiKey = "AIzaSyB4g-SCtIEkrfcEYQzyf6b2ehJ9rWt_oLY" //AIzaSyAodFkkuCMW1AYCi5UurQxAZ_xcpMGa6BE"
    
    static let deviceType = "iphone"
    static let ScreenWidth =  UIScreen.main.bounds.width
    static let ScreenHeight =  UIScreen.main.bounds.height
    static let appDelegate = UIApplication.shared.delegate as! AppDelegate
  //  static let userDeviceId = UIDevice.current.identifierForVendor!.uuidString
    static func getDeviceId()-> String {
        if let uuid = UIDevice.current.identifierForVendor{
            return uuid.uuidString
        }
        return "123"
    }
    static func getSystemVersion()-> String {
        return "\(UIDevice.current.systemVersion)"
    }
//    let systemVersion = UIDevice.current.systemVersion
//    print("iOS\(systemVersion)")

    
    static let deviceOSVersion = NSString(string: UIDevice.current.systemVersion).floatValue
 //   static let appVersion: AnyObject? = Bundle.main.infoDictionary!["CFBundleShortVersionString"] as AnyObject?
    static func getAppVersion()-> String {
        if let uuid = Bundle.main.infoDictionary!["CFBundleShortVersionString"] as AnyObject?{
        return "\(uuid)"
        
        }
        
        return "1.0"
    }
    
    static let emailAcceptableCharacter = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_.-@"
    static let AddressAcceptableCharacter = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890,/- "
    static let NameAcceptableCharacter = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ "
    static let ZipCodeAcceptableCharacter = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890"
    static let StateCharacter = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890 ."
    static let phoneNoAcceptableCharacter = "1234567890"
    
    
    
    func passValid (_ str:String) -> String {
        
        let char1 = "! @ # $ % ^ & * + = - _ ( ) { } [ ] : ; ' ? / | \\ \" > . < ,"
        let char2 = "a b c d e f g h i j k l m n o p q r s t u v w x y z"
        let char3 = "A B C D E F G H I J K L K M N O P Q R S T U V W X Y Z"
        let char4 = "0 1 2 3 4 5 6 7 8 9"
        
        let arr1 = char1.components(separatedBy: " ")
        let arr2 = char2.components(separatedBy: " ")
        let arr3 = char3.components(separatedBy: " ")
        let arr4 = char4.components(separatedBy: " ")
        
        var boolChar1 = false
        var boolChar2 = false
        var boolChar3 = false
        var boolChar4 = false
        
        for i in 0..<arr1.count {
            if str.subString(arr1[i]) {
                print(str)
                boolChar1 = true
                break
            }
        }
        
        for i in 0..<arr2.count {
            if str.subString(arr2[i]) {
                   print(str)
                boolChar2 = true
                break
            }
        }
       
        
        for i in 0..<arr3.count {
            if str.subString(arr3[i]) {
                boolChar3 = true
                break
            }
        }
        
        for i in 0..<arr4.count {
            if str.subString(arr4[i]) {
                boolChar4 = true
                break
            }
        }
       // print("boolChar1-\(boolChar1)\n boolChar2-\(boolChar2)\nboolChar3-\(boolChar3)\n boolChar4-\(boolChar4)")
        
        if !boolChar1{
            return "specialcharacter"
        }else if !boolChar2{
            return "lowercase"
        }else if !boolChar3{
            return "uppercase"
        }
        else if !boolChar4{
            return "number"
        }else {
            return "correct"
        }
    }
}

/* func subString (_ str:String) -> Bool {
 if self.range(of: str) != nil {
 return true
 }
 
 return false
 }*/


func generateBoundaryString() -> String {
    return "Boundary-\(NSUUID().uuidString)"
}





func stringDecode(_ s: String) -> String? {
    if let str :String  =  s as? String{
        if let data = str.data(using: .utf8) {
            return String(data: data, encoding: .nonLossyASCII)
        }
    }
    return "\(s)"
}
func stringEncode(_ s: String) -> String {
    if let data = s.data(using: .nonLossyASCII, allowLossyConversion: true) {
        return String(data: data, encoding: .utf8)!
    }else {
        return s
    }
}
func dateFormateToGate(format:String)->String {
    let formatter = DateFormatter()
    formatter.dateFormat = format // "yyyy-mm-dd hh:mm:ss"
    return "\(formatter.string(from: Date()))"
}
func stringToDate(_ strDate:String) -> Date {
    // "MMMM dd, yyyy"
    let formatter = DateFormatter()
    formatter.dateFormat = "MMMM dd, yyyy" // "yyyy-mm-dd hh:mm:ss"
    if let date1 = formatter.date(from: strDate) {
        return date1//"\(formatter.string(from: Date()))"
    }else {
        return Date()
    }
    
    
}








func converDictToJson(dict: Any) -> String{
    
    var jsonData = NSData()
    var strTest111 = ""
    do {
        jsonData = try JSONSerialization.data(withJSONObject: dict, options: []) as NSData
        // here "jsonData" is the dictionary encoded in JSON data
        strTest111 = String(data: jsonData as Data, encoding: String.Encoding.utf8)!
        //   print("strTest111 ------>",strTest111)
        return strTest111
    } catch let error as NSError {
        print(error)
    }
    return ""
}





public func hour12To24(time:String) -> String {
    let dateFormatter = DateFormatter()
    dateFormatter.dateFormat = "h:mm a"
    
    if let dt = dateFormatter.date(from: time) {
        dateFormatter.dateFormat = "H:mm:ss"
        return dateFormatter.string(from: dt)
    }else {
        print("problem in date")
    }
    
    return time
}




public func localToUTCTime(date:String) -> String {
    let dateFormatter = DateFormatter()
    dateFormatter.dateFormat = "h:mm a"
    dateFormatter.calendar = NSCalendar.current
    dateFormatter.timeZone = TimeZone.current
    
    if let dt = dateFormatter.date(from: date) {
        dateFormatter.timeZone = TimeZone(abbreviation: "UTC")
        dateFormatter.dateFormat = "H:mm:ss"
        return dateFormatter.string(from: dt)
    }else {
        print("problem in date")
    }
    return date
}

public func UTCToLocalTime(date:String) -> String {
    let dateFormatter = DateFormatter()
    dateFormatter.dateFormat = "H:mm:ss"
    dateFormatter.timeZone = TimeZone(abbreviation: "UTC")
    
    if let dt = dateFormatter.date(from: date) {
        dateFormatter.timeZone = TimeZone.current
        dateFormatter.dateFormat = "h:mm a"
        return dateFormatter.string(from: dt)
        
    }else {
        print("problem in date")
    }
    return date
    
}



class userInfo: NSObject {
    class func removeAllUserDefaultOBJ(){
        userInfo.saveLoginInfo(nil)
//        UserDefaults.standard.removeObject(forKey:"email")
//        UserDefaults.standard.removeObject(forKey:"password")
        UserDefaults.standard.removeObject(forKey:"LoginInfo") // userinfo
        UserDefaults.standard.removeObject(forKey:"savetoken") // token
        UserDefaults.standard.synchronize()
    }
    

    class func saveLoginInfo(_ dict:NSDictionary?) {
        let defaults = UserDefaults.standard
        if dict != nil {
        let archivedObject = NSKeyedArchiver.archivedData(withRootObject: dict!)
            defaults.set(archivedObject, forKey: "LoginInfo")
        }else {
            defaults.removeObject(forKey: "LoginInfo")
        }
        defaults.synchronize()
    }

    
    class func getLoginInfo() -> NSDictionary? {
        let defaults = UserDefaults.standard
        if let temp = defaults.value(forKey: "LoginInfo") {
            if let dict = NSKeyedUnarchiver.unarchiveObject(with: temp as! Data) as? NSDictionary {
                return dict
            }
        }
        return nil
    }
    
    
    class func savearrDownload(_ dict:NSMutableArray?) {
        let defaults = UserDefaults.standard
        if dict != nil {
            let archivedObject = NSKeyedArchiver.archivedData(withRootObject: dict!)
            defaults.set(archivedObject, forKey: "arrDownload")
        }else {
            defaults.removeObject(forKey: "arrDownload")
        }
        defaults.synchronize()
    }
    
    
    class func getarrDownload() -> NSMutableArray? {
        let defaults = UserDefaults.standard
        if let temp = defaults.value(forKey: "arrDownload") {
            if let dict = NSKeyedUnarchiver.unarchiveObject(with: temp as! Data) as? NSMutableArray {
                return dict
            }
        }
        return nil
    }
    
    
    
    
    
    class  func userid() -> String {
        let defaults = UserDefaults.standard
        if let temp = defaults.value(forKey: "LoginInfo") {
            if let dict = NSKeyedUnarchiver.unarchiveObject(with: temp as! Data) as? NSDictionary {
                let userid = string(dict, "id")
                return userid
            }
        }
        return ""
        //  return WebServices.server_url.replacingOccurrences(of: "baseurl", with: "")
    }
    
    
    
    

    class func savetoken(_ strtoken:String) {
        let defaults = UserDefaults.standard
        if strtoken != "" {
            let archivedObject = NSKeyedArchiver.archivedData(withRootObject: strtoken)
            defaults.set(archivedObject, forKey: "savetoken")
        }else {
            defaults.removeObject(forKey: "savetoken")
        }
        defaults.synchronize()
    }
    
    class func getsavetoken() -> String {
        let defaults = UserDefaults.standard
        if let temp = defaults.value(forKey: "savetoken") {
            if let dict = NSKeyedUnarchiver.unarchiveObject(with: temp as! Data) as? String {
                return dict
            }
        }
        return ""
    }
    
    
    //Authorization:Bearer token
    
    class func Token()-> NSDictionary{
        if let user: String = userInfo.getsavetoken() {
            print(user)
            if user != "" {
                return  NSMutableDictionary(dictionary: ["Authorization": "Bearer " + user])
                
               
            }
        }
        return NSMutableDictionary(dictionary: ["Authorization": "Bearer " + "token"])
    }
   
}





class baseUrlData: NSObject {
    
    
   class func saveBaseUrlInfo(_ dict:NSDictionary?) {
        let defaults = UserDefaults.standard
        if dict != nil {
            print(dict!)
            if let base_url = dict?.object(forKey: "baseurl") as? String {
                defaults.set(base_url, forKey: "base_url")
            }
            if let base_url = dict?.object(forKey: "images_path") as? String {
                defaults.set(base_url, forKey: "images_path")
            }
            let archivedObject = NSKeyedArchiver.archivedData(withRootObject: dict!)
            defaults.set(archivedObject, forKey: "base_url_data")
        }else {
            defaults.removeObject(forKey: "base_url_data")
        }
        defaults.synchronize()
    }
    
    
    class func getServices()->NSArray {
        let defaults = UserDefaults.standard
        if let temp = defaults.value(forKey: "base_url_data")  {
            if let dict = NSKeyedUnarchiver.unarchiveObject(with: temp as! Data) as? NSDictionary {
                if let arr = dict.object(forKey: "services") as? NSArray {
                    return arr
                }
            }
        }
        return NSArray()
    }
    class  func base_url() -> String {
        let defaults = UserDefaults.standard
        if let temp = defaults.value(forKey: "base_url") as? String {
            return temp
        }
        return ""
      //  return WebServices.server_url.replacingOccurrences(of: "baseurl", with: "")
    }
    
    class  func uploads_url() -> String {
        let defaults = UserDefaults.standard
        if let temp = defaults.value(forKey: "uploads_url") as? String {
            return temp
        }
        return "http://54.161.88.77/park-pal/public/uploads/"
    }

}


func convertAnyToJson(_ tmp: Any) -> String{
    
    var jsonData = NSData()
    var strTest111 = ""
    do {
        jsonData = try JSONSerialization.data(withJSONObject: tmp, options: []) as NSData
        
        
        // here "jsonData" is the dictionary encoded in JSON data
        strTest111 = String(data: jsonData as Data, encoding: String.Encoding.ascii)!
        //   print("strTest111 ------>",strTest111)
        return strTest111
    } catch let error as NSError {
        print(error)
    }
    return ""
}


func convertToDictionary(text: String) -> [String: Any]? {
    if let data = text.data(using: .utf8) {
        do {
            return try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any]
        } catch {
            print(error.localizedDescription)
        }
    }
    return nil
}








class EncodeDecodeString {
    func stringDecode(_ s: String) -> String? {
        if let data = s.data(using: .utf8) {
            return String(data: data, encoding: .nonLossyASCII)
        }
        return "\(s)"
    }
    func stringEncode(_ s: String) -> String {
        if let data = s.data(using: .nonLossyASCII, allowLossyConversion: true) {
            return String(data: data, encoding: .utf8)!
        }else {
            return s
        }
    }
}

 func timeAgoSinceDate(date:Date?, numericDates:Bool) -> String {
    
    if let date11   = date  {
        let now11 = Date()
        
        
        if now11.years(from: date11) > 0 {
            return "\(Date().years(from: date11)) year ago"
        }
        else if (now11.months(from: date11) > 0) {
            return "\(now11.months(from: date11)) months ago"
        }
        else  if (now11.weeks(from: date11) > 0) {
            return "\(now11.weeks(from: date11)) weeks ago"
        }
        else if (now11.days(from: date11) > 0) {
            return "\(now11.days(from: date11)) days ago"
        }
        else if (now11.hours(from: date11) > 0) {
            return "\(now11.hours(from: date11)) hours ago"
        }
        else if (now11.minutes(from: date11) > 0) {
            return "\(now11.minutes(from: date11)) minutes ago"
        }
        else if (now11.seconds(from: date11) > 0) {
            return "\(now11.seconds(from: date11)) seconds ago"
        }
        return "Just now"
        
        
    }
    return ""
}
func timeAgoSinceDateInShort(date:Date?, numericDates:Bool) -> String {
    
    if let date11   = date  {
        let now11 = Date()
        
        
        if now11.years(from: date11) > 0 {
            return "\(Date().years(from: date11)) year"
        }
        else if (now11.months(from: date11) > 0) {
            return "\(now11.months(from: date11)) mon"
        }
        else  if (now11.weeks(from: date11) > 0) {
            return "\(now11.weeks(from: date11)) week"
        }
        else if (now11.days(from: date11) > 0) {
            return "\(now11.days(from: date11)) day"
        }
        else if (now11.hours(from: date11) > 0) {
            return "\(now11.hours(from: date11)) hour"
        }
        else if (now11.minutes(from: date11) > 0) {
            return "\(now11.minutes(from: date11)) min"
        }
        else if (now11.seconds(from: date11) > 0) {
            return "\(now11.seconds(from: date11)) sec"
        }
        return "Just"
        
        
    }
    return ""
}

 func stringToDateWithFormat( strDate:String,  dateFormat:String) -> Date?{
    
    let formatter = DateFormatter()
    formatter.dateFormat = dateFormat
    formatter.timeZone = TimeZone(abbreviation: "UTC")
    
    if let date1 = formatter.date(from: strDate) {
        //        print("strDate---->\(strDate), date------->\(date1)")
        return date1//"\(formatter.string(from: Date()))"
    }else {
        return nil
    }
}


