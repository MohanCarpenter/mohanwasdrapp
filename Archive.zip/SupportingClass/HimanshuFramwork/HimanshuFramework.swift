//
//  HimanshuFramework.swift
//  Washitto
//
//  Created by kavyaMacMini4 on 08/06/18.
//  Copyright © 2018 Himanshupal.kavya. All rights reserved.
//

import UIKit
import HarishFrameworkSwift4
let kappDelegate = UIApplication.shared.delegate as! AppDelegate
let DeviceID = UIDevice.current.identifierForVendor!.uuidString

/*cell.imgUser.sd_setImage(with: URL as URL!, placeholderImage: UIImage(named: "noimage.png"),  options: SDWebImageOptions.retryFailed)*/

let appLightGray = UIColor(red: 247/255, green: 247/255, blue: 247/255, alpha: 1.0)
let appColor = UIColor(red: 60/255, green: 176/255, blue: 223/255, alpha: 1.0)

class hpFramework: NSObject {
    class func getInstance() -> hpFramework {
        return hpFramework()
    }
  
    
    
}
