//
//  MapUserImage.h
//  WashittoDelivery
//
//  Created by Rahul on 24/07/18.
//  Copyright © 2018 Himanshu pal. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface MapUserImage : NSObject


+ (UIImage*)mergeImage:(UIImage *) pinImage withImage:(UIImage *) userImage;
+(UIImage *)imageWithBorderFromImage:(UIImage *)image;

@end
